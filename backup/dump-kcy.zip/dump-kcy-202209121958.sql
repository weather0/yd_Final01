-- MySQL dump 10.13  Distrib 5.5.62, for Win64 (AMD64)
--
-- Host: ydmariadbinstance.cmnybkzgfijn.ap-northeast-2.rds.amazonaws.com    Database: kcy
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.8-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aca_id_seq`
--

DROP TABLE IF EXISTS `aca_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aca_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aca_id_seq`
--

LOCK TABLES `aca_id_seq` WRITE;
/*!40000 ALTER TABLE `aca_id_seq` DISABLE KEYS */;
INSERT INTO `aca_id_seq` VALUES (3,1,9223372036854775806,1,1,0,0,0);
/*!40000 ALTER TABLE `aca_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_member_seq`
--

DROP TABLE IF EXISTS `class_member_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_member_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_member_seq`
--

LOCK TABLES `class_member_seq` WRITE;
/*!40000 ALTER TABLE `class_member_seq` DISABLE KEYS */;
INSERT INTO `class_member_seq` VALUES (14000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `class_member_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_no_seq`
--

DROP TABLE IF EXISTS `class_no_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_no_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_no_seq`
--

LOCK TABLES `class_no_seq` WRITE;
/*!40000 ALTER TABLE `class_no_seq` DISABLE KEYS */;
INSERT INTO `class_no_seq` VALUES (4000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `class_no_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_seq`
--

DROP TABLE IF EXISTS `evaluation_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluation_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation_seq`
--

LOCK TABLES `evaluation_seq` WRITE;
/*!40000 ALTER TABLE `evaluation_seq` DISABLE KEYS */;
INSERT INTO `evaluation_seq` VALUES (2000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `evaluation_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_admins`
--

DROP TABLE IF EXISTS `k_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_admins` (
  `admin_rank` varchar(100) DEFAULT NULL,
  `admin_job` varchar(100) DEFAULT NULL,
  `admin_id` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`),
  CONSTRAINT `R_92` FOREIGN KEY (`admin_id`) REFERENCES `k_users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_admins`
--

LOCK TABLES `k_admins` WRITE;
/*!40000 ALTER TABLE `k_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_alarm`
--

DROP TABLE IF EXISTS `k_alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_alarm` (
  `sch_id` varchar(100) NOT NULL,
  `alarm_target` varchar(100) DEFAULT NULL,
  `alarm_type` varchar(100) DEFAULT NULL,
  `alarm_day` date DEFAULT NULL,
  `alarm_hour` date DEFAULT NULL,
  `alarm_content` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`sch_id`),
  CONSTRAINT `R_71` FOREIGN KEY (`sch_id`) REFERENCES `k_schedule` (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_alarm`
--

LOCK TABLES `k_alarm` WRITE;
/*!40000 ALTER TABLE `k_alarm` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_alarm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_attendance`
--

DROP TABLE IF EXISTS `k_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_attendance` (
  `stu_id` varchar(100) DEFAULT NULL,
  `attn_type` varchar(100) DEFAULT NULL,
  `class_id` varchar(100) DEFAULT NULL,
  `attn_date` date DEFAULT NULL,
  KEY `R_113` (`stu_id`),
  KEY `k_attendance_FK` (`class_id`),
  CONSTRAINT `R_113` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`),
  CONSTRAINT `k_attendance_FK` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_attendance`
--

LOCK TABLES `k_attendance` WRITE;
/*!40000 ALTER TABLE `k_attendance` DISABLE KEYS */;
INSERT INTO `k_attendance` VALUES ('00000000','3','CL3004','2022-09-12'),('test123','1','CL3004','2022-09-12');
/*!40000 ALTER TABLE `k_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_bills`
--

DROP TABLE IF EXISTS `k_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_bills` (
  `bill_id` varchar(100) NOT NULL,
  `bill_year` int(11) DEFAULT NULL,
  `bill_sem` int(11) DEFAULT NULL,
  `bill_amount` int(11) DEFAULT NULL,
  `major_id` varchar(100) DEFAULT NULL,
  `bill_type` varchar(100) DEFAULT 'b',
  PRIMARY KEY (`bill_id`),
  KEY `R_93` (`major_id`),
  CONSTRAINT `R_93` FOREIGN KEY (`major_id`) REFERENCES `k_major` (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_bills`
--

LOCK TABLES `k_bills` WRITE;
/*!40000 ALTER TABLE `k_bills` DISABLE KEYS */;
INSERT INTO `k_bills` VALUES ('202111010',2021,1,1000000,'1010','b'),('202121010',2021,2,1000000,'1010','b'),('202211010',2022,1,1000000,'1010','b'),('202211018',2022,1,123123123,'1018','b'),('202221010',2022,2,0,'1010','b'),('202221026',2022,2,0,'1026','b');
/*!40000 ALTER TABLE `k_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_d`
--

DROP TABLE IF EXISTS `k_career_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_d` (
  `career_h_id` varchar(100) DEFAULT NULL,
  `career_q_result` varchar(100) DEFAULT NULL,
  `career_q_id` varchar(100) DEFAULT NULL,
  KEY `R_108` (`career_h_id`),
  KEY `k_career_d_FK` (`career_q_id`),
  CONSTRAINT `R_108` FOREIGN KEY (`career_h_id`) REFERENCES `k_career_h` (`career_h_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_d`
--

LOCK TABLES `k_career_d` WRITE;
/*!40000 ALTER TABLE `k_career_d` DISABLE KEYS */;
INSERT INTO `k_career_d` VALUES ('3001','평소에도 관심이 있는 분야였고 더욱 깊게 배우고싶어서 들어오게 되었습니다.','4005'),('3001','네 작게나마 독학으로 공부를 했습니다.','4006'),('3001','Vue쪽에 대한 수업을 듣고싶습니다. ','4007'),('3001','원페이지로 해결하는 기능이 좋은거같아 배우고싶습니다.','4008'),('3001','웹개발자 쪽으로 생각하고있습니다.','4009'),('3001','취업에 대해 상담드리고싶습니다.','4010'),('2556','평소에도 관심이 있는 분야였고 더욱 깊게 배우고싶어서 들어오게 되었습니다.','4005'),('2556','네 작게나마 독학으로 공부를 했습니다.','4006'),('2556','Spring Bood쪽에 대한 수업을 듣고싶습니다. ','4007'),('2556','원페이지로 해결하는 기능이 좋은거같아 배우고싶습니다.','4008'),('2556','웹개발자 쪽으로 생각하고있습니다.','4009'),('2556','취업에 대해 상담드리고싶습니다.','4010'),('2557','평소에도 관심이 있는 분야였고 더욱 깊게 배우고싶어서 들어오게 되었습니다.','4005'),('2557','네 작게나마 독학으로 공부를 했습니다.','4006'),('2557','Ajax쪽에 대한 수업을 듣고싶습니다. ','4007'),('2557','원페이지로 해결하는 기능이 좋은거같아 배우고싶습니다.','4008'),('2557','웹개발자 쪽으로 생각하고있습니다.','4009'),('2557','취업에 대해 상담드리고싶습니다.','4010'),('2558','평소에도 관심이 있는 분야였고 더욱 깊게 배우고싶어서 들어오게 되었습니다.','4005'),('2558','네 작게나마 독학으로 공부를 했습니다.','4006'),('2558','JAVA쪽에 대한 수업을 듣고싶습니다. ','4007'),('2558','원페이지로 해결하는 기능이 좋은거같아 배우고싶습니다.','4008'),('2558','웹개발자 쪽으로 생각하고있습니다.','4009'),('2558','취업에 대해 상담드리고싶습니다.','4010'),('2559','평소에도 관심이 있는 분야였고 더욱 깊게 배우고싶어서 들어오게 되었습니다.','4005'),('2559','네 작게나마 독학으로 공부를 했습니다.','4006'),('2559','C++쪽에 대한 수업을 듣고싶습니다. ','4007'),('2559','원페이지로 해결하는 기능이 좋은거같아 배우고싶습니다.','4008'),('2559','웹개발자 쪽으로 생각하고있습니다.','4009'),('2559','취업에 대해 상담드리고싶습니다.','4010'),('2885','평소에도 관심이 있는 분야입니다.','4005'),('2885','네 작게나마 독학으로 공부를 했습니다.','4006'),('2885','코딩쪽에 대한 수업을 듣고싶습니다. ','4007'),('2885','원페이지로 해결하는 기능이 좋은거같아 배우고싶습니다.','4008'),('2885','웹개발자 쪽으로 생각하고있습니다.','4009'),('2885','취업에 대해 상담드리고싶습니다.','4010'),('4001','ㅇㅇㅇ','4005'),('4001','ㅇㅇㅇ','4006'),('4001','ㅇㅇ','4009'),('4001','ㅇㅇㅇ','4010'),('4002','없습니다','4005'),('4002','아뇨','4006'),('4002','아뇨','4009'),('4002','아뇨','4010'),('4002','아뇨','6001');
/*!40000 ALTER TABLE `k_career_d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_h`
--

DROP TABLE IF EXISTS `k_career_h`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_h` (
  `career_h_id` varchar(100) NOT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `career_h_date` date DEFAULT current_timestamp(),
  `mtr_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`career_h_id`),
  KEY `R_63` (`stu_id`),
  KEY `k_career_h_FK` (`mtr_id`),
  CONSTRAINT `R_63` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`),
  CONSTRAINT `k_career_h_FK` FOREIGN KEY (`mtr_id`) REFERENCES `k_mentoring` (`mtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_h`
--

LOCK TABLES `k_career_h` WRITE;
/*!40000 ALTER TABLE `k_career_h` DISABLE KEYS */;
INSERT INTO `k_career_h` VALUES ('2556','01119665','2022-09-06','2222'),('2557','01103888','2022-09-06','2003'),('2558','00149383','2022-09-06','2005'),('2559','01132538','2022-09-06','2004'),('2885','test123','2022-09-06','3002'),('3001','test123','2022-09-06','4001'),('4001','test123','2022-09-07','5001'),('4002','test123','2022-09-07','5002');
/*!40000 ALTER TABLE `k_career_h` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_list`
--

DROP TABLE IF EXISTS `k_career_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_list` (
  `career_list_id` varchar(100) NOT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `career_list_date` date DEFAULT current_timestamp(),
  PRIMARY KEY (`career_list_id`),
  KEY `R_61` (`prof_id`),
  CONSTRAINT `R_61` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_list`
--

LOCK TABLES `k_career_list` WRITE;
/*!40000 ALTER TABLE `k_career_list` DISABLE KEYS */;
INSERT INTO `k_career_list` VALUES ('2022','testprof','2022-08-30');
/*!40000 ALTER TABLE `k_career_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_q`
--

DROP TABLE IF EXISTS `k_career_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_q` (
  `career_q_id` varchar(100) NOT NULL,
  `career_q_content` varchar(500) DEFAULT NULL,
  `career_list_id` varchar(100) DEFAULT NULL,
  `career_q_yn` varchar(100) DEFAULT 'Y',
  PRIMARY KEY (`career_q_id`),
  KEY `k_career_q_FK` (`career_list_id`),
  CONSTRAINT `R_105` FOREIGN KEY (`career_list_id`) REFERENCES `k_career_list` (`career_list_id`),
  CONSTRAINT `k_career_q_FK` FOREIGN KEY (`career_list_id`) REFERENCES `k_career_list` (`career_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_q`
--

LOCK TABLES `k_career_q` WRITE;
/*!40000 ALTER TABLE `k_career_q` DISABLE KEYS */;
INSERT INTO `k_career_q` VALUES ('4005','본 학과에 들어오게된 계기가 있습니까?','2022','Y'),('4006','본 학과에 대해 알고 지원하셨습니까?','2022','Y'),('4007','필수로 듣고 싶은 수업이 있습니까? 있다면 무엇입니까?','2022','N'),('4008','이 수업을 듣고 싶은 이유가 있습니까?','2022','N'),('4009','희망하는 회사 또는 분야가 있습니까?','2022','Y'),('4010','어떠한 주제의 상담을 원하십니까? ex)취업 or 전과에 대해서 상담을 원합니다','2022','Y');
/*!40000 ALTER TABLE `k_career_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class`
--

DROP TABLE IF EXISTS `k_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class` (
  `class_id` varchar(100) NOT NULL,
  `course_id` varchar(100) DEFAULT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `class_to` int(11) DEFAULT NULL,
  `class_year` int(11) DEFAULT NULL,
  `class_sem` int(11) DEFAULT NULL,
  `class_syl` varchar(100) DEFAULT NULL,
  `class_ck` int(11) DEFAULT 0,
  `class_syl_original` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `R_132` (`course_id`),
  KEY `R_133` (`prof_id`),
  CONSTRAINT `R_132` FOREIGN KEY (`course_id`) REFERENCES `k_course` (`course_id`),
  CONSTRAINT `R_133` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class`
--

LOCK TABLES `k_class` WRITE;
/*!40000 ALTER TABLE `k_class` DISABLE KEYS */;
INSERT INTO `k_class` VALUES ('CL3002','I1000','testprof',20,2022,1,'91e07322-4960-4708-9af8-5265ac61bffe_ㅎㅁㅅㄱ.pptx',1,NULL),('CL3003','I1002','testprof',20,2022,1,'14096df7-743c-42da-8a5c-f6b1754fffe5_KakaoTalk_20220824_094904764.png',0,NULL),('CL3004','I1004','testprof',10,2022,1,'f9694db6-6468-4a79-9bac-7858ba968c8f_KakaoTalk_20220824_094904764.png',2,NULL),('CL3005','I1003','08268070',10,2022,1,'8564d4c4-9b88-48e7-85c4-7347975ea923_최종 프로젝트 DB설계(논리) - 2강1조.jpeg',1,NULL);
/*!40000 ALTER TABLE `k_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_member`
--

DROP TABLE IF EXISTS `k_class_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_member` (
  `class_id` varchar(100) DEFAULT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `class_member_id` varchar(100) NOT NULL,
  PRIMARY KEY (`class_member_id`),
  KEY `R_32` (`class_id`),
  KEY `R_112` (`stu_id`),
  CONSTRAINT `R_112` FOREIGN KEY (`stu_id`) REFERENCES `k_users` (`user_id`),
  CONSTRAINT `R_32` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_member`
--

LOCK TABLES `k_class_member` WRITE;
/*!40000 ALTER TABLE `k_class_member` DISABLE KEYS */;
INSERT INTO `k_class_member` VALUES ('CL3002','00000000','CMI10003'),('CL3004','00000000','CMI10005'),('CL3004','test123','CMI12001');
/*!40000 ALTER TABLE `k_class_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_notice`
--

DROP TABLE IF EXISTS `k_class_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_notice` (
  `class_notice_no` int(11) DEFAULT NULL,
  `class_id` varchar(100) DEFAULT NULL,
  `class_notice_title` varchar(500) DEFAULT NULL,
  `class_notice_date` date DEFAULT NULL,
  `class_notice_hit` int(11) DEFAULT NULL,
  `class_notice_file` varchar(500) DEFAULT NULL,
  `class_notice_id` varchar(100) NOT NULL,
  `class_notice_type` varchar(100) DEFAULT NULL,
  `class_notice_con` varchar(5000) DEFAULT NULL,
  `class_notice_original` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`class_notice_id`),
  KEY `R_42` (`class_id`),
  CONSTRAINT `R_42` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_notice`
--

LOCK TABLES `k_class_notice` WRITE;
/*!40000 ALTER TABLE `k_class_notice` DISABLE KEYS */;
INSERT INTO `k_class_notice` VALUES (2001,'CL3002','헤헤','2022-09-07',NULL,'31cd9935-4c53-43e8-af20-e5e26bf6578c_ㅎㅁㅅㄱ.pptx','4000','noticedata','헤헤','ㅎㅁㅅㄱ.pptx'),(2002,'CL3005','ㅎㅇㅎㅇ','2022-09-07',NULL,'61f38ce1-a214-4307-807f-74aee3fdf8e0_최종 프로젝트 DB설계(논리) - 2강1조.jpeg','4001','notice','fdgsg','최종 프로젝트 DB설계(논리) - 2강1조.jpeg');
/*!40000 ALTER TABLE `k_class_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_reg`
--

DROP TABLE IF EXISTS `k_class_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_reg` (
  `class_id` varchar(100) NOT NULL,
  `course_id` varchar(100) DEFAULT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `class_to` int(11) DEFAULT NULL,
  `class_year` int(11) DEFAULT NULL,
  `class_sem` int(11) DEFAULT NULL,
  `class_syl` varchar(500) DEFAULT NULL,
  `class_yn` varchar(100) DEFAULT 'n',
  `class_title` varchar(100) DEFAULT NULL,
  `class_syl_original` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `R_97` (`prof_id`),
  KEY `R_96` (`course_id`),
  CONSTRAINT `R_96` FOREIGN KEY (`course_id`) REFERENCES `k_course` (`course_id`),
  CONSTRAINT `R_97` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_reg`
--

LOCK TABLES `k_class_reg` WRITE;
/*!40000 ALTER TABLE `k_class_reg` DISABLE KEYS */;
INSERT INTO `k_class_reg` VALUES ('CL3002','I1000','testprof',20,2022,1,'91e07322-4960-4708-9af8-5265ac61bffe_ㅎㅁㅅㄱ.pptx','y','신청','ㅎㅁㅅㄱ.pptx'),('CL3003','I1002','testprof',20,2022,1,'14096df7-743c-42da-8a5c-f6b1754fffe5_KakaoTalk_20220824_094904764.png','y','신청합니다','KakaoTalk_20220824_094904764.png'),('CL3004','I1004','testprof',10,2022,1,'f9694db6-6468-4a79-9bac-7858ba968c8f_KakaoTalk_20220824_094904764.png','y','빨리 허가 해주세요','KakaoTalk_20220824_094904764.png'),('CL3005','I1003','08268070',10,2022,1,'8564d4c4-9b88-48e7-85c4-7347975ea923_최종 프로젝트 DB설계(논리) - 2강1조.jpeg','y','신청할게요','최종 프로젝트 DB설계(논리) - 2강1조.jpeg'),('CL3006','I1005','testprof',5,2022,1,'7f4efbc7-ba5b-40fc-a9d8-7fcb1be7723b_KakaoTalk_20220824_094904764.png','n','테스트','KakaoTalk_20220824_094904764.png');
/*!40000 ALTER TABLE `k_class_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_schedule`
--

DROP TABLE IF EXISTS `k_class_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_schedule` (
  `class_id` varchar(100) DEFAULT NULL,
  `class_sch_date` date DEFAULT NULL,
  `class_sch_id` varchar(100) NOT NULL,
  PRIMARY KEY (`class_sch_id`),
  KEY `R_116` (`class_id`),
  CONSTRAINT `R_116` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_schedule`
--

LOCK TABLES `k_class_schedule` WRITE;
/*!40000 ALTER TABLE `k_class_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_class_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_schedule_t`
--

DROP TABLE IF EXISTS `k_class_schedule_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_schedule_t` (
  `schedule_title` varchar(100) DEFAULT NULL,
  `class_timetable_days` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_schedule_t`
--

LOCK TABLES `k_class_schedule_t` WRITE;
/*!40000 ALTER TABLE `k_class_schedule_t` DISABLE KEYS */;
INSERT INTO `k_class_schedule_t` VALUES ('월요일','D1000'),('화요일','D1001'),('수요일','D1002'),('목요일','D1003'),('금요일','D1004');
/*!40000 ALTER TABLE `k_class_schedule_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_time`
--

DROP TABLE IF EXISTS `k_class_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_time` (
  `class_id` varchar(100) NOT NULL,
  `class_timetable_id` varchar(100) DEFAULT NULL,
  `room_id` varchar(100) DEFAULT NULL,
  KEY `R_89` (`class_timetable_id`),
  KEY `R_90` (`room_id`),
  KEY `R_28` (`class_id`),
  CONSTRAINT `R_28` FOREIGN KEY (`class_id`) REFERENCES `k_class_reg` (`class_id`),
  CONSTRAINT `R_89` FOREIGN KEY (`class_timetable_id`) REFERENCES `k_class_timetable` (`class_timetable_id`),
  CONSTRAINT `R_90` FOREIGN KEY (`room_id`) REFERENCES `k_rooms` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_time`
--

LOCK TABLES `k_class_time` WRITE;
/*!40000 ALTER TABLE `k_class_time` DISABLE KEYS */;
INSERT INTO `k_class_time` VALUES ('CL3002','T1008','R109'),('CL3002','T1010','R109'),('CL3002','T1012','R109'),('CL3003','T1016','R103'),('CL3003','T1018','R103'),('CL3003','T1022','R103'),('CL3005','T1000','R108'),('CL3005','T1002','R108'),('CL3005','T1004','R108'),('CL3006','T1010','R104'),('CL3006','T1011','R104'),('CL3006','T1012','R104'),('CL3006','T1025','R105'),('CL3006','T1026','R105'),('CL3006','T1027','R105');
/*!40000 ALTER TABLE `k_class_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_timetable`
--

DROP TABLE IF EXISTS `k_class_timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_timetable` (
  `class_timetable_id` varchar(100) NOT NULL,
  `class_timetable_name` varchar(100) DEFAULT NULL,
  `class_timetable_code` varchar(100) DEFAULT NULL,
  `class_timetable_days` varchar(100) DEFAULT NULL,
  `class_timetable_start` time DEFAULT NULL,
  `class_timetable_end` time DEFAULT NULL,
  `sch_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_timetable_id`),
  KEY `R_136` (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_timetable`
--

LOCK TABLES `k_class_timetable` WRITE;
/*!40000 ALTER TABLE `k_class_timetable` DISABLE KEYS */;
INSERT INTO `k_class_timetable` VALUES ('T1000','1교시','TC1000','D1000','09:00:00','09:50:00',NULL),('T1001','2교시','TC1001','D1000','10:00:00','10:50:00',NULL),('T1002','3교시','TC1002','D1000','11:00:00','11:50:00',NULL),('T1003','4교시','TC1003','D1000','12:00:00','12:50:00',NULL),('T1004','5교시','TC1004','D1000','14:00:00','14:50:00',NULL),('T1005','6교시','TC1005','D1000','15:00:00','15:50:00',NULL),('T1006','7교시','TC1006','D1000','16:00:00','16:50:00',NULL),('T1007','8교시','TC1007','D1000','17:00:00','17:50:00',NULL),('T1008','1교시','TC1008','D1001','09:00:00','09:50:00',NULL),('T1009','2교시','TC1009','D1001','10:00:00','10:50:00',NULL),('T1010','3교시','TC1010','D1001','11:00:00','11:50:00',NULL),('T1011','4교시','TC1011','D1001','12:00:00','12:50:00',NULL),('T1012','5교시','TC1012','D1001','14:00:00','14:50:00',NULL),('T1013','6교시','TC1013','D1001','15:00:00','15:50:00',NULL),('T1014','7교시','TC1014','D1001','16:00:00','16:50:00',NULL),('T1015','8교시','TC1015','D1001','17:00:00','17:50:00',NULL),('T1016','1교시','TC1016','D1002','09:00:00','09:50:00',NULL),('T1017','2교시','TC1017','D1002','10:00:00','10:50:00',NULL),('T1018','3교시','TC1018','D1002','11:00:00','11:50:00',NULL),('T1019','4교시','TC1019','D1002','12:00:00','12:50:00',NULL),('T1020','5교시','TC1020','D1002','14:00:00','14:50:00',NULL),('T1021','6교시','TC1021','D1002','15:00:00','15:50:00',NULL),('T1022','7교시','TC1022','D1002','16:00:00','16:50:00',NULL),('T1023','8교시','TC1023','D1002','17:00:00','17:50:00',NULL),('T1024','1교시','TC1024','D1003','09:00:00','09:50:00',NULL),('T1025','2교시','TC1025','D1003','10:00:00','10:50:00',NULL),('T1026','3교시','TC1026','D1003','11:00:00','11:50:00',NULL),('T1027','4교시','TC1027','D1003','12:00:00','12:50:00',NULL),('T1028','5교시','TC1028','D1003','14:00:00','14:50:00',NULL),('T1029','6교시','TC1029','D1003','15:00:00','15:50:00',NULL),('T1030','7교시','TC1030','D1003','16:00:00','16:50:00',NULL),('T1031','8교시','TC1031','D1003','17:00:00','17:50:00',NULL),('T1032','1교시','TC1032','D1004','09:00:00','09:50:00',NULL),('T1033','2교시','TC1033','D1004','10:00:00','10:50:00',NULL),('T1034','3교시','TC1034','D1004','11:00:00','11:50:00',NULL),('T1035','4교시','TC1035','D1004','12:00:00','12:50:00',NULL),('T1036','5교시','TC1036','D1004','14:00:00','14:50:00',NULL),('T1037','6교시','TC1037','D1004','15:00:00','15:50:00',NULL),('T1038','7교시','TC1038','D1004','16:00:00','16:50:00',NULL),('T1039','8교시','TC1039','D1004','17:00:00','17:50:00',NULL);
/*!40000 ALTER TABLE `k_class_timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_course`
--

DROP TABLE IF EXISTS `k_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_course` (
  `major_id` varchar(100) DEFAULT NULL,
  `course_id` varchar(100) NOT NULL,
  `course_title` varchar(100) DEFAULT NULL,
  `course_content` varchar(5000) DEFAULT NULL,
  `course_type` varchar(100) DEFAULT NULL,
  `course_credit` double DEFAULT 0,
  `course_openday` date DEFAULT NULL,
  `course_closeday` date DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `R_11` (`major_id`),
  CONSTRAINT `R_11` FOREIGN KEY (`major_id`) REFERENCES `k_major` (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_course`
--

LOCK TABLES `k_course` WRITE;
/*!40000 ALTER TABLE `k_course` DISABLE KEYS */;
INSERT INTO `k_course` VALUES ('1015','I1000','Spring','spring배우는 수업','선택교양',3,'2020-07-16','2022-07-16'),('1015','I1001','Spring Boot','spring Boot 배우는 수업','선택전공',2,'2022-08-30','2024-08-30'),('1015','I1002','Html',' Html 배우는 수업','선택교양',3,'2022-08-30','2024-08-30'),('1015','I1003','javaScript','javaScript 배우는 수업','필수전공',3,'2022-08-30','2024-08-30'),('1015','I1004','jquery','jquery 배우는 수업','선택전공',3,'2022-08-30','2024-08-30'),('1015','I1005','DB베이스','DB 배우는 수업','필수전공',3,'2022-08-30','2024-08-30'),('1014','Sc1000','사회의 악','사회는 악이라는 것을 가르친다','필수전공',2,'2020-07-16','2022-07-16');
/*!40000 ALTER TABLE `k_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_credit`
--

DROP TABLE IF EXISTS `k_credit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_credit` (
  `credit_total` int(11) DEFAULT NULL,
  `credit_major` int(11) DEFAULT NULL,
  `credit_lib` int(11) DEFAULT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  KEY `R_137` (`stu_id`),
  CONSTRAINT `R_137` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_credit`
--

LOCK TABLES `k_credit` WRITE;
/*!40000 ALTER TABLE `k_credit` DISABLE KEYS */;
INSERT INTO `k_credit` VALUES (100,70,30,'01174314'),(110,82,28,'11123456'),(120,100,20,'11123789');
/*!40000 ALTER TABLE `k_credit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_gpa`
--

DROP TABLE IF EXISTS `k_gpa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_gpa` (
  `score_id` varchar(100) DEFAULT NULL,
  `gpa_id` varchar(100) NOT NULL,
  `gpa_point` double DEFAULT NULL,
  `gpa_grade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`gpa_id`),
  KEY `R_37` (`score_id`),
  CONSTRAINT `R_37` FOREIGN KEY (`score_id`) REFERENCES `k_scores` (`score_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_gpa`
--

LOCK TABLES `k_gpa` WRITE;
/*!40000 ALTER TABLE `k_gpa` DISABLE KEYS */;
INSERT INTO `k_gpa` VALUES ('Score6000','G6001',77.5,'C+'),('Score7004','G7005',75,'C+'),('Score7006','G7007',95,'A+');
/*!40000 ALTER TABLE `k_gpa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_gpa_standard`
--

DROP TABLE IF EXISTS `k_gpa_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_gpa_standard` (
  `gpa_standard_attn` int(11) DEFAULT NULL,
  `gpa_standard_quiz` int(11) DEFAULT NULL,
  `gpa_standard_mid` int(11) DEFAULT NULL,
  `gpa_standard_final` int(11) DEFAULT NULL,
  `class_id` varchar(100) NOT NULL,
  PRIMARY KEY (`class_id`),
  CONSTRAINT `R_18` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_gpa_standard`
--

LOCK TABLES `k_gpa_standard` WRITE;
/*!40000 ALTER TABLE `k_gpa_standard` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_gpa_standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_grad`
--

DROP TABLE IF EXISTS `k_grad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_grad` (
  `grad_credit` double DEFAULT NULL,
  `grad_major_credit` double DEFAULT NULL,
  `grad_lib_credit` double DEFAULT NULL,
  `major_id` varchar(100) DEFAULT NULL,
  `grad_id` varchar(100) NOT NULL,
  PRIMARY KEY (`grad_id`),
  KEY `R_77` (`major_id`),
  CONSTRAINT `R_77` FOREIGN KEY (`major_id`) REFERENCES `k_major` (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_grad`
--

LOCK TABLES `k_grad` WRITE;
/*!40000 ALTER TABLE `k_grad` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_grad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_major`
--

DROP TABLE IF EXISTS `k_major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_major` (
  `major_id` varchar(100) NOT NULL,
  `major_name` varchar(100) DEFAULT NULL,
  `major_openday` date DEFAULT NULL,
  `major_closeday` date DEFAULT NULL,
  PRIMARY KEY (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_major`
--

LOCK TABLES `k_major` WRITE;
/*!40000 ALTER TABLE `k_major` DISABLE KEYS */;
INSERT INTO `k_major` VALUES ('1002','중어중문학과','2004-05-15','2005-12-13'),('1003','화학과','2007-01-30','2008-02-12'),('1004','노어노문학과','2004-03-08','2005-10-27'),('1010','경영학과','2008-09-26',NULL),('1011','건축학과','2009-04-11',NULL),('1012','국어국문학과','2002-11-09',NULL),('1013','사회복지학과','1995-11-23',NULL),('1014','사회학과','2004-06-16',NULL),('1015','컴퓨터공학과','1997-10-15',NULL),('1016','심리학과','2004-02-04',NULL),('1017','언론정보학과','2009-04-04',NULL),('1018','언어학과','2002-12-22',NULL),('1019','영어영문학과','1998-08-01',NULL),('1020','의류학과','2000-03-18',NULL),('1021','철학과','2007-03-03',NULL),('1022','통계학과','2006-04-18',NULL),('1023','물리학과','2001-05-21',NULL),('1024','기계공학과','1997-07-02',NULL),('1025','수학과','2000-01-19',NULL),('1026','체육학과','2007-11-07',NULL);
/*!40000 ALTER TABLE `k_major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_matching`
--

DROP TABLE IF EXISTS `k_matching`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_matching` (
  `prof_id` varchar(100) DEFAULT NULL,
  `matching_date` date DEFAULT NULL,
  `matching_type` varchar(100) DEFAULT NULL,
  `matching_id` varchar(100) NOT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`matching_id`),
  KEY `R_55` (`stu_id`),
  KEY `R_56` (`prof_id`),
  CONSTRAINT `R_55` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`),
  CONSTRAINT `R_56` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_matching`
--

LOCK TABLES `k_matching` WRITE;
/*!40000 ALTER TABLE `k_matching` DISABLE KEYS */;
INSERT INTO `k_matching` VALUES ('00217253','2022-08-26','1','1','01115942'),('00217253','2022-08-29','1','1001','test123'),('00265609','2022-08-26','1','2','01132538'),('00265609','2022-08-30','1','2001','00103086'),('00217253','2022-08-30','1','2002','00149383'),('00265609','2022-08-30','1','2003','00149776'),('00217253','2022-08-30','1','2004','01103888'),('00265609','2022-08-30','1','2006','test123'),('testprof','2022-08-30','0','2007','test123'),('testprof','2022-08-30','0','5','01119665'),('testprof','2022-08-30','0','6','01103888'),('testprof','2022-08-30','0','8','00149383'),('testprof','2022-08-30','0','9','01132538');
/*!40000 ALTER TABLE `k_matching` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_matching_change`
--

DROP TABLE IF EXISTS `k_matching_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_matching_change` (
  `stu_id` varchar(100) NOT NULL,
  `matching_change_yn` varchar(100) DEFAULT NULL,
  `matching_change_date` date DEFAULT NULL,
  `matching_change_reject` varchar(500) DEFAULT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `matching_change_reason` varchar(500) DEFAULT NULL,
  `matching_want` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`stu_id`),
  CONSTRAINT `R_125` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_matching_change`
--

LOCK TABLES `k_matching_change` WRITE;
/*!40000 ALTER TABLE `k_matching_change` DISABLE KEYS */;
INSERT INTO `k_matching_change` VALUES ('01115942','2','2022-08-26','적절한 거부 사유','00217253','적절한 사유','00265609');
/*!40000 ALTER TABLE `k_matching_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring`
--

DROP TABLE IF EXISTS `k_mentoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring` (
  `matching_id` varchar(100) DEFAULT NULL,
  `mtr_count` int(11) DEFAULT NULL,
  `mtr_status` varchar(100) DEFAULT 'ing',
  `mtr_id` varchar(100) NOT NULL,
  `mtr_sch_id` varchar(100) DEFAULT NULL,
  `mtr_cancel` varchar(100) DEFAULT '0',
  `mtr_fileName` varchar(500) DEFAULT '0',
  `prof_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mtr_id`),
  KEY `R_131` (`mtr_sch_id`),
  KEY `R_68` (`matching_id`),
  KEY `k_mentoring_FK` (`prof_id`),
  CONSTRAINT `R_131` FOREIGN KEY (`mtr_sch_id`) REFERENCES `k_mentoring_schedule` (`mtr_sch_id`),
  CONSTRAINT `R_68` FOREIGN KEY (`matching_id`) REFERENCES `k_matching` (`matching_id`),
  CONSTRAINT `k_mentoring_FK` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring`
--

LOCK TABLES `k_mentoring` WRITE;
/*!40000 ALTER TABLE `k_mentoring` DISABLE KEYS */;
INSERT INTO `k_mentoring` VALUES ('6',1,'ing','2003','4004','0','0','testprof'),('9',1,'can','2004','5001','취소','0','testprof'),('8',1,'can','2005','6002','취소','0','testprof'),('5',1,'com','2222','2086','0','0','testprof'),('2007',1,'can','3002','3012','0','0','testprof'),('2007',2,'com','4001','6001','0','0','testprof'),('2007',3,'com','5001','7001','0','0','testprof'),('2007',4,'can','5002','7002','가정사','0','testprof');
/*!40000 ALTER TABLE `k_mentoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring_log`
--

DROP TABLE IF EXISTS `k_mentoring_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring_log` (
  `mtr_id` varchar(100) NOT NULL,
  `mtr_log_subject` varchar(500) DEFAULT NULL,
  `mtr_log_content` varchar(7000) DEFAULT NULL,
  `mtr_log_comment` varchar(7000) DEFAULT NULL,
  `mtr_home` varchar(100) DEFAULT NULL,
  `mtr_date` date DEFAULT current_timestamp(),
  PRIMARY KEY (`mtr_id`),
  CONSTRAINT `R_69` FOREIGN KEY (`mtr_id`) REFERENCES `k_mentoring` (`mtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring_log`
--

LOCK TABLES `k_mentoring_log` WRITE;
/*!40000 ALTER TABLE `k_mentoring_log` DISABLE KEYS */;
INSERT INTO `k_mentoring_log` VALUES ('2222','진로에 대한 상담','( 지난 한 주 어떻게 보냈는지?) 친구들도 만나고 학원은 빠짐없이 계속 나\r\n가고 있다. ( 지난주에 오늘은 **씨가 사람들과 관계 맺는 모습에 대해서\r\n이야기 해 보자고 했는데, 생각을 해 보셨는지?) 해 보았다. 앞으로 복학\r\n하게 될 때 학교적응에 중요한 요인이 선후배들과의 관계라고 생각한다.\r\n지금까지 내가 알고 지내 온 사람들을 볼 때 그렇게 인간관계가 어렵거나\r\n힘들지 않았다. 원만하게 지내왔다고 생각되기 때문에 걱정이 되지는 않는\r\n다. ( 나이 차이가 있는 후배들과 같이 수업을 듣게 될 것인데 **씨와 사고\r\n방식이 어떨 것 같은지?) 그렇게 차이가 있으리라고 생각하지는 않는다.\r\n오히려 내가 생각하는 방식이 후배들의 사고방식과 많이 비슷하기 때문에\r\n그렇게 어려울 것이라고 생각되지는 않는다. 학과 학생회 활동이나 과대표\r\n활동에 대해서는 거의 신경을 쓰지 않았고 앞으로도 그렇게 하려고 한다.\r\n그래서 후배들과 부딪힐 일은 그렇게 많지 않으리라고 생각한다. 문제는\r\n선배들과의 관계이다. 입학한 이후로 1년 동안의 학교에 충실하지 않아서\r\n얼굴을 아는 선배들이 거의 없다. 그때는 선배들에 대한 평판이 좋지 않았\r\n다. 나이를 의식하는 것은 아니지만 나이가 같은 선배들도 있다. 앞으로\r\n어떻게 될지는 모르겠지만 익숙하지는 않을 것 같다. 하지만 그들도 군대\r\n를 갔다 와서 생활하기에는 그렇게 어렵지 않을 거라고 생각한다','하려고 하는 의지가 있고 배움에 대한 열정이 있어보임','집이 멀어 학교 인근에서 자취중이라고함','2022-09-06'),('5001','ㅇㅇ','ㅁㅇㅁㅈㅇㅁㅈㅇ','ㅁㅈㅇㅁㅈㅇㅁㅈㅇ','ㅇㅇㅇㅇ','2022-09-07');
/*!40000 ALTER TABLE `k_mentoring_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring_memo`
--

DROP TABLE IF EXISTS `k_mentoring_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring_memo` (
  `mtr_id` varchar(100) NOT NULL,
  `mtr_memo_content` varchar(10000) DEFAULT NULL,
  PRIMARY KEY (`mtr_id`),
  CONSTRAINT `R_143` FOREIGN KEY (`mtr_id`) REFERENCES `k_mentoring` (`mtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring_memo`
--

LOCK TABLES `k_mentoring_memo` WRITE;
/*!40000 ALTER TABLE `k_mentoring_memo` DISABLE KEYS */;
INSERT INTO `k_mentoring_memo` VALUES ('2003',' 이 사례는 대학생들이 흔히 호소하는 대인관계의 불편함을 주로 다룬 사례이다.\n이 사례의 내담자는 대학생다운 언어능력과 사고능력이 구비되어 있었으므로,\n분석적 기법이나 대인관계에서의 행동개선을 위한 역할연습도 효과적으로\n적용되었다.\n  다음에는 분석적 기법이 적용된 과정을 보다 잘 살펴볼 수 있도록 전 회기분의\n상담을 요약과 축어록을 섞어 제시하였다.'),('3002','이 학생은 진로에 대해 고민중인 학생으로 자신이 현재 배우는 과목에 대해 의문을 느끼고있음.'),('4001','등록'),('5001','ㅇ언뭉넝루어우우얼');
/*!40000 ALTER TABLE `k_mentoring_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring_schedule`
--

DROP TABLE IF EXISTS `k_mentoring_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring_schedule` (
  `mtr_sch_id` varchar(100) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `mtr_sch_date` date DEFAULT NULL,
  `mtr_sch_timecode` varchar(500) DEFAULT NULL,
  `CHECK_CODE` varchar(100) DEFAULT '0',
  PRIMARY KEY (`mtr_sch_id`),
  KEY `R_127` (`user_id`),
  KEY `k_mentoring_schedule_FK` (`mtr_sch_timecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring_schedule`
--

LOCK TABLES `k_mentoring_schedule` WRITE;
/*!40000 ALTER TABLE `k_mentoring_schedule` DISABLE KEYS */;
INSERT INTO `k_mentoring_schedule` VALUES ('2081','testprof','2022-02-10','1','0'),('2082','testprof','2022-02-11','1','0'),('2083','testprof','2022-02-09','0','0'),('2084','testprof','2022-02-17','1','0'),('2085','testprof','2022-02-17','2','0'),('2086','testprof','2022-02-16','0','1'),('2088','testprof','2022-02-01','1','0'),('2090','testprof','2022-02-01','4','0'),('3002','testprof','2022-02-04','3','0'),('3003','testprof','2022-02-04','4','0'),('3004','testprof','2022-02-04','5','0'),('3005','testprof','2022-08-16','1','0'),('3006','testprof','2022-08-16','3','0'),('3007','testprof','2022-08-16','4','0'),('3008','testprof','2022-08-22','3','0'),('3009','testprof','2022-08-22','5','0'),('3010','testprof','2022-08-22','6','0'),('3011','testprof','2022-08-12','0','0'),('3012','testprof','2022-08-12','1','1'),('3013','testprof','2022-08-12','4','0'),('3014','testprof','2022-08-12','5','0'),('3015','testprof','2022-08-08','2','0'),('3016','testprof','2022-08-26','5','0'),('4001','testprof','2022-02-08','0','0'),('4002','testprof','2022-02-08','1','0'),('4003','testprof','2022-02-08','3','0'),('4004','testprof','2022-02-08','4','1'),('4005','testprof','2022-02-08','6','0'),('4006','testprof','2022-02-08','7','0'),('4007','testprof','2022-02-02','0','0'),('4009','testprof','2022-02-02','5','0'),('5001','00000000','2022-02-02','0','1'),('5002','00000000','2022-02-02','3','0'),('5003','00000000','2022-02-02','5','0'),('5004','00000000','2022-02-02','6','0'),('6001','testprof','2022-09-07','3','1'),('6002','testprof','2022-09-07','4','1'),('6003','testprof','2022-10-12','3','0'),('6004','testprof','2022-10-12','4','0'),('6005','testprof','2022-10-12','5','0'),('6006','testprof','2022-10-17','3','0'),('6007','testprof','2022-10-07','4','0'),('6008','testprof','2022-10-07','5','0'),('6009','testprof','2022-10-25','0','0'),('6010','testprof','2022-10-25','9','0'),('7001','testprof','2022-09-22','0','1'),('7002','testprof','2022-09-22','5','1');
/*!40000 ALTER TABLE `k_mentoring_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_notice`
--

DROP TABLE IF EXISTS `k_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_notice` (
  `notice_id` varchar(100) NOT NULL,
  `notice_title` varchar(1000) DEFAULT NULL,
  `notice_content` varchar(10000) DEFAULT NULL,
  `notice_date` date DEFAULT NULL,
  `notice_writer` varchar(100) DEFAULT NULL,
  `notice_hit` int(11) DEFAULT NULL,
  `notice_file` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_notice`
--

LOCK TABLES `k_notice` WRITE;
/*!40000 ALTER TABLE `k_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_pay_d`
--

DROP TABLE IF EXISTS `k_pay_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_pay_d` (
  `pay_d_amount` int(11) DEFAULT NULL,
  `pay_d_count` int(11) DEFAULT NULL,
  `pay_d_bank` varchar(100) DEFAULT NULL,
  `pay_d_day` date DEFAULT NULL,
  `pay_id` varchar(100) DEFAULT NULL,
  KEY `R_95` (`pay_id`),
  CONSTRAINT `R_95` FOREIGN KEY (`pay_id`) REFERENCES `k_pay_h` (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_pay_d`
--

LOCK TABLES `k_pay_d` WRITE;
/*!40000 ALTER TABLE `k_pay_d` DISABLE KEYS */;
INSERT INTO `k_pay_d` VALUES (1000000,1,'KB','2021-03-02','test123202111010'),(1000000,1,'KB','2021-09-02','test123202121010'),(250000,1,'KB','2022-03-02','test123202211010'),(250000,2,'KB','2022-04-02','test123202211010'),(250000,3,'KB','2022-05-02','test123202211010'),(250000,4,'KB','2022-06-02','test123202211010');
/*!40000 ALTER TABLE `k_pay_d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_pay_h`
--

DROP TABLE IF EXISTS `k_pay_h`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_pay_h` (
  `pay_id` varchar(100) NOT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `bill_id` varchar(100) DEFAULT NULL,
  `pay_h_total` int(11) DEFAULT 1,
  `pay_h_remain` int(11) DEFAULT 1,
  `pay_h_bal` int(11) DEFAULT NULL,
  `pay_h_yn` varchar(100) DEFAULT 'n',
  `pay_h_acc` varchar(100) DEFAULT NULL,
  `pay_h_grade` int(11) DEFAULT NULL,
  `pay_h_sem` int(11) DEFAULT NULL,
  `pay_h_type` varchar(100) DEFAULT 'b',
  PRIMARY KEY (`pay_id`),
  KEY `R_39` (`stu_id`),
  KEY `R_40` (`bill_id`),
  CONSTRAINT `R_39` FOREIGN KEY (`stu_id`) REFERENCES `k_users` (`user_id`),
  CONSTRAINT `R_40` FOREIGN KEY (`bill_id`) REFERENCES `k_bills` (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_pay_h`
--

LOCK TABLES `k_pay_h` WRITE;
/*!40000 ALTER TABLE `k_pay_h` DISABLE KEYS */;
INSERT INTO `k_pay_h` VALUES ('00149383202221010','00149383','202221010',1,1,0,'n',NULL,4,2,'b'),('00149776202221026','00149776','202221026',1,1,0,'n',NULL,1,2,'b'),('01115942202221026','01115942','202221026',1,1,0,'n',NULL,3,2,'b'),('test123202111010','test123','202111010',1,0,0,'y','200000000001',2,1,'b'),('test123202121010','test123','202121010',1,0,0,'y','200000000001',2,2,'b'),('test123202211010','test123','202211010',4,0,0,'y','200000000001',3,1,'s1'),('test123202221010','test123','202221010',1,1,0,'n','200000000001',3,1,'b');
/*!40000 ALTER TABLE `k_pay_h` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_prof_q`
--

DROP TABLE IF EXISTS `k_prof_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_prof_q` (
  `prof_q_id` varchar(100) NOT NULL,
  `prof_q_content` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`prof_q_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_prof_q`
--

LOCK TABLES `k_prof_q` WRITE;
/*!40000 ALTER TABLE `k_prof_q` DISABLE KEYS */;
INSERT INTO `k_prof_q` VALUES ('EV1000','강의계획서가 강좌의 목표,내용,성적평가 방법 등 과목의 성격을 이해하기 쉽게 구성되었다.'),('EV1001','강의계획서 진도에 맞게 해당 주차에 온라인 수업 콘텐츠가 게시되었다'),('EV1002','강의교재나 참고자료가 수업내용을 이해하는데 적절하게 구성되었으며 다양한 학습자료가 제공되\r\n었다.\r\n'),('EV1003','학생들의 질의응답 게시판 또는 이메일, 모바일 등을 활용하여 질의 내용에 성실하게 답변하였다.\r\n'),('EV1004','과제의 방법과 성적 평가기준 및 방식은 객관적이고 합리적으로 제시되었다.\r\n'),('EV1005','과제의 내용 및 분량은 적절하였으며 강의 내용을 이해하는데 도움을 주었다'),('EV1006','이 강의를 통해 관련 지식과 전공능력(핵심역량)이 증진되었다.\r\n');
/*!40000 ALTER TABLE `k_prof_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_prof_r`
--

DROP TABLE IF EXISTS `k_prof_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_prof_r` (
  `class_id` varchar(100) DEFAULT NULL,
  `prof_r_result` varchar(500) DEFAULT NULL,
  `prof_r_date` date DEFAULT NULL,
  `prof_q_id` varchar(100) DEFAULT NULL,
  `class_member_id` varchar(100) DEFAULT NULL,
  KEY `R_54` (`class_id`),
  KEY `R_85` (`prof_q_id`),
  KEY `R_53` (`class_member_id`),
  CONSTRAINT `R_53` FOREIGN KEY (`class_member_id`) REFERENCES `k_class_member` (`class_member_id`),
  CONSTRAINT `R_54` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`),
  CONSTRAINT `R_85` FOREIGN KEY (`prof_q_id`) REFERENCES `k_prof_q` (`prof_q_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_prof_r`
--

LOCK TABLES `k_prof_r` WRITE;
/*!40000 ALTER TABLE `k_prof_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_prof_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_professors`
--

DROP TABLE IF EXISTS `k_professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_professors` (
  `prof_id` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `prof_field` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_edu` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_career` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_paper` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_lab` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_mentee` int(2) DEFAULT NULL,
  PRIMARY KEY (`prof_id`),
  CONSTRAINT `R_1` FOREIGN KEY (`prof_id`) REFERENCES `k_users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_estonian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_professors`
--

LOCK TABLES `k_professors` WRITE;
/*!40000 ALTER TABLE `k_professors` DISABLE KEYS */;
INSERT INTO `k_professors` VALUES ('00149383','ㅋㅋㅋ','00대학','00대학 임원','논문없음','202호실',10),('00217253','철학','00대학 00박사','00대학 소장','테스트용 논문','203호실',10),('00265609','사회복지','00대학 00박사','00대학 부소장','테스트용 논문2','503호실',10),('03205116','사회','00대학','00박사','없음','201호',10),('08268070','IT','00대학 00박','00대학 소장','시험용 논문','201호실',10),('21212121','핵융합에너지','치킨대학 신바람박사','인터넷진흥원 원장(진)','라식에 관한 연구','301호실',NULL),('testprof','몰루','00대학','00대학 임원','논문없음','202호실',10);
/*!40000 ALTER TABLE `k_professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_quiz_d`
--

DROP TABLE IF EXISTS `k_quiz_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_quiz_d` (
  `quiz_d_date` date DEFAULT NULL,
  `quiz_d_openday` date DEFAULT NULL,
  `quiz_d_closeday` date DEFAULT NULL,
  `quiz_d_id` varchar(100) NOT NULL,
  `quiz_h_id` varchar(100) DEFAULT NULL,
  `quiz_d_cnt` int(11) DEFAULT NULL,
  PRIMARY KEY (`quiz_d_id`),
  KEY `R_145` (`quiz_h_id`),
  CONSTRAINT `R_145` FOREIGN KEY (`quiz_h_id`) REFERENCES `k_quiz_h` (`quiz_h_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_quiz_d`
--

LOCK TABLES `k_quiz_d` WRITE;
/*!40000 ALTER TABLE `k_quiz_d` DISABLE KEYS */;
INSERT INTO `k_quiz_d` VALUES ('2022-09-07',NULL,'2022-09-16','D4001','HD4001',NULL),('2022-09-07','2022-09-07','2022-09-15','D4002','HD4006',NULL),('2022-09-07','2022-09-07','2022-09-22','D4003','HD4007',NULL),('2022-09-09','2022-09-09','2022-09-24','D5001','HD6001',NULL);
/*!40000 ALTER TABLE `k_quiz_d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_quiz_h`
--

DROP TABLE IF EXISTS `k_quiz_h`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_quiz_h` (
  `class_id` varchar(100) DEFAULT NULL,
  `quiz_h_title` varchar(500) DEFAULT NULL,
  `quiz_h_content` varchar(10000) DEFAULT NULL,
  `quiz_h_file` varchar(500) DEFAULT NULL,
  `quiz_h_id` varchar(100) NOT NULL,
  `quiz_h_seq` int(11) DEFAULT NULL,
  `quiz_h_original` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`quiz_h_id`),
  KEY `R_144` (`class_id`),
  CONSTRAINT `R_144` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_quiz_h`
--

LOCK TABLES `k_quiz_h` WRITE;
/*!40000 ALTER TABLE `k_quiz_h` DISABLE KEYS */;
INSERT INTO `k_quiz_h` VALUES ('CL3002','과제','과제','9bd2104b-80a7-4914-8f40-818c3b36a3f6_ㅎㅁㅅㄱ.pptx','HD4001',5005,'ㅎㅁㅅㄱ.pptx'),('CL3005','dfdfdsf','dgsgrg','c26a408c-2ead-4258-9997-0a43ff679243_최종 프로젝트 DB설계(논리) - 2강1조.jpeg','HD4006',5006,'최종 프로젝트 DB설계(논리) - 2강1조.jpeg'),('CL3005','과젱','과젱','fda592c7-14b9-4445-8631-6a5b6f2c1b96_최종 프로젝트 DB설계(논리) - 2강1조.jpeg','HD4007',5007,'최종 프로젝트 DB설계(논리) - 2강1조.jpeg'),('CL3004','ㅇ','ㅇ',NULL,'HD6001',6005,'');
/*!40000 ALTER TABLE `k_quiz_h` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_quiz_r`
--

DROP TABLE IF EXISTS `k_quiz_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_quiz_r` (
  `quiz_r_content` varchar(10000) DEFAULT NULL,
  `quiz_r_date` date DEFAULT NULL,
  `quiz_r_file` varchar(500) DEFAULT NULL,
  `quiz_d_id` varchar(100) DEFAULT NULL,
  `quiz_r_point` int(11) DEFAULT NULL,
  `quiz_r_id` varchar(100) NOT NULL,
  `quiz_r_orginal` varchar(500) DEFAULT NULL,
  `class_member_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`quiz_r_id`),
  KEY `R_121` (`quiz_d_id`),
  KEY `class_member_id` (`class_member_id`),
  CONSTRAINT `R_121` FOREIGN KEY (`quiz_d_id`) REFERENCES `k_quiz_d` (`quiz_d_id`),
  CONSTRAINT `k_quiz_r_ibfk_1` FOREIGN KEY (`class_member_id`) REFERENCES `k_class_member` (`class_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_quiz_r`
--

LOCK TABLES `k_quiz_r` WRITE;
/*!40000 ALTER TABLE `k_quiz_r` DISABLE KEYS */;
INSERT INTO `k_quiz_r` VALUES ('dgsgsg','2022-09-07',NULL,'D4001',50,'R4001','최종 프로젝트 DB설계(논리) - 2강1조.jpeg','CMI10003'),('ㅇ','2022-09-09',NULL,'D5001',80,'R5001',NULL,'CMI12001'),('ㅎㅎ','2022-09-09',NULL,'D5001',100,'R5002',NULL,'CMI10005');
/*!40000 ALTER TABLE `k_quiz_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_rooms`
--

DROP TABLE IF EXISTS `k_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_rooms` (
  `room_id` varchar(100) NOT NULL,
  `room_building` varchar(100) DEFAULT NULL,
  `room_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_rooms`
--

LOCK TABLES `k_rooms` WRITE;
/*!40000 ALTER TABLE `k_rooms` DISABLE KEYS */;
INSERT INTO `k_rooms` VALUES ('R100','브라운관',101),('R101','브라운관',102),('R102','브라운관',103),('R103','브라운관',104),('R104','브라운관',105),('R105','브라운관',201),('R106','브라운관',202),('R107','브라운관',203),('R108','브라운관',204),('R109','브라운관',205),('R110','브라운관',301),('R111','브라운관',302),('R112','브라운관',303),('R113','브라운관',304),('R114','브라운관',305),('R115','브라운관',401),('R116','브라운관',402),('R117','브라운관',403),('R118','브라운관',404),('R119','브라운관',405),('R120','브라운관',501),('R121','브라운관',502),('R122','브라운관',503),('R123','브라운관',504),('R124','브라운관',505),('R125','실버관',101),('R126','실버관',102),('R127','실버관',103),('R128','실버관',104),('R129','실버관',105),('R130','실버관',201),('R131','실버관',202),('R132','실버관',203),('R133','실버관',204),('R134','실버관',205),('R135','실버관',301),('R136','실버관',302),('R137','실버관',303),('R138','실버관',304),('R139','실버관',305),('R140','실버관',401),('R141','실버관',402),('R142','실버관',403),('R143','실버관',404),('R144','실버관',405),('R145','실버관',501),('R146','실버관',502),('R147','실버관',503),('R148','실버관',504),('R149','실버관',505),('R150','골드관',101),('R151','골드관',102),('R152','골드관',103),('R153','골드관',104),('R154','골드관',105),('R155','골드관',201),('R156','골드관',202),('R157','골드관',203),('R158','골드관',204),('R159','골드관',205),('R160','골드관',301),('R161','골드관',302),('R162','골드관',303),('R163','골드관',304),('R164','골드관',305),('R165','골드관',401),('R166','골드관',402),('R167','골드관',403),('R168','골드관',404),('R169','골드관',405),('R170','골드관',501),('R171','골드관',502),('R172','골드관',503),('R173','골드관',504),('R174','골드관',505);
/*!40000 ALTER TABLE `k_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_sch_times`
--

DROP TABLE IF EXISTS `k_sch_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_sch_times` (
  `mtr_sch_timecode` varchar(500) NOT NULL,
  `mtr_sch_start` time DEFAULT NULL,
  `mtr_sch_end` time DEFAULT NULL,
  PRIMARY KEY (`mtr_sch_timecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_sch_times`
--

LOCK TABLES `k_sch_times` WRITE;
/*!40000 ALTER TABLE `k_sch_times` DISABLE KEYS */;
INSERT INTO `k_sch_times` VALUES ('0','09:00:00','09:50:00'),('1','10:00:00','10:50:00'),('2','11:00:00','11:50:00'),('3','12:00:00','12:50:00'),('4','13:00:00','13:50:00'),('5','14:00:00','14:50:00'),('6','15:00:00','15:50:00'),('7','16:00:00','16:50:00'),('8','17:00:00','17:50:00'),('9','18:00:00','18:50:00');
/*!40000 ALTER TABLE `k_sch_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_schedule`
--

DROP TABLE IF EXISTS `k_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_schedule` (
  `sch_id` varchar(100) NOT NULL,
  `sch_start` date DEFAULT NULL,
  `sch_end` date DEFAULT NULL,
  `sch_title` varchar(500) DEFAULT NULL,
  `sch_manager` varchar(100) DEFAULT NULL,
  `sch_type` varchar(100) DEFAULT NULL,
  `sch_color` varchar(100) DEFAULT NULL,
  `sch_alarm` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_schedule`
--

LOCK TABLES `k_schedule` WRITE;
/*!40000 ALTER TABLE `k_schedule` DISABLE KEYS */;
INSERT INTO `k_schedule` VALUES ('S202201','2022-03-02','2022-06-30','2022년1학기','공통','SEMESTER',NULL,NULL),('S202202','2022-09-01','2022-12-30','2022년2학기','공통','SEMESTER',NULL,NULL),('S202301','2023-03-02','2023-06-30','2023년1학기','공통','SEMESTER',NULL,NULL),('S202302','2023-09-01','2023-12-30','2023년2학기','공통','SEMESTER',NULL,NULL),('S202401','2024-03-04','2024-06-30','2024년1학기','공통','SEMESTER',NULL,NULL),('S202402','2024-09-02','2024-12-30','2024년2학기','공통','SEMESTER',NULL,NULL),('S202501','2025-03-04','2025-06-30','2025년1학기','공통','SEMESTER',NULL,NULL),('S202502','2025-09-01','2025-12-30','2025년2학기','공통','SEMESTER',NULL,NULL),('S202601','2026-03-03','2026-06-30','2026년1학기','공통','SEMESTER',NULL,NULL),('S202602','2026-09-01','2026-12-30','2026년2학기','공통','SEMESTER',NULL,NULL),('S202701','2027-03-02','2027-06-30','2027년1학기','공통','SEMESTER',NULL,NULL),('S202702','2027-09-01','2027-12-30','2027년2학기','공통','SEMESTER',NULL,NULL),('S202801','2028-03-02','2028-06-30','2028년1학기','공통','SEMESTER',NULL,NULL),('S202802','2028-09-01','2028-12-30','2028년2학기','공통','SEMESTER',NULL,NULL),('S202901','2029-03-02','2029-06-30','2029년1학기','공통','SEMESTER',NULL,NULL),('S202902','2029-09-03','2029-12-30','2029년2학기','공통','SEMESTER',NULL,NULL),('S203001','2030-03-04','2030-06-30','2030년1학기','공통','SEMESTER',NULL,NULL),('S203002','2030-09-02','2030-12-30','2030년2학기','공통','SEMESTER',NULL,NULL),('S203101','2031-03-04','2031-06-30','2031년1학기','공통','SEMESTER',NULL,NULL),('S203102','2031-09-01','2031-12-30','2031년2학기','공통','SEMESTER',NULL,NULL);
/*!40000 ALTER TABLE `k_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_scores`
--

DROP TABLE IF EXISTS `k_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_scores` (
  `score_id` varchar(100) NOT NULL,
  `class_member_id` varchar(100) DEFAULT NULL,
  `score_attn` int(11) DEFAULT NULL,
  `score_quiz` int(11) DEFAULT NULL,
  `score_mid` int(11) DEFAULT NULL,
  `score_final` int(11) DEFAULT NULL,
  `score_date` date DEFAULT NULL,
  PRIMARY KEY (`score_id`),
  KEY `R_124` (`class_member_id`),
  CONSTRAINT `R_124` FOREIGN KEY (`class_member_id`) REFERENCES `k_class_member` (`class_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_scores`
--

LOCK TABLES `k_scores` WRITE;
/*!40000 ALTER TABLE `k_scores` DISABLE KEYS */;
INSERT INTO `k_scores` VALUES ('Score6000','CMI10003',100,50,80,80,'2022-09-09'),('Score7001','CMI12001',100,80,50,100,'2022-09-12'),('Score7003','CMI10005',100,100,100,80,'2022-09-12'),('Score7004','CMI12001',70,80,50,100,'2022-09-12'),('Score7006','CMI10005',80,100,100,100,'2022-09-12');
/*!40000 ALTER TABLE `k_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_student_aca`
--

DROP TABLE IF EXISTS `k_student_aca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_student_aca` (
  `aca_id` varchar(100) NOT NULL DEFAULT nextval(`kcy`.`aca_id_seq`),
  `aca_type` varchar(100) DEFAULT NULL,
  `aca_start` varchar(100) DEFAULT NULL,
  `aca_end` varchar(100) DEFAULT NULL,
  `aca_reason` varchar(100) DEFAULT NULL,
  `aca_reason_d` varchar(5000) DEFAULT NULL,
  `aca_yn` varchar(100) DEFAULT NULL,
  `aca_reject` varchar(500) DEFAULT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `aca_date` datetime DEFAULT NULL,
  `aca_file` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`aca_id`),
  KEY `R_79` (`stu_id`),
  CONSTRAINT `R_79` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_student_aca`
--

LOCK TABLES `k_student_aca` WRITE;
/*!40000 ALTER TABLE `k_student_aca` DISABLE KEYS */;
INSERT INTO `k_student_aca` VALUES ('2004','더미데이터','2015-04-27',NULL,NULL,NULL,NULL,NULL,'11123456','2015-04-27 00:00:00',NULL),('2006','입학','2011-03-01',NULL,NULL,NULL,NULL,NULL,'11123456','2011-03-01 00:00:00',NULL),('2007','휴학','S202301','S202401','수험','수험 휴학입니다!','신청중',NULL,'11123456','2022-08-31 00:00:00',NULL),('3001','복학','S202601',NULL,NULL,NULL,'신청중',NULL,'11123456','2022-09-01 00:00:00',NULL),('3002','자퇴',NULL,NULL,'수험','수험자퇴합니다','반려','ㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎㅈㄷㅎ','11123456','2022-09-01 00:00:00',NULL),('3003','자퇴',NULL,NULL,'해외체류','해외 자퇴합니다','승인',NULL,'11123456','2022-09-01 00:00:00',NULL),('3004','복학','S202502',NULL,NULL,NULL,'반려','5641646894','11123456','2022-09-01 00:00:00',NULL),('3005','입학','2011-09-01',NULL,NULL,NULL,NULL,NULL,'11123789','2022-09-01 00:00:00',NULL),('3006','휴학','S202601','S202701','군입대','군입대합니다','반려','ㅅㅎ','11123789','2022-09-01 00:00:00',NULL),('3007','휴학','S202401','S202401','건강문제','몸이 아파요','반려','90707807ㅕ0ㅛㅗ','11123789','2022-09-01 00:00:00',NULL),('3008','복학','S202501',NULL,NULL,NULL,'신청중',NULL,'11123789','2022-09-01 00:00:00',NULL),('7002','휴학','S202701','S202701','건강문제','건강문제요 ㅜㅜ ','승인',NULL,'11123789','2022-09-05 12:51:15','11123789_8509_ㅜㅜㄹ ㄱ더ㅜㅎㅌㅁ ㅈㄷ렆쿠ㅑㅐㅔ ㅍ어ㅗㅁ 제댜ㅓㅑㅎ레우 test테스 트12 3!@#+= ㅁㅈㄷ렆ㅁㅈㄷ렆쿠ㅑㅐㅔㅍ 어ㅗㅁ제댜ㅓㅑ쿠ㅑㅐㅁㅈㄷ렆쿠ㅑ ㅐㅔㅍ 어ㅗㅁ제댜ㅓㅑㅔㅍ어 ㅗㅁ제댜ㅁㅈa wjnpiofajwfeph08wyeafwefㄷ렆쿠ㅑㅐㅔㅍ어ㅗㅁ제댜ㅓㅑㅓㅑ-.txt');
/*!40000 ALTER TABLE `k_student_aca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_students`
--

DROP TABLE IF EXISTS `k_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_students` (
  `stu_id` varchar(100) NOT NULL,
  `student_regdate` date DEFAULT NULL,
  `student_graddate` date DEFAULT NULL,
  `student_grade` int(11) DEFAULT NULL,
  `student_sem` int(11) DEFAULT NULL,
  `student_aca_yn` varchar(100) DEFAULT NULL,
  `student_prof` varchar(100) DEFAULT NULL,
  `student_change_status` varchar(100) DEFAULT '0',
  `student_token` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`stu_id`),
  KEY `k_students_FK` (`student_prof`),
  CONSTRAINT `R_3` FOREIGN KEY (`stu_id`) REFERENCES `k_users` (`user_id`),
  CONSTRAINT `k_students_FK` FOREIGN KEY (`student_prof`) REFERENCES `k_professors` (`prof_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_students`
--

LOCK TABLES `k_students` WRITE;
/*!40000 ALTER TABLE `k_students` DISABLE KEYS */;
INSERT INTO `k_students` VALUES ('00000000',NULL,NULL,1,2,'재학',NULL,'0',NULL),('00103086',NULL,NULL,3,2,'재학','00265609','0',NULL),('00149383',NULL,NULL,4,2,'재학','00217253','0',NULL),('00149776',NULL,NULL,1,2,'재학','00265609','0',NULL),('01103888',NULL,NULL,2,2,'재학','00217253','0',NULL),('01115942',NULL,NULL,3,2,'재학','00217253','0',NULL),('01119665',NULL,NULL,4,2,'재학',NULL,'0',NULL),('01132538',NULL,NULL,1,2,'재학','00265609','0',NULL),('01174314','2001-04-01',NULL,2,1,NULL,NULL,'0',NULL),('11123456','2011-03-01',NULL,2,1,'재학',NULL,'0',NULL),('11123789','2011-09-01',NULL,2,1,'재학',NULL,'0',NULL),('test123',NULL,NULL,3,1,'재학','00265609','0','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiIxMTAxMDEyNDI2Iiwic2NvcGUiOlsiaW5xdWlyeSIsImxvZ2luIiwidHJhbnNmZXIiXSwiaXNzIjoiaHR0cHM6Ly93d3cub3BlbmJhbmtpbmcub3Iua3IiLCJleHAiOjE2NzAzODM3NzIsImp0aSI6IjUwZjk2OTBmLTVjNjctNDE5Mi04MTNjLWU1ZTJhYThmYmY1ZCJ9.GIm1pP-mHdOy53xgtyL2U2K2S3EVzpurB9dV5KmZN4Q');
/*!40000 ALTER TABLE `k_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_users`
--

DROP TABLE IF EXISTS `k_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_users` (
  `user_id` varchar(100) NOT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_ssn` varchar(100) DEFAULT NULL,
  `user_sex` varchar(100) DEFAULT NULL,
  `user_dept` varchar(100) DEFAULT NULL,
  `user_addr` varchar(500) DEFAULT NULL,
  `user_phone` varchar(100) DEFAULT NULL,
  `user_email` varchar(500) DEFAULT NULL,
  `user_pw` varchar(100) DEFAULT NULL,
  `user_nation` varchar(100) DEFAULT NULL,
  `user_pic` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_users`
--

LOCK TABLES `k_users` WRITE;
/*!40000 ALTER TABLE `k_users` DISABLE KEYS */;
INSERT INTO `k_users` VALUES ('00000000','ROLE_STU','김용현','001122-3333333','M','컴퓨터공학과','달서구 이곡동','010-7396-9969','mus5607@naver.com','$2a$10$dzznctHUqEoOFqed5BtWFOa2Y/JPTcRBU40.xbwe.KCugNvgd4yYC','대한민국',NULL),('00103086','ROLE_STU','송믿음','810603-1432965','M','물리학과','경상남도 창원시 의창구 창이대로113번길 9-1 (명서동, 부산상가)','290-823-3740','bsurcombea6@samsung.com','$2a$10$7HGFkVIS6boPYEEYMm6AfusJlpfFK8XUayT8IWL1ujZYFjv.Aw.IK','대한민국',NULL),('00149383','ROLE_STU','노혁','810717-2063168','F','경영학과','부산광역시 연제구 토곡로 70 (연산동, 부산광역시 창의융합교육원)','965-264-6151','abastickcm@loc.gov','A9zPObeY1','대한민국',NULL),('00149776','ROLE_STU','윤샘','790814-2555244','F','체육학과','경상남도 함양군 안의면 광풍로 117 (안의면, 대구실비)','857-851-7733','xbirkmyre1w@exblog.jp','PDun85w','대한민국',NULL),('00217253','ROLE_PROF','배리','530829-2424464','F','철학과','경상북도 울진군 울진읍 읍내로 3 (울진읍, 대구모텔)','411-364-1115','acarverhilldc@quantcast.com','9gORyvusefy4','대한민국',NULL),('00265609','ROLE_PROF','신기원','681226-2282172','F','사회복지학과','경상북도 울진군 근남면 성류굴로 213 (근남면, 대구식당)','852-657-4821','hworvell5g@paypal.com','dDvglSCG','대한민국',NULL),('01101225','ROLE_STU','봉우원','801020-1111590','M','수학과','제주특별자치도 서귀포시 중정로61번길 8-1 (서귀동, 서울왕만두)','643-625-6708','hiles7b@tripod.com','0Mc2N90v','대한민국',NULL),('01103888','ROLE_STU','Martine','800727-1262731','M','언어학과','세종특별자치시 국책연구원5로 12','759-424-6415','mmartine4i@accuweather.com','RhBNQcmU1OF','Japan',NULL),('01115942','ROLE_STU','Creedland','790720-2398448','F','체육학과','경상남도 양산시 다방길 3 (다방동, 부산우유)','694-776-8562','ccreedland5@uiuc.edu','kjwN6KGn6riY','Portugal',NULL),('01119665','ROLE_STU','허린','810701-2313878','F','컴퓨터공학과','경상북도 김천시 대항면 황악로 1444 (대항면, 대구슈퍼)','479-709-6694','arothman9s@geocities.com','Q4kR18soABGG','대한민국',NULL),('01132538','ROLE_STU','양빛나','790725-2789155','F','사회복지학과','경상남도 거창군 거창읍 거창대로 5-1 (거창읍, 부산공업사)','903-571-9514','mpage8b@friendfeed.com','TJ2ZZ0','대한민국',NULL),('01152457','ROLE_STU','배민정','811029-2551112','F','경영학과','서울특별시 서초구 남부순환로 2248 (방배동, 서울시교원연수원)','674-637-0374','njeremaesaa@friendfeed.com','sDhYGv','대한민국',NULL),('01158956','ROLE_STU','안강민','810404-2616060','F','의류학과','충청남도 천안시 동남구 목천읍 천정2길 97 (목천읍, 대전충남양돈농협)','954-844-4728','bpellew5k@guardian.co.uk','Iz06IhutgM','대한민국',NULL),('01170739','ROLE_STU','Paulley','820617-1036918','M','기계공학과','경기도 광주시 경안천로 139 (송정동, 광주시농민단체회관)','605-736-5006','epaulley3w@wisc.edu','KnTvZGf','China',NULL),('01174314','ROLE_STU','권서하','790225-1568647','M','사회학과','경상남도 창원시 진해구 여좌로58번길 2 (여좌동, 부산식육점)','754-250-8379','emyattaq@netwoeafvertising.org','$2a$10$8E.l0YPTJ.ozMt9XixQVqOo8y6IDt6IMCKDV50TqfMylMMVpROF1i','대한민국',NULL),('01187591','ROLE_STU','임웅','811226-1235062','M','경영학과','경상북도 경주시 외동읍 석계산업단지길 66-53 (외동읍, 대구테크)','399-475-4795','fsheerin7s@aboutads.info','DXGLUClgHe1F','대한민국',NULL),('02103984','ROLE_STU','정철','800119-1569375','M','언론정보학과','경상남도 양산시 상북면 상북중앙로 437 (상북면, 부산일보)','194-106-8930','mmcbeth7x@efawef','t74S87EWr6wX','대한민국',NULL),('02116466','ROLE_STU','전다솜','831106-1310936','M','체육학과','대전광역시 중구 학고개로34번길 56-1 (옥계동, 대구빌라)','746-630-7937','ssilverwooda@chronoengine.com','AAfxCaLCu','대한민국',NULL),('02137760','ROLE_STU','Slaght','820919-1300409','M','통계학과','대전광역시 동구 송촌남로11번길 116 (용전동, 대전문학관)','668-512-2755','cslaghtbb@amazon.de','08RAkqq','Canada',NULL),('02169057','ROLE_STU','남궁나영','801030-2162270','F','사회복지학과','경상남도 양산시 양산대로 931 (신기동, 대구은행)','820-258-1403','tlyndea0@reference.com','4Snno40KjtO','대한민국',NULL),('02185384','ROLE_STU','예서현','820220-1147080','M','언론정보학과','경상남도 사천시 벌용길 75 (벌리동, 서울우유)','661-520-0252','larmell6j@cloudflare.com','7oWKeCR','대한민국',NULL),('02186866','ROLE_STU','정재희','820728-1728175','M','물리학과','전라남도 담양군 대전면 대치8길 28-12 (대전면, 대전시장)','447-193-5239','mmallison3u@arizona.edu','LH26daCSz0zO','대한민국',NULL),('02281628','ROLE_PROF','장미연','690611-1652428','M','언론정보학과','경상남도 함안군 대산면 대산중앙로 206-2 (대산면, 서울스토아)','479-167-1921','hmcgraylea1@opera.com','QmgTvb','대한민국',NULL),('02298076','ROLE_PROF','류웅','550330-1613584','M','물리학과','경상남도 양산시 하북면 신평남부길 63 (하북면, 부산갈비)','370-412-6137','pburnsellcu@dmoz.org','j8aNuUPBnR4b','대한민국',NULL),('02345196','ROLE_ADMIN','박광','600530-2084287','F','인사','서울특별시 강동구 명일로 243 (길동, 서울시산림조합빌딩)','829-805-3631','ttuson4t@amazon.com','$2a$10$dzznctHUqEoOFqed5BtWFOa2Y/JPTcRBU40.xbwe.KCugNvgd4yYC','대한민국',NULL),('03104778','ROLE_STU','장봄','840808-1868807','M','심리학과','인천광역시 미추홀구 길파로35번길 26-1 (주안동, 대로빌라)','269-420-5257','dmccurlye62@infoseek.co.jp','uA3bRoPAX','대한민국',NULL),('03115387','ROLE_STU','설달래','810404-2719911','F','사회복지학과','충청북도 청주시 서원구 궁뜰로67번길 4 (장성동, 대구산업)','737-672-7728','msussans8e@histats.com','UFjNuAEPiB','대한민국',NULL),('03139643','ROLE_STU','Jeggo','821220-2287257','F','경영학과','경상남도 창원시 진해구 명제로109번길 7 (죽곡동, 부산식당)','195-314-5388','bjeggo5h@people.com.cn','MZ8vXr5dX8','Zambia',NULL),('03149991','ROLE_STU','유아람','810111-1211625','M','국어국문학과','강원도 양양군 양양읍 동해대로 3017 (양양읍)','916-275-4289','lkinworthy7l@fc2.com','jamYJpJUDXJT','대한민국',NULL),('03158946','ROLE_STU','노남규','830212-2131846','F','통계학과','대전광역시 동구 대전로791번길 31-1 (중동, 대전식당)','104-884-7028','smcblain9u@tinyurl.com','DfyutHgeDY','대한민국',NULL),('03159576','ROLE_STU','제갈철','820221-1248159','M','컴퓨터공학과','경기도 광주시 파발로 202 (탄벌동, 광주시노인복지회관)','514-504-8233','sashboltaw@google.fr','LTvoKO','대한민국',NULL),('03167791','ROLE_STU','박혜린','820407-2018866','F','영어영문학과','경상북도 문경시 중앙로 53 (모전동, 대구유리)','652-324-7592','mecclestone6i@theguardian.com','VqBaE0','대한민국',NULL),('03169863','ROLE_STU','조일성','840718-2551084','F','사회복지학과','경상남도 거제시 사등면 가조서로 241 (사등면, 서울수산)','396-941-6149','acavell6x@senate.gov','Is8Lie','대한민국',NULL),('03176290','ROLE_STU','백별','830128-2395112','F','수학과','광주광역시 동구 제봉로82번길 13-8 (서석동, 광주광역시 남자청소년쉼터 어깨동무)','282-477-0934','cdalbydk@yahoo.co.jp','s0tmmrW90f4R','대한민국',NULL),('03180530','ROLE_STU','Grigorio','831220-1622346','M','체육학과','경상남도 창원시 진해구 충장로 156-2 (충무동, 대구여인숙)','927-253-8146','sgrigoriocc@e-recht24.de','iQmKHOwwU4','Czech Republic',NULL),('03205116','ROLE_PROF','류상','650102-1406849','M','사회학과','대전광역시 동구 계족로 277 (소제동, 대전목공소)','925-959-6780','lrushworth1o@loc.gov','$2a$10$8E.l0YPTJ.ozMt9XixQVqOo8y6IDt6IMCKDV50TqfMylMMVpROF1i','대한민국',NULL),('03253506','ROLE_PROF','제갈사랑','621116-1787384','M','경영학과','제주특별자치도 서귀포시 중정로91번길 30 (서귀동, 서울족탕)','573-157-0542','rphillott21@cdc.gov','bfGa48V','대한민국',NULL),('03279944','ROLE_PROF','Coronas','630129-2476716','F','언어학과','부산광역시 강서구 녹산산단382로14번길 55 (송정동, 부산광역시 신발산업진흥센타)','835-956-3178','tcoronasc3@dagondesign.com','M7FPvOewpL','Philippines',NULL),('04102650','ROLE_STU','설건','820212-2946240','F','철학과','경상남도 양산시 상북면 수서로 503-40 (상북면, 부산로지스)','191-232-5408','hbrood54@dmoz.org','WKECu9k81','대한민국',NULL),('04106983','ROLE_STU','장철','841015-2548733','F','심리학과','제주특별자치도 서귀포시 남원읍 중산간동로 6597 (남원읍, 서울농장)','713-839-2076','ssweetland7m@arizona.edu','vFaLIjb0N','대한민국',NULL),('04114599','ROLE_STU','남궁샛별','830404-2863425','F','사회복지학과','전라남도 강진군 대구면 수동길 11 (대구면, 대구우체국)','848-476-3618','apatten1u@is.gd','xRoeQ4oNllNc','대한민국',NULL),('04117070','ROLE_STU','예달','830424-1367655','M','컴퓨터공학과','경상북도 울진군 북면 장터길 113 (북면, 대구식당)','852-517-8425','vsaleway5t@1688.com','mA6q0Q9','대한민국',NULL),('04121831','ROLE_STU','황보하현','830701-2523230','F','건축학과','경상남도 양산시 하북면 신평강변3길 17-15 (하북면, 부산집)','956-664-9249','paliman92@amazon.co.jp','O9VK9G','대한민국',NULL),('04125213','ROLE_STU','Forder','820928-2720056','F','사회복지학과','서울특별시 영등포구 문래로 121 (문래동3가, 서울특별시 남부교육지원청)','805-595-8512','rforder9w@wsj.com','aLwMPhcg','Malaysia',NULL),('04133177','ROLE_STU','황종연','820308-1270499','M','언어학과','광주광역시 서구 무진대로 584 (유촌동, 광주광역시 보건환경연구원)','166-428-7947','kpordallbw@salon.com','ZhxdcZF8gTw5','대한민국',NULL),('04165954','ROLE_STU','Sandy','840403-2667383','F','컴퓨터공학과','경상북도 문경시 중앙로 50-3 (모전동, 대구약국)','956-741-4543','ksandy3y@twitpic.com','qZ1Pd5pNh','Czech Republic',NULL),('04182065','ROLE_STU','예달','850913-2800087','F','경영학과','강원도 양양군 현남면 동해대로 849-31 (현남면)','314-429-1876','aschermick15@cargocollective.com','oozrzwXDzw','대한민국',NULL),('04256872','ROLE_PROF','Pattillo','701026-1231811','M','통계학과','제주특별자치도 서귀포시 표선면 표선관정로 97 (표선면, 서울약국)','884-256-9556','cpattilloz@google.ru','UpihdAzLL','Sweden',NULL),('04291160','ROLE_PROF','복남순','580319-1509109','M','통계학과','강원도 동해시 느릅재길 2 (발한동, 대구먹거리)','203-290-0643','meam2s@spiegel.de','PiWFb7gf','대한민국',NULL),('04345712','ROLE_ADMIN','탁남순','660730-1984040','M','인사','경상남도 남해군 미조면 미조로236번길 30 (미조면, 서울이발관)','579-643-0857','hcardillop@ted.com','k2FPDNXN8cw','대한민국',NULL),('05120221','ROLE_STU','제갈요한','851221-2573082','F','철학과','강원도 동해시 동문산1길 6 (발한동, 대전한복)','700-299-6618','vreinbeckdl@rediff.com','iN4d7qEGT','대한민국',NULL),('05134454','ROLE_STU','노이수','840413-1711674','M','언론정보학과','경상남도 양산시 북정5길 14 (북정동, 서울우유)','478-825-2263','kholywellch@vinaora.com','uj8kJNQT4Ot','대한민국',NULL),('05151227','ROLE_STU','Downer','860507-2336352','F','체육학과','대전광역시 동구 대전로 838 (정동, 대전DFC)','498-418-1104','randrysiak55@spiegel.de','vb7d1oaJ','대한민국',NULL),('05190097','ROLE_STU','Tale','840219-2362907','F','건축학과','경상남도 통영시 항남3길 20 (항남동, 서울삼겹살)','516-741-4874','ktale4n@moonfruit.com','8jy9Ju3GDv','United States',NULL),('05193283','ROLE_STU','전믿음','850107-2213547','F','심리학과','경상북도 영양군 입암면 신구2길 17-5 (입암면, 대전식당)','797-285-6617','efarloecn@globo.com','xZGA6lD','대한민국',NULL),('05205405','ROLE_PROF','Theunissen','660921-2177952','F','언어학과','경상남도 산청군 산청읍 꽃봉산로91번길 23-2 (산청읍, 부산침구)','458-707-8244','htheunissen3r@ebay.com','kc23kT','China',NULL),('05237415','ROLE_PROF','안경구','661219-2315915','F','심리학과','경상남도 양산시 하북면 신평강변4길 6 (하북면, 서울뚝배기)','179-522-8539','acalvard95@stanford.edu','u62VeH','대한민국',NULL),('05348590','ROLE_ADMIN','황보건','611215-1916731','M','재무','경상남도 양산시 원동면 영포안길 33-8 (원동면, 부산일보)','846-603-7749','rbrandonbv@amazon.co.uk','UPRMOfpAS','대한민국',NULL),('06107937','ROLE_STU','풍성','840421-2189988','F','사회학과','인천광역시 서구 봉수대로 336 (석남동, 봉수대로주유소)','738-261-1996','bmathyscs@bigcartel.com','ZFMSywQl3s','대한민국',NULL),('06130692','ROLE_STU','최호','861129-1883796','M','컴퓨터공학과','경상남도 양산시 다방길 29 (다방동, 부산밧데리)','933-420-7593','kcunliffe3x@scientificamerican.com','CdSALz1wc','대한민국',NULL),('06139948','ROLE_STU','노철순','850604-1669705','M','기계공학과','경상남도 통영시 안개2길 26 (무전동, 서울빌딩)','850-198-2583','thinstridgebi@so-net.ne.jp','ZM8eFCD','대한민국',NULL),('06144158','ROLE_STU','오믿음','841024-2945677','F','철학과','부산광역시 동구 고관로 64 (초량동, 부산시의사회관)','979-129-4105','nchillistone7v@usatoday.com','tohtp0xS2Iwu','대한민국',NULL),('06160685','ROLE_STU','봉지해','860903-1998142','M','영어영문학과','전라남도 순천시 서면 대구1구길 129 (서면, 대구교회)','605-290-0414','jgirodon8j@nymag.com','OZlyhF','대한민국',NULL),('06162353','ROLE_STU','문철희','870320-2806703','F','건축학과','강원도 춘천시 신동면 순환대로 20-10 (신동면)','323-829-8446','nrushton3e@dagondesign.com','etVOhdvjDy4','대한민국',NULL),('06171730','ROLE_STU','송경님','850423-1285376','M','의류학과','경상남도 거제시 장목면 거제북로 1212 (장목면, 대로빌3)','270-766-0953','bwaple90@bandcamp.com','kmqaDPk2Hl9T','대한민국',NULL),('06198626','ROLE_STU','심아름','840906-2699415','F','경영학과','서울특별시 중구 소파로4길 6 (예장동, 서울특별시 건강가정 지원센터)','341-354-1908','rdemaria5f@blogspot.com','ID2WPZ7TTgHu','대한민국',NULL),('06200595','ROLE_PROF','표으뜸','651016-2152979','F','심리학과','경상남도 의령군 칠곡면 칠곡로 67-1 (칠곡면, 부산우유)','116-605-2733','aaire91@wix.com','mWuN7pF','대한민국',NULL),('06281484','ROLE_PROF','설그루','610813-2936806','F','심리학과','대전광역시 대덕구 대전로 1215 (오정동, 대전병원)','417-935-4068','kfissenden24@youku.com','B5eDjHhNYgq','대한민국',NULL),('06283617','ROLE_PROF','남나비','730703-2503814','F','기계공학과','부산광역시 수영구 광일로 8-6 (광안동, 대로해도지빌)','282-631-2461','jvardenbu@people.com.cn','C2ea378','대한민국',NULL),('07100951','ROLE_STU','박영신','870712-1037140','M','수학과','경상남도 사천시 건어시장길 23 (선구동, 서울식품)','953-983-0341','acarped4@etsy.com','VvIbiEWIQ1','대한민국',NULL),('07126054','ROLE_STU','손지석','870716-2058812','F','심리학과','대구광역시 달서구 학산남로 66 (상인동, 대구광역시 유아교육진흥원)','887-584-8158','rdesouzac6@amazon.co.jp','YpuyBjILG4e','대한민국',NULL),('07139702','ROLE_STU','허믿음','870603-1045562','M','수학과','부산광역시 사상구 모라로6번길 7 (삼락동, 대전공업사)','913-512-2970','bfrusher3p@irs.gov','lzsFcd','대한민국',NULL),('07144726','ROLE_STU','Bazoche','870924-2117572','F','통계학과','대전광역시 유성구 도안대로 398 (상대동, 대전역사박물관)','723-519-3545','rbazoche1j@cam.ac.uk','sX9H1DlP4','Mauritius',NULL),('07165230','ROLE_STU','서재섭','880903-2495047','F','건축학과','대전광역시 대덕구 대화로32번길 279 (대화동, 대전아스콘)','889-218-7213','hhedditch8n@independent.co.uk','9zJuATm2','대한민국',NULL),('07169336','ROLE_STU','정나라우람','881211-2886042','F','체육학과','부산광역시 강서구 명지오션시티10로 61 (명지동, 부산시차량등록사업소)','959-131-6101','moreilly7u@tamu.edu','sD96jzdI','대한민국',NULL),('07178184','ROLE_STU','이은','881001-1712080','M','심리학과','경상남도 남해군 남해읍 화전로 161 (남해읍, 서울우유)','920-664-4499','ejayam@samsung.com','OXElDi0E','대한민국',NULL),('07183946','ROLE_STU','조은석','881220-2914287','F','언론정보학과','경상남도 거창군 거창읍 대평5길 8 (거창읍, 대구오토바이)','868-903-1635','rhullyer78@webs.com','v6ypgkg','대한민국',NULL),('07185991','ROLE_STU','풍호','850724-1562606','M','언론정보학과','충청남도 천안시 동남구 쌍용대로 142 (봉명동, 쌍용대로주유소)','725-520-5409','ehaithwaitel@time.com','PgZkFlPgc','대한민국',NULL),('07231165','ROLE_PROF','MacShirrie','640201-1955295','M','영어영문학과','경상남도 함안군 군북면 중암5길 14 (군북면, 부산건강원)','810-941-2079','pmacshirrieb@dropbox.com','2wfswhqU','Indonesia',NULL),('07277873','ROLE_PROF','손미란','600419-1805160','M','사회학과','전라북도 익산시 무왕로 1178 (부송동, 대로주유소)','653-760-0628','rslograve4p@google.fr','Kgq0pum','대한민국',NULL),('07291274','ROLE_PROF','문한샘','690905-2782275','F','언론정보학과','서울특별시 관악구 낙성대로 101 (봉천동, 서울시과학전시관)','442-406-8184','nparminter9i@google.nl','7Zg2FWzs','대한민국',NULL),('07299522','ROLE_PROF','사공다솜','650621-1184914','M','의류학과','제주특별자치도 서귀포시 대정읍 상모로 325 (대정읍, 서울약국)','844-649-4150','mclaffeye@yellowpages.com','JgIuUCsU','대한민국',NULL),('08101138','ROLE_STU','김담비','871120-2979479','F','언어학과','대구광역시 서구 달서로12길 29-47 (비산동, 대로파크빌)','434-561-1755','jhuot7n@yahoo.com','h2V1A2dIXRb','대한민국',NULL),('08107051','ROLE_STU','하홍자','880926-2533521','F','국어국문학과','경상북도 청송군 부남면 한앞길 47 (부남면, 대전2리경로당)','320-660-4531','fmcmeekinb0@blogs.com','sUzIQQ3l9Q','대한민국',NULL),('08110595','ROLE_STU','황비','860324-1576520','M','기계공학과','경상남도 통영시 도산면 도산일주로 19 (도산면, 부산식당)','524-254-3127','ldohrmann45@tamu.edu','Q4eIF2mCU','대한민국',NULL),('08112846','ROLE_STU','추지해','890222-2921836','F','사회학과','경상남도 함안군 가야읍 함마대로 1594 (가야읍, 대로식당)','458-239-6387','tyole2w@newsvine.com','PoBkq2J85UG','대한민국',NULL),('08113217','ROLE_STU','최요한','861225-1842530','M','컴퓨터공학과','서울특별시 용산구 원효로53가길 24 (원효로2가, 대로빌)','660-252-3151','smarstersbp@elpais.com','RYVM1GxI','대한민국',NULL),('08123476','ROLE_STU','최성','870122-1702743','M','사회복지학과','울산광역시 남구 대학로5번길 11 (무거동, 대로전원파크)','529-366-4412','meyam7z@sina.com.cn','2ENDTi','대한민국',NULL),('08126264','ROLE_STU','권광','871119-1372032','M','경영학과','경기도 남양주시 화도읍 북한강로 1711-34 (화도읍, 대로참숯가마)','913-916-9366','hweymontbr@etsy.com','fVK6RjcUzj','대한민국',NULL),('08138949','ROLE_STU','제갈현','860601-2989288','F','사회학과','경상남도 하동군 하동읍 중앙로 60 (하동읍, 서울신문)','915-952-2753','boreilly72@jalbum.net','USfZLpB0e','대한민국',NULL),('08142585','ROLE_STU','정린','860318-2085933','F','의류학과','경상남도 함안군 칠원읍 서남길 32 (칠원읍, 서울한복)','212-703-8173','sstoadc9@chronoengine.com','VQRgUNQO','대한민국',NULL),('08150892','ROLE_STU','최승헌','880806-2398441','F','철학과','경기도 광주시 이배재로 16 (탄벌동, 한국국토정보공사 광주시지사)','852-784-2395','jrapseybx@typepad.com','j9XWFW','대한민국',NULL),('08157899','ROLE_STU','복한샘','861201-2935481','F','언어학과','서울특별시 성동구 청계천로 500 (마장동, 서울시 청운복지관)','703-211-0911','aantonat3s@umich.edu','gP1yaIbAW3On','대한민국',NULL),('08161294','ROLE_STU','심성','890827-2600015','F','기계공학과','강원도 평창군 대화면 평창대로 770-2 (대화면)','215-474-1240','cpoluzzib4@nps.gov','FzmJEW3S4','대한민국',NULL),('08172305','ROLE_STU','김재','860907-1117968','M','의류학과','대전광역시 서구 계룡로 314 (갈마동, 대전일보사)','486-925-5122','snudds6w@123-reg.co.uk','KEmoKWiB9Ei','대한민국',NULL),('08268070','ROLE_PROF','정란','730609-1640817','M','컴퓨터공학과','경상남도 하동군 하동읍 시장1길 20-4 (하동읍, 대구제유)','347-365-3068','hchezier1@examiner.com','$2a$10$8E.l0YPTJ.ozMt9XixQVqOo8y6IDt6IMCKDV50TqfMylMMVpROF1i','대한민국',NULL),('08287004','ROLE_PROF','정호','601216-1442099','M','영어영문학과','경상남도 양산시 용주로 87 (용당동, 부산도시락)','973-306-2151','ymackonochie3g@homestead.com','3sORtYe4','대한민국',NULL),('08291798','ROLE_PROF','유힘찬','750313-2146809','F','국어국문학과','충청남도 천안시 동남구 대흥로 25 (구성동, 대전지방보훈청)','918-904-4943','nbuntine5o@sina.com.cn','WmqyIi0','대한민국',NULL),('08349236','ROLE_ADMIN','전경모','600624-2833137','F','인사','경기도 광주시 파발로 194 (경안동, 광주시 보건소)','845-433-6475','umcpartlind7@woothemes.com','JxLCbs0JOaE','대한민국',NULL),('08374220','ROLE_ADMIN','사공성한','640809-1963851','M','인사','울산광역시 남구 삼호로207번길 3-9 (무거동, 대로빌라)','670-374-1071','ddedhambg@blogtalkradio.com','5PU6eoIKk','대한민국',NULL),('09103045','ROLE_STU','사공영철','881222-2799936','F','언론정보학과','강원도 춘천시 동내면 순환대로 561 (동내면)','301-355-7624','jvasyutkinal@fda.gov','9xih7NzR','대한민국',NULL),('09110058','ROLE_STU','박초롱','890711-2179707','F','사회복지학과','경상남도 창원시 의창구 차룡단지로 35 (팔용동, 부산정밀)','485-398-3383','awhooleyd2@fda.gov','MccYZdVXTh2D','대한민국',NULL),('09169569','ROLE_STU','최웅','870426-2900511','F','언론정보학과','부산광역시 북구 만덕대로155번길 99-1 (덕천동, 부산광역시 건설기술교육원)','355-667-5978','pwarrener22@deliciousdays.com','j7ej3j','대한민국',NULL),('09181881','ROLE_STU','성민서','890909-2037595','F','철학과','대전광역시 대덕구 대화로32번길 293 (대화동, 대전아스콘)','784-418-3150','cmackartanbm@nhs.uk','gr1uMm','대한민국',NULL),('09339494','ROLE_ADMIN','조진','750704-2226609','F','기획','충청북도 영동군 추풍령면 작점로 16-1 (추풍령면, 대구막창)','900-428-8710','mjohnsey73@disqus.com','zYd75c','대한민국',NULL),('09376772','ROLE_ADMIN','홍현승','710510-2509397','F','기획','충청북도 보은군 마로면 관기3길 6-5 (마로면, 대전지업사)','947-405-0962','tmccluinj@nifty.com','dqRFhvqbQ','대한민국',NULL),('09379449','ROLE_ADMIN','장지해','640812-1273585','M','재무','대구광역시 동구 동촌로 73 (검사동, 대구광역시 농.특산품 전시판매장)','771-634-5615','brosenbloom81@liveinternet.ru','sKt2sRWqdDXD','대한민국',NULL),('10101105','ROLE_STU','남궁일성','900313-2577110','F','의류학과','대구광역시 달서구 성당로 187 (성당동, 대구광역시 종합복지회관)','146-144-1132','tcassels7p@behance.net','xKR5hXMkY','대한민국',NULL),('10135925','ROLE_STU','서경재','911002-2372148','F','컴퓨터공학과','경상남도 통영시 서문로 30 (문화동, 부산일보)','139-490-9480','asabatesao@tinyurl.com','1EnDAtuihM5','대한민국',NULL),('10147216','ROLE_STU','고우리','901014-1312164','M','통계학과','충청남도 천안시 동남구 영성로 84 (오룡동, 대전상호저축은행)','292-357-7815','bchampken3z@biblegateway.com','WKIO0ma1h3WN','대한민국',NULL),('10156422','ROLE_STU','최은','880614-2403170','F','수학과','강원도 동해시 동해대로 4835 (이도동, 동해 석미아데나 더퍼스트)','268-903-1393','rhosburn9f@scientificamerican.com','E26EBy','대한민국',NULL),('10173865','ROLE_STU','예훈','890801-1915195','M','사회학과','경상남도 함안군 군북면 월촌안길 38 (군북면, 대구식당)','178-171-9105','bbilbyds@slate.com','k7qOvn','대한민국',NULL),('10175411','ROLE_STU','고여진','880919-2068744','F','통계학과','강원도 고성군 현내면 동해대로 9051 (현내면)','144-105-5431','smattholiea4@squidoo.com','M9t9XKKRLjxx','대한민국',NULL),('10188712','ROLE_STU','Ferriere','880205-1015985','M','사회학과','경상북도 포항시 북구 흥해읍 한동로 25 (흥해읍, 대구은행)','473-843-8771','bferriere8i@usa.gov','GTqfog1VNDbQ','Brazil',NULL),('10245479','ROLE_PROF','Carnaman','680607-2348347','F','언론정보학과','경상남도 남해군 설천면 노량로183번길 20 (설천면, 대구횟집)','679-220-6215','vcarnamand3@gnu.org','4F3wjm8hJe1','Indonesia',NULL),('10271715','ROLE_PROF','표혜림','660620-2098327','F','기계공학과','경상남도 양산시 덕계로 32 (덕계동, 서울깍두기)','906-609-2538','nthompson34@discuz.net','N7L0Xg3TQCO8','대한민국',NULL),('10278966','ROLE_PROF','Catt','740523-2710954','F','영어영문학과','강원도 삼척시 도계읍 도계로 337 (도계읍, 대구식육점)','146-650-3771','gcatt96@google.pl','pD5YTplEx7B','Ivory Coast',NULL),('10298843','ROLE_PROF','오빛가람','670804-2294629','F','사회복지학과','경기도 고양시 덕양구 통일로 504 (대자동, 서울시장묘사업소)','648-346-8585','mchamberlen1p@washingtonpost.com','iUME7wSpSi','대한민국',NULL),('11118142','ROLE_STU','정재','900212-1424423','M','통계학과','경상북도 문경시 중앙시장1길 4-12 (점촌동, 대구상회)','771-132-4416','mecob2x@amazon.co.jp','bnQxGwy0UxE','대한민국',NULL),('11123456','ROLE_STU','박찬호','910401-2123456','F','영어영문학과','충청북도 단양군 어상천면 대전2길 20-3 (어상천면, 대전2리경로당)','010-1111-2222','pch@ajefaw.com','$2a$10$zKFX6Yi6Uk1.9jv.zDhDjeLDli1MbWd1sMuB76jNDWzwHQ83xPJiK','대한민국','11123456.jpg'),('11123789','ROLE_STU','김삿갓','910401-1123456','M','물리학과','경상북도 봉화군 춘양면 의양로5길 7-10 (춘양면, 대구상회)','010-1111-2222','4pch2@ajefaw.com','$2a$10$/uvskmwfNZFn/74GBqbfO.JrloNX5e/KU.oYzAzA9oLrxjaL4YQf.','대한민국','11123789.jpg'),('11126385','ROLE_STU','Dale','900703-2036889','F','수학과','경상남도 양산시 상북면 반회서3길 16-14 (상북면, 서울우유)','469-846-0987','adale2c@guardian.co.uk','Vz0mR1oF4','France',NULL),('11135820','ROLE_STU','설은채','910126-2425184','F','국어국문학과','부산광역시 강서구 화전산단6로 35 (화전동, 부산시기계공업협동조합)','773-161-3634','ljapp8k@marriott.com','40XqLp','대한민국',NULL),('11155787','ROLE_STU','탁우람','920904-1500124','M','통계학과','경상남도 의령군 의령읍 의병로20길 20-3 (의령읍, 대구식육점)','529-230-0755','lperocciak@nydailynews.com','DtJ8yPQ27','대한민국',NULL),('11155891','ROLE_STU','양현우','920222-2426979','F','사회복지학과','경상남도 사천시 문선7길 24-21 (벌리동, 서울삼계탕)','134-466-7687','dstanneringcw@youtube.com','mXi2WVXDkYlU','대한민국',NULL),('11175038','ROLE_STU','노태환','920525-1551572','M','통계학과','대전광역시 중구 학고개로34번길 58 (옥계동, 대구빌라)','126-433-0399','pbothencj@cyberchimps.com','uRV8WknzObx','대한민국',NULL),('11184366','ROLE_STU','표태식','910826-1799771','M','경영학과','전라남도 무안군 삼향읍 삼일로 362 (삼향읍, 대로회집)','664-426-6082','sfarlamc1@aefwef','yC1QeXpR','대한민국',NULL),('11185346','ROLE_STU','류호','921207-1818648','M','의류학과','경상북도 영천시 대창면 금창로 691 (대창면, 대구약국)','353-993-8857','jphifer2m@naver.com','Xedig4NF','대한민국',NULL),('11186205','ROLE_STU','하민서','891008-1249144','M','의류학과','전라북도 남원시 요천로 1742 (월락동, 대로갈비)','261-888-3432','fhodginsag@mayoclinic.com','z2y5J0sh','대한민국',NULL),('11210096','ROLE_PROF','문이경','720928-2025032','F','의류학과','경상남도 창원시 의창구 차상로72번길 11-1 (팔용동, 부산국밥)','212-404-5862','lrolfs6q@dyndns.org','WvdZeVy8yzw','대한민국',NULL),('11236532','ROLE_PROF','탁경택','750806-2415613','F','의류학과','경상남도 창원시 의창구 원이대로285번길 11 (봉곡동, 서울상가)','353-858-0518','ytabourin16@technorati.com','YqG7WXl','대한민국',NULL),('11245302','ROLE_PROF','Petrusch','720521-2373475','F','수학과','강원도 평창군 방림면 평창대로 264-3 (방림면)','847-509-3428','epetrusch8f@com.com','XRaqTFBGX','Indonesia',NULL),('11252732','ROLE_PROF','류무영','760714-2909239','F','통계학과','경상북도 영주시 선비로 200 (영주동, 대구장식)','891-235-4197','ademattiav@about.com','Wtoh7s','대한민국',NULL),('11371696','ROLE_ADMIN','성윤자','680325-2030614','F','인사','부산광역시 서구 충무대로 229 (남부민동, 충무대로봄여름가을겨울)','692-147-5816','woguz3n@phpbb.com','oN7qmIMsD','대한민국',NULL),('12108821','ROLE_STU','Insworth','900924-2584984','F','철학과','경상북도 경산시 진량읍 대구대로 359-7 (진량읍, 대구원룸)','623-610-6709','dinsworth7h@prlog.org','COgdeG','Russia',NULL),('12110058','ROLE_STU','Brine','900418-1248941','M','국어국문학과','울산광역시 울주군 삼남읍 쌍수정1길 39 (삼남읍, 대구제면)','127-728-8964','cbrine2i@samsung.com','7dx7EKE','China',NULL),('12130744','ROLE_STU','임건','910727-2019365','F','컴퓨터공학과','경기도 광주시 회안대로 891 (송정동, 광주시문화스포츠센터)','131-261-4869','fkaradzas5z@imageshack.us','xgt5A3NG7F','대한민국',NULL),('12131053','ROLE_STU','탁솔','920812-1719220','M','언론정보학과','울산광역시 남구 대학로 152 (무거동, 대로빌딩)','462-413-0396','rmeechani@cornell.edu','eSaRWjlNM2','대한민국',NULL),('12144760','ROLE_STU','Swettenham','931009-1759115','M','영어영문학과','경상남도 양산시 장터1길 14 (중부동, 부산횟집)','606-820-7239','jswettenhamy@photobucket.com','vqdHLqg0dVL','Indonesia',NULL),('12172877','ROLE_STU','Whyard','920928-2060351','F','물리학과','충청북도 제천시 수산면 인삼로 561 (수산면, 대전분교)','887-113-5957','gwhyard2f@meetup.com','iysIiO3p','Belarus',NULL),('12188975','ROLE_STU','탁연석','911021-1709490','M','언어학과','대구광역시 남구 대명복개로1길 38 (대명동, 대구광역시 달성교육청)','945-120-4707','edysart3f@washingtonpost.com','LiPARUeHUgDF','대한민국',NULL),('12229475','ROLE_PROF','박영신','750308-1214676','M','철학과','경상북도 울진군 후포면 후포로 79-1 (후포면, 대구여관)','806-265-2067','apatrick79@jiathis.com','p3N5Af6','대한민국',NULL),('12271194','ROLE_PROF','Scipsey','780223-1529053','M','의류학과','충청북도 청주시 상당구 상당로144번길 5 (북문로2가, 대전일보충북본부)','417-498-4494','sscipsey7y@amazonaws.com','y3TMpdwmTe','Indonesia',NULL),('12294120','ROLE_PROF','전유리','710209-2966957','F','수학과','부산광역시 수영구 광남로 18 (남천동, 부산시약사신용협동조합)','154-579-0410','npretticp@netvibes.com','x18O9Kl','대한민국',NULL),('12312312','ROLE_ADMIN','김행정','751211-1765432','M','기획','강원도 춘천시 신동면 순환대로 309-90 (신동면)','010-1111-2222','11pch2@ajefaw.com','$2a$10$MgGUJaLJN80Nhuv01K5nw.n1SrJR0D0xkl.Hj3.jo7hSYs/stqKRq','대한민국','12312312.jpg'),('12345678','ROLE_ADMIN','유샛별','740581-1513513','M','인사','경상남도 양산시 옥곡3길 11 (남부동, 부산우유)','000-111-4115','teset@test.com','$2a$10$D.rEXUgDz9e9.HtUWve5WeSi7f77P8j5PqFgVFJRWtairtxY9CQ32','대한민국',NULL),('12392705','ROLE_ADMIN','고승미','750830-1193929','M','재무','경상남도 함양군 서상면 대남로 185 (서상면, 대로마을회관)','455-380-8766','fsennettcd@ox.ac.uk','PPjsTMLUG','대한민국',NULL),('13108574','ROLE_STU','윤지해','920406-1318337','M','물리학과','경상북도 예천군 예천읍 시장로 71-2 (예천읍, 대구이용원)','797-692-9211','gstovoldce@chron.com','DSNwUb','대한민국',NULL),('13113512','ROLE_STU','허재신','931111-2880116','F','의류학과','전라북도 전주시 완산구 풍남문5길 14 (전동3가, 대전여인숙)','683-594-0560','amartinsonw@google.co.jp','AQubzW','대한민국',NULL),('13137023','ROLE_STU','정버들','930313-2514781','F','언어학과','강원도 삼척시 도계읍 도계로 313-1 (도계읍, 대구철물)','883-738-0912','zlabrom2p@icq.com','odE5iPd0RQG','대한민국',NULL),('13139981','ROLE_STU','장혁','930713-1517871','M','언어학과','경상남도 양산시 물금읍 가촌동2길 40-1 (물금읍, 부산우유)','757-238-1987','olightwood46@columbia.edu','eJHbv6kqLQ','대한민국',NULL),('13186274','ROLE_STU','백나라우람','940728-2924674','F','물리학과','충청남도 금산군 추부면 승무재로 112 (추부면, 대전종균서대산)','984-764-9240','sleisman59@w3.org','jFovzg58','대한민국',NULL),('13194220','ROLE_STU','Littlejohn','910911-2130734','F','언론정보학과','경상남도 사천시 중앙시장2길 12-10 (선구동, 서울장식)','532-323-1591','llittlejohn2z@reverbnation.com','AoKm0HGl02','Ukraine',NULL),('13258522','ROLE_PROF','Dolman','690922-2276827','F','컴퓨터공학과','경상북도 영천시 금호읍 금호로 142 (금호읍, 대구농약사)','690-875-2709','gdolmandv@tamu.edu','870vjEUlqh','Uruguay',NULL),('13311712','ROLE_ADMIN','사공현승','800408-2218417','F','기획','서울특별시 영등포구 당산로51길 15 (당산동6가, 대로빌딩)','931-679-9668','mwalford9m@gov.uk','5bk2wXv','대한민국',NULL),('13314969','ROLE_ADMIN','설빛가람','660112-1678216','M','기획','부산광역시 북구 낙동대로1739번길 7 (구포동, 부산광역시 낙동강관리본부)','311-287-3372','fpetteford7c@phpbb.com','ecXUX0kAavZ','대한민국',NULL),('13385880','ROLE_ADMIN','김우람','750407-1868771','M','재무','강원도 춘천시 동면 야시대로 1645 (동면)','596-654-6226','hrudgley9x@storify.com','D3XSx1','대한민국',NULL),('14103134','ROLE_STU','백나라우람','941023-1294135','M','심리학과','강원도 양양군 양양읍 동해대로 2661-11 (양양읍, 쏠팰리스)','939-758-7336','rangears@ed.gov','Jsp6yr2qJzGL','대한민국',NULL),('14106615','ROLE_STU','최진','951203-2933100','F','사회학과','경상남도 함안군 칠원읍 구성길 26 (칠원읍, 서울미용실)','324-611-3789','khaygreen70@bravesites.com','ivtRDlP4','대한민국',NULL),('14117683','ROLE_STU','이성','940506-1066113','M','언어학과','충청남도 청양군 청양읍 중앙로12길 8-2 (청양읍, 대전일보청양총국)','673-937-5831','bbamletcy@360.cn','rnI9yFrN','대한민국',NULL),('14121313','ROLE_STU','유성','940803-1703993','M','기계공학과','대전광역시 동구 대전로 952-2 (삼성동, 대전금속)','427-104-2059','esivilbn@ehow.com','743WmADW7Umb','대한민국',NULL),('14121627','ROLE_STU','권창현','950421-2574102','F','컴퓨터공학과','제주특별자치도 서귀포시 성산읍 한도로242번길 10-13 (성산읍, 부산가든)','523-375-2146','lmuir8c@mozilla.org','4GGFbl','대한민국',NULL),('14126305','ROLE_STU','오믿음','920209-1670835','M','심리학과','서울특별시 강북구 한천로150길 6-19 (수유동, 서울시티런)','992-729-5229','mbrister7a@nydailynews.com','5F8fFXU','대한민국',NULL),('14137896','ROLE_STU','풍소연','941012-1614480','M','기계공학과','경상북도 경산시 진량읍 대추마을길9길 33 (진량읍, 대구원룸)','592-948-5617','gfarenden3o@ca.gov','BSJMOdcjv36I','대한민국',NULL),('14160233','ROLE_STU','문두리','941224-2589195','F','국어국문학과','서울특별시 성북구 정릉로6가길 3 (정릉동, 서울시녹지관리16초소)','532-597-3230','olorence87@ebay.com','dhlPbq54','대한민국',NULL),('14184145','ROLE_STU','노성','940125-1759332','M','의류학과','충청북도 단양군 대강면 사인암1길 13 (대강면, 대구민박)','764-508-5798','mjeary9q@i2i.jp','FWegDeVKwYtq','대한민국',NULL),('14210481','ROLE_PROF','설재','700916-1436131','M','물리학과','경상남도 남해군 창선면 창선로 85 (창선면, 서울미용실)','134-988-2569','hgocke4l@wordpress.org','SGKiPW4JxX','대한민국',NULL),('14234456','ROLE_PROF','임아름','780105-1423076','M','사회복지학과','경상남도 남해군 남해읍 화전로 112 (남해읍, 서울약국)','679-208-2066','dsallinger1n@reuters.com','IxImaMOZ8Fm','대한민국',NULL),('14250168','ROLE_PROF','Hartfield','820630-1723119','M','컴퓨터공학과','충청남도 서천군 비인면 비인로 179 (비인면, 대전일보)','628-224-9189','chartfield0@ibm.com','hQzeOl','China',NULL),('14268611','ROLE_PROF','임선진','790625-2318283','F','국어국문학과','경상남도 양산시 상북면 반회동7길 17 (상북면, 부산식당)','350-780-2665','sshelmerdine2u@ovh.net','LsYtwAFZ','대한민국',NULL),('14271791','ROLE_PROF','풍현승','820701-1913951','M','통계학과','경상남도 밀양시 삼랑진읍 삼랑진로 1268-50 (삼랑진읍, 부산대학교)','473-348-5984','ggorch1l@joomla.org','Rlh7JOKTJl7z','대한민국',NULL),('14272236','ROLE_PROF','문성','720109-1114394','M','사회학과','경상남도 거창군 북상면 병곡길 447-11 (북상면, 대구횟집)','250-826-7229','fbiddy8u@dyndns.org','meBLAmSB7n9','대한민국',NULL),('15106737','ROLE_STU','장건','940929-1455715','M','수학과','경상남도 사천시 장동길 20 (죽림동, 부산기업)','500-196-9773','acubbonad@cafepress.com','rgXNcKd','대한민국',NULL),('15107174','ROLE_STU','심나봄','960827-2654620','F','사회복지학과','경상남도 양산시 북정로 32 (북정동, 서울한의원)','612-209-0464','nblenkin8r@economist.com','EEc0um','대한민국',NULL),('15108668','ROLE_STU','전란','950224-2093389','F','컴퓨터공학과','충청남도 천안시 동남구 미나릿길 52-13 (영성동, 대전여인숙)','374-257-2683','erackbz@europa.eu','CeAvoW','대한민국',NULL),('15114325','ROLE_STU','최훈','961221-1954479','M','사회학과','대전광역시 대덕구 동서대로1761번길 12 (송촌동, 대전약품)','644-276-4833','gbencher8@businesswire.com','b6bjGZ','대한민국',NULL),('15118598','ROLE_STU','Benaine','930925-1295429','M','국어국문학과','전라북도 임실군 신평면 석등슬치로 352-1 (신평면, (유)대전)','758-520-9089','wbenainebs@de.vu','SukNCA','China',NULL),('15122208','ROLE_STU','정설','960705-2452835','F','건축학과','전라북도 부안군 부안읍 향교길 25 (부안읍, 부안향교대전)','426-539-5658','nbarthrop61@nationalgeographic.com','cDNinYT4','대한민국',NULL),('15127860','ROLE_STU','설영애','950722-2251184','F','경영학과','대전광역시 대덕구 아리랑로 166 (읍내동, 대전조차장)','978-683-2779','jstrevens9a@nationalgeographic.com','cgGm3j','대한민국',NULL),('15147602','ROLE_STU','탁은','930324-1776633','M','국어국문학과','경상남도 창원시 마산합포구 진북면 학동로 537-331 (진북면, 부산농원)','870-451-6187','gpeddowear@a8.net','7eOHuH8VYL','대한민국',NULL),('15223287','ROLE_PROF','박광','820725-1399928','M','철학과','경상북도 포항시 북구 송라면 보경로 724 (송라면, 대전3리회관)','202-512-6558','dtuminini29@ask.com','JlkFrR00','대한민국',NULL),('15231565','ROLE_PROF','표경완','690708-2630858','F','물리학과','경상남도 남해군 남해읍 화전로 49 (남해읍, 서울한복)','420-116-7422','cpetrasek94@bloomberg.com','msbvKbf','대한민국',NULL),('15262813','ROLE_PROF','송믿음','700713-1507126','M','영어영문학과','경상남도 거창군 거창읍 시장길 33-4 (거창읍, 부산이불)','493-734-0651','dbrand1v@miibeian.gov.cn','k5Y1DMDSOKHK','대한민국',NULL),('16101803','ROLE_STU','황보경택','970404-1839114','M','언어학과','강원도 춘천시 동내면 순환대로 766-8 (동내면)','781-718-2902','jmellor8o@wsj.com','rqSIeAYW','대한민국',NULL),('16102611','ROLE_STU','류여진','950914-1149707','M','경영학과','경상남도 창원시 진해구 용원중로5번길 6-24 (용원동, 서울깍두기)','780-875-0064','nskalad1@nih.gov','dkxPFQd','대한민국',NULL),('16110752','ROLE_STU','심오성','950710-1906733','M','건축학과','서울특별시 서초구 태봉로 131 (우면동, 서울시품질시험소)','453-632-0523','kluberto2e@mit.edu','dep3ocs6sW','대한민국',NULL),('16116861','ROLE_STU','허담비','950529-1768390','M','심리학과','경상남도 창원시 진해구 석동로39번안길 46 (석동, 부산오뎅)','975-897-7562','pslowcock9v@whitehouse.gov','r55irXSq','대한민국',NULL),('16119134','ROLE_STU','송지해','941205-1487445','M','영어영문학과','경상남도 의령군 의령읍 충익로 127 (의령읍, 대전삼계탕)','778-415-9826','tburnup6l@macromedia.com','Cb9s5NSBl','대한민국',NULL),('16122646','ROLE_STU','Haye','950428-1744237','M','건축학과','경상남도 양산시 신기로 49 (북정동, 서울밧데리)','584-339-7837','khaye6y@about.me','UnfY73xkjGBk','Yemen',NULL),('16126888','ROLE_STU','홍힘찬','950220-2440477','F','철학과','경상남도 사천시 중앙시장1길 3-1 (선구동, 부산상회)','984-523-3130','fcolbran2a@goo.gl','vzawQB','대한민국',NULL),('16137684','ROLE_STU','배리','970225-1891391','M','사회학과','대전광역시 대덕구 선비마을로 260 (법동, 대전광역시 동부여성가족원)','692-987-0634','pwinchester4z@dailymail.co.uk','iLkEbd0','대한민국',NULL),('16154463','ROLE_STU','사공으뜸','960616-1721812','M','사회학과','전라북도 남원시 솔터길 76 (광치동, 대구원룸)','392-655-8853','bfarrans6c@answers.com','tKPAXQMF','대한민국',NULL),('16156846','ROLE_STU','Thorne','950217-2457227','F','컴퓨터공학과','강원도 춘천시 동내면 순환대로 606 (동내면)','190-337-2281','fthorne12@i2i.jp','nVlIRw','Philippines',NULL),('16164305','ROLE_STU','황보광','940603-2344702','F','국어국문학과','경기도 파주시 가온로 106 (목동동, 대로프라자)','500-898-2952','pjanas1m@slideshare.net','EnALNCVrIL','대한민국',NULL),('16172972','ROLE_STU','하경택','970826-1868057','M','건축학과','경상남도 사천시 유람선길 17 (서동, 대로안전)','528-625-1838','cboog1i@bigcartel.com','3V2G4ou','대한민국',NULL),('16175208','ROLE_STU','제갈지','960109-2384517','F','통계학과','경상남도 통영시 서송정1길 8-3 (도남동, 서울영양탕)','926-205-1490','jloxdaleco@bloglovin.com','mqopeMm0','대한민국',NULL),('16180053','ROLE_STU','예희재','970806-1415913','M','컴퓨터공학과','경상남도 함양군 함양읍 용평5길 25-2 (함양읍, 부산오뎅)','988-183-2224','kianittellof@php.net','tFyfZnO','대한민국',NULL),('16180882','ROLE_STU','송진','960205-1192075','M','언론정보학과','충청남도 당진시 송악읍 복운1길 196-16 (송악읍, 대전교구복운리공소)','725-676-2137','coliverpaull3i@yelp.com','M4YfsJgaQaU','대한민국',NULL),('16197429','ROLE_STU','추누리','940422-2244311','F','체육학과','경상남도 창원시 진해구 안골로108번길 111 (안골동, 서울식당)','484-841-0490','apolferas@desdev.cn','PzBr9uBwU','대한민국',NULL),('16208163','ROLE_PROF','탁은','760916-2418523','F','건축학과','서울특별시 성동구 자동차시장길 47 (용답동, 서울시예방약품비품소)','559-874-7321','bpooly6f@ucoz.com','QKtGjzNUC','대한민국',NULL),('16234199','ROLE_PROF','복지','800230-1568759','M','언어학과','대구광역시 서구 북비산로74길 20-5 (비산동, 대로파크빌)','453-376-4949','hgehringer4u@nymag.com','nINjykh','대한민국',NULL),('16237302','ROLE_PROF','홍경구','690211-1802788','M','체육학과','경상북도 예천군 풍양면 낙상1길 47 (풍양면, 대구건업)','968-805-7765','sivanenkov3d@stumbleupon.com','QrXhyDZgcg','대한민국',NULL),('16253388','ROLE_PROF','탁달','750429-1585469','M','경영학과','강원도 춘천시 신동면 순환대로 318 (신동면)','949-614-9841','brestall1d@amazon.co.jp','v7nZeWHJE','대한민국',NULL),('16271524','ROLE_PROF','허일성','831211-2547011','F','경영학과','충청북도 괴산군 청천면 대전길 41 (청천면, 대전노인정)','770-823-7235','tleybanai@webs.com','7cbvPOWO6s','대한민국',NULL),('17120777','ROLE_STU','성철','970622-2905155','F','국어국문학과','경상북도 영주시 번영로 149 (하망동, 대구은행)','165-281-0373','jbowering71@newsvine.com','qTCxp4spFy','대한민국',NULL),('17121572','ROLE_STU','장승헌','950422-2931186','F','철학과','경상남도 의령군 의령읍 의병로20길 7-4 (의령읍, 부산미용실)','656-320-3006','glenaghen58@cargocollective.com','kADcjddW','대한민국',NULL),('17125917','ROLE_STU','황경준','960411-2957224','F','기계공학과','경상남도 남해군 설천면 노량로183번길 14-1 (설천면, 부산횟집)','252-504-2791','nakehurstu@vk.com','yrCeKKyW','대한민국',NULL),('17128399','ROLE_STU','추현','970527-1070122','M','건축학과','충청남도 아산시 온화로29번길 2 (온천동, 대구양푼이)','917-807-8842','scaverhill6d@gravatar.com','C22EqQfqUX8','대한민국',NULL),('17189569','ROLE_STU','강믿음','950822-2234951','F','언어학과','경상남도 사천시 중앙시장2길 24-3 (선구동, 서울주단)','641-339-3384','yscrivin5n@jugem.jp','dQ3gYce','대한민국',NULL),('17197614','ROLE_STU','권서하','950430-2629668','F','심리학과','경상북도 경주시 외동읍 순금1길 19 (외동읍, 대구유통)','200-497-7898','rbrideaux3t@cdc.gov','ES2yHoWACD','대한민국',NULL),('17198885','ROLE_STU','남연숙','950517-1968704','M','철학과','경상남도 함안군 칠북면 이령1길 57 (칠북면, 부산가든)','387-906-7788','nhub5u@jiathis.com','Sbhucx7cYF','대한민국',NULL),('17216720','ROLE_PROF','유미래','710630-1299655','M','언론정보학과','제주특별자치도 서귀포시 중정로 100-2 (서귀동, 대전여인숙)','625-284-6645','btimmermann53@mlb.com','jQPxRdjgx8a','대한민국',NULL),('18100892','ROLE_STU','Saintpierre','990318-1731578','M','수학과','대전광역시 동구 은어송로 95 (가오동, 대전맹학교)','261-683-0685','osaintpierrek@howstuffworks.com','4NGB8QbTw','Poland',NULL),('18103786','ROLE_STU','윤진','970702-2640880','F','물리학과','대구광역시 수성구 희망로 175 (황금동, 대구시약사회관)','662-101-3830','dfrancomdm@bloomberg.com','oRXEtt5ltt','대한민국',NULL),('18116253','ROLE_STU','장별찌','970929-1802605','M','물리학과','충청북도 제천시 수산면 인삼로 531 (수산면, 대전보건진료소)','993-714-2298','iverduin7e@google.co.uk','ZB6U85','대한민국',NULL),('18116606','ROLE_STU','홍철순','980430-1669675','M','사회복지학과','서울특별시 마포구 방울내로5길 42 (망원동, 서울특별시 청년교류공간)','802-948-5136','tlinfootcz@tumblr.com','VC08aJ','대한민국',NULL),('18119511','ROLE_STU','Marde','990204-2726954','F','건축학과','경기도 광주시 이배재로 209-5 (목현동, 광주시농업기술센터)','542-344-0231','smardedp@tuttocitta.it','iCFUAFl','Vietnam',NULL),('18139962','ROLE_STU','노은채','970204-2655329','F','언어학과','충청북도 청주시 서원구 남이면 남석로 87-9 (남이면, 대로이엔씨(주))','891-976-9811','awadie89@odnoklassniki.ru','kGPWZkB','대한민국',NULL),('18140568','ROLE_STU','문태윤','990721-2046635','F','영어영문학과','경상남도 하동군 화개면 쌍계사길 21 (화개면, 서울식당)','178-676-6258','mmulliganb3@digg.com','BviouEzQzn','대한민국',NULL),('18146593','ROLE_STU','문훈','980907-1465233','M','심리학과','경상남도 진주시 진양호로570번길 7 (장대동, 대전산업중앙빌라)','543-360-2023','ddelacostecb@unblog.fr','IaY60nD','대한민국',NULL),('18180198','ROLE_STU','서별빛','960510-1206321','M','철학과','서울특별시 중랑구 사가정로42길 21 (면목동, 대로빌딩)','294-720-6520','cashness2r@elpais.com','mL8jCm07Ey','대한민국',NULL),('18183524','ROLE_STU','심다운','980413-1634167','M','체육학과','서울특별시 마포구 방울내로5길 43 (망원동, 서울특별시 청년교류공간)','468-802-9840','tbellhousea9@webmd.com','KOw9HC','대한민국',NULL),('18199618','ROLE_STU','허무열','961220-2278895','F','영어영문학과','경상남도 창원시 진해구 충장로82번길 17 (대흥동, 서울갈비탕)','693-260-9979','nmarioneaud8@ihg.com','p3i7hOB','대한민국',NULL),('18228944','ROLE_PROF','Aspall','750315-1612641','M','기계공학과','경상남도 사천시 서부시장길 49 (동동, 서울전업사)','279-182-1197','caspall6@t.co','348IbM0','Poland',NULL),('19104187','ROLE_STU','임민서','970806-1487804','M','국어국문학과','제주특별자치도 서귀포시 안덕면 사계중앙로3번길 11 (안덕면, 사계대전경로당)','479-270-9398','jromerac7@opera.com','s7CiDsZSld','대한민국',NULL),('19109453','ROLE_STU','배강민','990702-2827700','F','의류학과','전라남도 나주시 영산포로 169-1 (이창동, 대구마트)','865-522-4261','ogebuhr8q@kickstarter.com','W6k7Qd','대한민국',NULL),('19109454','ROLE_STU','하나길','000813-2264427','F','심리학과','인천광역시 부평구 부평대로 88 (부평동, 부평대로우체국)','179-674-9011','bhopewellax@usatoday.com','uW6fGZrWk','대한민국',NULL),('19111503','ROLE_STU','허샘','980414-2175058','F','언론정보학과','경상남도 양산시 상북면 상북중앙로 411-1 (상북면, 서울목공소)','950-641-6208','bdoumenc5w@cbc.ca','PzLmQW','대한민국',NULL),('19118402','ROLE_STU','양우람','000402-2832871','F','기계공학과','전라북도 고창군 대산면 사거1길 54-3 (대산면, 대로슈퍼)','941-449-9001','cmccay6o@elpais.com','ZAPqrv','대한민국',NULL),('19136098','ROLE_STU','배경택','981118-1729181','M','영어영문학과','경기도 오산시 원동로37번길 39 (원동, 대구슈퍼)','359-298-2082','mwallis2o@geocities.com','4HT8vhP1','대한민국',NULL),('19143945','ROLE_STU','전세호','991006-2211869','F','경영학과','경기도 부천시 평천로 639 (약대동, 중동대로주유소)','200-586-4308','ejiroutkadq@nasa.gov','k6aKmbfsXD','대한민국',NULL),('19179440','ROLE_STU','Ducham','980524-1817817','M','국어국문학과','경상남도 함양군 지곡면 병곡지곡로 963 (지곡면, 대전식육식당)','103-954-7733','jducham7i@icio.us','3FXPQaaJ1KbT','Peru',NULL),('19189372','ROLE_STU','전동건','000826-1404413','M','영어영문학과','경상북도 영천시 신녕면 불바위길 4 (신녕면, 대구한의원)','920-801-3004','amiddler1g@liveinternet.ru','kPJeqe3d2Hgb','대한민국',NULL),('19192126','ROLE_STU','Aldam','980726-1330534','M','심리학과','경상북도 성주군 선남면 나선로 899 (선남면, 대구제재소)','244-993-3274','raldamc5@vkontakte.ru','zhWVHWObzaP','South Africa',NULL),('19193538','ROLE_STU','임치원','980604-1165016','M','의류학과','전라북도 고창군 대산면 대산시장길 10-3 (대산면, 대구식당)','822-118-5604','dnourse4r@fastcompany.com','jpIzjBGI','대한민국',NULL),('19285757','ROLE_PROF','Stennard','820501-1481609','M','체육학과','대전광역시 동구 대학로 62 (용운동, 대전대학교)','722-609-8847','wstennard4m@answers.com','GJNJ1YAUo','Slovenia',NULL),('20121193','ROLE_STU','양승헌','990907-2921488','F','영어영문학과','충청남도 보령시 원동2길 35 (대천동, 대전일보보령지국)','432-536-1349','awichard6k@is.gd','AvGdSxt','대한민국',NULL),('20123808','ROLE_STU','Fouracres','011218-1327103','M','기계공학과','제주특별자치도 서귀포시 중앙로 22 (서귀동, 서울감자탕)','222-209-2669','nfouracresab@youku.com','iLLCr5JPPtEz','Russia',NULL),('20141374','ROLE_STU','조철','980622-2745963','F','통계학과','경상남도 창원시 진해구 충장로364번가길 1 (이동, 서울포차)','298-147-0069','pcoskerry8d@fastcompany.com','SV00ruHMA3','대한민국',NULL),('20142248','ROLE_STU','Alleyn','980712-2426541','F','물리학과','서울특별시 영등포구 도림로 145 (대림동, 서울시남부도로사업소)','214-927-7118','galleyn7k@deviantart.com','mQdSZpp4k1','China',NULL),('20144609','ROLE_STU','Tzar','990825-2878765','F','통계학과','경상남도 거창군 거창읍 주곡로 504-20 (거창읍, 대전식당)','684-500-5212','ptzar85@tiny.cc','i2JXE0e1uKv3','China',NULL),('20155510','ROLE_STU','남은샘','000217-2420427','F','기계공학과','충청남도 청양군 목면 안심길 177-4 (목면, 대전노인회목면분회)','999-394-2108','sbage63@jiathis.com','MFGWr2DysB','대한민국',NULL),('20165495','ROLE_STU','남빛가람','000722-2915942','F','물리학과','충청남도 보령시 해수욕장2길 19 (신흑동, 서울시학생교육원대천임해수련분원)','501-538-6107','atrillow23@meetup.com','H6lmlTQS','대한민국',NULL),('20165528','ROLE_STU','예철순','981002-1094393','M','언론정보학과','경상남도 진주시 큰들로150번길 10 (상평동, 부산원룸)','680-821-8883','dbradtkex@blogs.com','g1GcQHLUic01','대한민국',NULL),('20165868','ROLE_STU','황주원','010105-2611964','F','건축학과','경상남도 사천시 사천읍 시장1길 8 (사천읍, 서울상회)','697-986-0410','dsinkings3h@theguardian.com','wcObJOmwphhv','대한민국',NULL),('20166057','ROLE_STU','Shevelin','981204-1133842','M','사회복지학과','광주광역시 서구 학생독립로 37 (화정동, 광주광역시 청소년수련원, 청소년극장)','922-936-6365','eshevelin28@arizona.edu','VkNoVf5K','Sweden',NULL),('20173769','ROLE_STU','문힘찬','000321-2539273','F','물리학과','충청남도 천안시 동남구 충절로 200 (원성동, 대로약국)','441-369-6646','tdevalci@abc.net.au','4htf3RZi7z2','대한민국',NULL),('20178628','ROLE_STU','최광조','980715-1467485','M','경영학과','경상남도 거창군 거창읍 중앙로 123-5 (거창읍, 부산식당)','166-288-7386','afaughnyn@google.com.hk','l3u8ey','대한민국',NULL),('20179587','ROLE_STU','장성','000428-2339288','F','체육학과','부산광역시 부산진구 화지로 12 (양정동, 부산시교육청)','619-948-2793','fscaife51@sohu.com','BFaSnq2','대한민국',NULL),('20187183','ROLE_STU','Refford','990912-1155322','M','건축학과','대전광역시 대덕구 새말3길 29 (상서동, 대전크랑크)','150-708-3152','mrefford4y@usatoday.com','3l2vpypjsl7P','Argentina',NULL),('20240291','ROLE_PROF','표한샘','850905-1578039','M','국어국문학과','강원도 춘천시 신동면 순환대로 20-12 (신동면)','177-729-7657','hellsom2q@usnews.com','N4LaigNtl','대한민국',NULL),('20255121','ROLE_PROF','박호','830705-1244125','M','언어학과','경상북도 경주시 다불로 7 (용강동, 대구은행)','176-895-3123','gblinco1f@surveymonkey.com','Uuaky7','대한민국',NULL),('20256648','ROLE_PROF','최리','790230-2425732','F','체육학과','강원도 영월군 주천면 평창강로 59 (주천면, 서울특별시 교육청 영월 야영교육장)','370-636-9512','hjimeno5i@issuu.com','eXc1r0Yrd','대한민국',NULL),('21105406','ROLE_STU','송남순','011112-2905350','F','체육학과','경상남도 의령군 의령읍 의병로 167-6 (의령읍, 서울우유)','116-370-3992','sbernardotti44@bravesites.com','dmdHAB0u','대한민국',NULL),('21118400','ROLE_STU','허보라','001113-1881107','M','언어학과','강원도 화천군 화천읍 중앙로7길 14 (화천읍, 대구방앗간)','865-791-3167','mfrankish4f@yahoo.com','4clnkib02e','대한민국',NULL),('21118677','ROLE_STU','정치원','010225-1927662','M','기계공학과','경상남도 통영시 멘데산업길 131 (정량동, 부산상회)','757-846-3424','schevis7o@latimes.com','8hy0bY0','대한민국',NULL),('21124593','ROLE_STU','박찬호','011228-2615200','F','영어영문학과','대구광역시 동구 동촌로 325 (신평동, 대한노인회 대구광역시 동구지회)','998-833-0983','rditchfieldbe@nba.com','Q0Szzdhlaw1','대한민국',NULL),('21149494','ROLE_STU','백지','021213-2123857','F','사회학과','부산광역시 동구 수정공원북로 13 (수정동, 부산시동구대한노인회)','429-540-8214','crosencrantz48@hugedomains.com','vbLn1lBEIr','대한민국',NULL),('21150011','ROLE_STU','복승재','001229-1928082','M','체육학과','경상남도 양산시 주남로 65 (주남동, 부산우유)','149-146-0397','crau6v@huffingtonpost.com','o7bEkG','대한민국',NULL),('21164493','ROLE_STU','Cresser','990824-1396994','M','영어영문학과','대전광역시 중구 수도산로 9 (대흥동, 대전중학교)','585-341-0644','dcresser77@time.com','JQBjMFA','China',NULL),('21212121','ROLE_PROF','박박사','791120-1004909','M','수학과','경상남도 양산시 상북면 상북중앙로 81 (상북면, 대구슈퍼)','298-191-3841','gduggeth@irs.gov','$2a$10$2CDDaqUcVkuSxWI5vGIXl.MTfoPGHpnFKcaDdOt5LzsZTdg8s8VGC','대한민국','21212121.jpg'),('21216968','ROLE_PROF','손한결','870727-1034907','M','건축학과','전라북도 익산시 함열읍 와리3길 31 (함열읍, 대전의상실)','289-585-2115','eghidini82@alibaba.com','x6xIlQ','대한민국',NULL),('21265836','ROLE_PROF','황보형','870919-2354289','F','건축학과','울산광역시 북구 안시례길 22 (시례동, 대전기업)','614-822-0016','frannie1z@wsj.com','Nhss0hZwEwh5','대한민국',NULL),('22102082','ROLE_STU','Giraudo','001124-2209936','F','물리학과','강원도 동해시 일출로 215 (어달동, 대구민박)','179-623-3744','ggiraudob1@zimbio.com','slaVlKmgTK','Indonesia',NULL),('22122035','ROLE_STU','한효은','031023-2686410','F','수학과','경상북도 경산시 계양로8길 13 (계양동, 대구빌라)','773-545-8096','mphelips52@businessinsider.com','pOv0jVoS2KVb','대한민국',NULL),('22145097','ROLE_STU','하태호','030401-2508304','F','통계학과','경상남도 사천시 곤명면 완사3길 57 (곤명면, 부산우유)','472-839-4639','khowerd2@freewebs.com','2CqXQF0VmW6','대한민국',NULL),('22145874','ROLE_STU','Tollett','000211-2294555','F','수학과','전라남도 강진군 대구면 청자로 1827 (대구면, 대구파출소)','492-360-6782','atollettd@hud.gov','CJduFD0ke5G','Indonesia',NULL),('22151829','ROLE_STU','유여진','001213-1055783','M','영어영문학과','대전광역시 서구 월평로13번길 23 (월평동, 대전빌라)','811-813-7803','mrawsen14@webs.com','FEo3Sos','대한민국',NULL),('22156790','ROLE_STU','황광조','030602-1436594','M','수학과','경상북도 경주시 외동읍 석계산업단지길 66-51 (외동읍, 대구산업)','621-278-4798','jedginton37@mediafire.com','Qo2bWCgPMm','대한민국',NULL),('22173886','ROLE_STU','권광','011030-2620520','F','의류학과','경상남도 창원시 마산회원구 봉양로 190 (봉암동, 부산은행)','706-678-2548','estiddard3v@drupal.org','L4hv8VYj28','대한민국',NULL),('22175972','ROLE_STU','송호','000608-2015667','F','사회학과','전라남도 고흥군 두원면 두원로 1168 (두원면, 대전보건진료소)','649-705-9121','wtissell8s@weibo.com','bgwyW6Qh','대한민국',NULL),('22186694','ROLE_STU','Malins','031030-2167617','F','철학과','대전광역시 대덕구 새말3길 28 (상서동, 대전크랑크)','416-681-6086','mmalins4w@mayoclinic.com','xq5H0XM7Y3','Albania',NULL),('22266199','ROLE_PROF','정미르','890103-1154551','M','철학과','경기도 성남시 중원구 여수대로 182 (여수동, 서울시도시철도공사모란기지사업소)','215-266-6964','jgrabert26@java.com','vzNIkayQe','대한민국',NULL),('95101804','ROLE_STU','Weekland','760319-1862181','M','영어영문학과','강원도 강릉시 강동면 동해대로 2003-22 (강동면)','968-720-6495','gweeklandd9@bandcamp.com','qKvqnxTrT','Russia',NULL),('95103515','ROLE_STU','홍희훈','750510-1007219','M','심리학과','서울특별시 마포구 월드컵로 251 (성산동, 서울시생활체육협의회)','820-509-0277','obraverybd@cyberchimps.com','SpgqkE4Tpb','대한민국',NULL),('95108044','ROLE_STU','Sheirlaw','730409-1317800','M','철학과','경상남도 남해군 설천면 노량로195번길 10 (설천면, 서울횟집)','769-734-2891','hsheirlaw5r@istockphoto.com','brukPdXCaqC','Iran',NULL),('95108789','ROLE_STU','조훈','760422-2714755','F','심리학과','서울특별시 강서구 화곡로 217-5 (화곡동, 우성대로빌라)','117-425-5202','ashorland17@utexas.edu','bu4Pszalbb6','대한민국',NULL),('95109682','ROLE_STU','강빛가람','760306-1526715','M','통계학과','경기도 오산시 역광장로 70-3 (오산동, 대전여인숙)','420-593-7648','kcuttler9b@house.gov','MM9dSHjs','대한민국',NULL),('95109757','ROLE_STU','Varley','731021-1057603','M','체육학과','서울특별시 영등포구 버드나루로18길 5 (당산동, 서울시의사회)','205-757-9726','cvarley97@netvibes.com','CZrqvDTu4','Malaysia',NULL),('95110536','ROLE_STU','손태연','740818-1770863','M','통계학과','경상남도 하동군 화개면 석문길 8 (화개면, 부산식당)','472-977-0029','ckenny5b@goodreads.com','uItxFxWI','대한민국',NULL),('95112934','ROLE_STU','사공린','731027-2076475','F','경영학과','경상남도 사천시 사천읍 동구밖길 34 (사천읍, 부산학원)','297-960-6914','kdrews5d@booking.com','Un3kP7M','대한민국',NULL),('95113162','ROLE_STU','남궁건','750401-2487197','F','심리학과','제주특별자치도 서귀포시 대정읍 하모상가로 18-2 (대정읍, 대전여인숙)','106-408-7338','msymcoxe32@indiegogo.com','BEtvFrj','대한민국',NULL),('95113717','ROLE_STU','박은정','761018-2444970','F','기계공학과','경상남도 통영시 사량면 내지길 22 (사량면, 부산민박)','666-597-6178','bbenoist5c@alibaba.com','fzNMqDG3v','대한민국',NULL),('95115760','ROLE_STU','김훈','761120-2479706','F','기계공학과','대구광역시 서구 달서로36길 17 (비산동, 대로하이츠3차)','713-978-2358','asilversmid1h@macromedia.com','8QkDewRL','대한민국',NULL),('95120617','ROLE_STU','김노을','760908-1448976','M','컴퓨터공학과','경기도 화성시 정남면 괘랑1길8번길 4 (정남면, 대로 그린빌라)','368-708-8057','msnipeb9@arizona.edu','O34lmlWOME','대한민국',NULL),('95122232','ROLE_STU','노달','761226-2182161','F','통계학과','울산광역시 남구 왕생로10번길 6 (달동, 대로빌라)','783-974-8067','kgonet49@1und1.de','9bfamvXeyVu','대한민국',NULL),('95123056','ROLE_STU','노한길','750221-1493270','M','체육학과','강원도 춘천시 신동면 순환대로 316 (신동면)','583-224-7691','kdonetbh@guardian.co.uk','xAZfyiic','대한민국',NULL),('95123959','ROLE_STU','표미희','740728-2821842','F','언어학과','충청남도 천안시 서북구 불당3길 19 (불당동, 대구뽈테기)','456-306-9293','twarfield8t@cbsnews.com','45AcTPoI','대한민국',NULL),('95125678','ROLE_STU','서한길','750222-2306225','F','영어영문학과','경기도 광주시 회안대로 350-17 (태전동, 광주시 청소년수련관)','492-697-3996','yeager4d@dell.com','06bBwT1GG','대한민국',NULL),('95127891','ROLE_STU','박린','751201-1124329','M','기계공학과','경상남도 양산시 웅상대로 1392 (삼호동, 부산철제)','128-194-4443','cbroadway8m@list-manage.com','3Hru1zMYQ','대한민국',NULL),('95137834','ROLE_STU','김병헌','740506-1542870','M','사회복지학과','충청남도 공주시 반포면 가마봉길 100 (반포면, 대전교육연수원)','491-994-4433','ifaunch8p@rakuten.co.jp','xK7XRIBC','대한민국',NULL),('95138318','ROLE_STU','전치원','750101-2698478','F','의류학과','경상남도 사천시 서부시장길 65 (동동, 서울한약방)','225-899-2211','iholdin6z@live.com','RCCIg6F1L9','대한민국',NULL),('95139429','ROLE_STU','박은채','760706-1532399','M','경영학과','경기도 광주시 행정타운로 49-3 (송정동, 광주시선거관리위원회)','535-913-6117','teaganb5@phpbb.com','vNR7UAtEz4bC','대한민국',NULL),('95139516','ROLE_STU','하나라','760410-1747318','M','사회학과','전라북도 정읍시 내장산로 930-10 (내장동, 동동주 대전회관)','302-354-8789','cwallege5p@tinyurl.com','1MiZQjJA','대한민국',NULL),('95141366','ROLE_STU','오여진','740314-2732283','F','통계학과','충청북도 충주시 주덕읍 참샘길 120 (주덕읍, 대로산업(주))','291-407-8906','mgarricdt@ftc.gov','EmZpAqQj4','대한민국',NULL),('95142246','ROLE_STU','양철','760330-1799453','M','건축학과','충청남도 당진시 합덕읍 합우로 49 (합덕읍, 대구농원)','548-525-8859','fdulton10@digg.com','1HbkXdMLEEy','대한민국',NULL),('95144098','ROLE_STU','황보성한','740224-2971204','F','수학과','경상남도 의령군 의령읍 수암로 33 (의령읍, 서울우유)','270-496-1212','mmelburyck@nyu.edu','H3mcY3YX','대한민국',NULL),('95144718','ROLE_STU','오지','730604-2261563','F','기계공학과','경기도 화성시 정남면 괘랑1길8번길 4-1 (정남면, 대로 그린빌라)','814-947-1855','rturbitt35@newyorker.com','r1RHaA','대한민국',NULL),('95151093','ROLE_STU','봉무영','760514-2274670','F','사회복지학과','경상남도 창원시 성산구 원이대로580번길 21 (중앙동, 서울식당)','355-649-5961','rarmitage64@china.com.cn','zXdJnNpdTlG','대한민국',NULL),('95155237','ROLE_STU','남애정','730901-1650119','M','물리학과','충청북도 단양군 영춘면 별방만종로 608 (영춘면, 대전식당)','860-500-4783','aphilippsohn1a@multiply.com','Cu98po','대한민국',NULL),('95157160','ROLE_STU','안두리','740118-2698184','F','경영학과','강원도 양양군 현남면 동해대로 849-39 (현남면)','172-220-7078','gmcmeekan5m@prnewswire.com','qrj2epy','대한민국',NULL),('95157895','ROLE_STU','Cheltnam','740601-1597310','M','국어국문학과','경상남도 사천시 중앙시장2길 12-12 (선구동, 부산잡화상회)','950-809-7637','rcheltnamdr@com.com','rCU9K8VXBi','Ukraine',NULL),('95161609','ROLE_STU','성나비','730809-1193900','M','언어학과','경상북도 영덕군 남정면 진불1길 5 (남정면, 대구모텔)','259-442-6750','bmacfadden7f@tmall.com','BvY1IjJug','대한민국',NULL),('95161791','ROLE_STU','권유리','750921-2918517','F','컴퓨터공학과','경기도 남양주시 화도읍 모꼬지로17번길 48-74 (화도읍, 서울특별시 학생교육원 대성리교육원)','977-290-6221','mdeblasidj@live.com','DrXpoOfEWINu','대한민국',NULL),('95166464','ROLE_STU','Weyman','731221-2153934','F','언론정보학과','경상남도 양산시 연호12길 31-9 (삼호동, 부산복집)','316-145-7475','rweyman9c@seesaa.net','da3Mgj8hFw63','Philippines',NULL),('95167558','ROLE_STU','허혁','740415-1778146','M','심리학과','경상북도 예천군 예천읍 군청길 15-11 (예천읍, 대구슈퍼)','971-431-3994','kmercer4a@ft.com','twerekCQ','대한민국',NULL),('95167636','ROLE_STU','Hassen','730712-1213491','M','사회학과','충청남도 보령시 웅천읍 충서로 977-30 (웅천읍, 대전석재)','282-719-2204','fhassen86@xing.com','qyo1bgR1Gq4t','Czech Republic',NULL),('95169217','ROLE_STU','조새벽','740324-2411288','F','수학과','충청남도 보령시 한내로 28 (동대동, 대로빌딩)','443-175-5556','kbertot5e@constantcontact.com','mFgZSuSF0p','대한민국',NULL),('95172962','ROLE_STU','봉빛가람','740919-1781467','M','영어영문학과','경상북도 영주시 구성로349번길 22 (영주동, 대구곡물상회)','850-553-0005','dlewcock4k@ed.gov','B2RSbQ','대한민국',NULL),('95174087','ROLE_STU','손지','760121-2338588','F','언어학과','전라북도 익산시 고봉로18길 79-14 (영등동, 대로빌라)','584-371-5796','afellibrand2v@topsy.com','yjsomng','대한민국',NULL),('95175773','ROLE_STU','김덕수','740718-1232261','M','의류학과','강원도 춘천시 동내면 순환대로 608 (동내면)','428-188-7797','egallally27@myspace.com','3LRAcRDn','대한민국',NULL),('95177465','ROLE_STU','임린','730111-2521876','F','통계학과','부산광역시 연제구 토곡로 74 (연산동, 부산광역시 영재교육진흥원)','319-615-1561','nbrech8z@nsw.gov.au','5Wq6rbOw','대한민국',NULL),('95180310','ROLE_STU','홍미르','760505-2706260','F','물리학과','충청북도 충주시 동량면 사천후동길 29 (동량면, 대전교회)','783-686-5951','rsegrott1k@cyberchimps.com','09zzsqAk','대한민국',NULL),('95181146','ROLE_STU','Adaway','751021-1866126','M','언어학과','경상남도 사천시 사천읍 평화2길 6 (사천읍, 서울설렁탕)','836-813-7978','vadaway7r@ifeng.com','nHLRH5WNZT','France',NULL),('95186008','ROLE_STU','Esley','750701-1047479','M','언어학과','경기도 포천시 신읍2길 10-10 (신읍동, 대로빌라)','788-551-1207','hesley3k@1und1.de','GtGNiPIWq','China',NULL),('95186689','ROLE_STU','손상','740206-1638091','M','기계공학과','경상남도 함안군 가야읍 가야로 40 (가야읍, 서울안과)','907-705-6264','abanville3c@harvard.edu','r11ghq','대한민국',NULL),('95195955','ROLE_STU','황훈','730328-2236345','F','철학과','대전광역시 중구 사정공원로 70 (사정동, 대전동물원)','153-725-2655','kpoundford5v@lycos.com','bXEfwZ','대한민국',NULL),('95197851','ROLE_STU','Blazi','760622-2841407','F','심리학과','경상남도 사천시 사천읍 동성길 7-1 (사천읍, 서울식당)','586-421-5157','mblazi13@army.mil','dR3Efj0LcYhE','Brazil',NULL),('95217606','ROLE_PROF','손용욱','621022-1238801','M','체육학과','경상북도 예천군 용궁면 용궁로 146-8 (용궁면, 대구철공소)','897-908-1860','afurst2t@quantcast.com','xZ5HFFuM','대한민국',NULL),('95228603','ROLE_PROF','Eefting','490326-2733694','F','언론정보학과','전라북도 군산시 내항2길 149 (금동, 대전횟집)','726-842-0267','seefting5q@unblog.fr','4e1SeC','Poland',NULL),('95246667','ROLE_PROF','풍혁','480114-1861265','M','경영학과','경상남도 남해군 삼동면 동부대로942번길 40-2 (삼동면, 서울상회)','583-417-8600','bambler2j@cdbaby.com','suygRW7','대한민국',NULL),('95249409','ROLE_PROF','성광식','540930-2427193','F','통계학과','울산광역시 북구 화봉로 125 (연암동, 대구식품)','913-501-6394','droskamsc2@slate.com','A1oStPiSmfM8','대한민국',NULL),('95263449','ROLE_PROF','Lemmon','600709-1917209','M','기계공학과','경상남도 남해군 창선면 창선로 70 (창선면, 서울이불)','771-782-7149','blemmona3@discovery.com','mQVH4L','Mauritius',NULL),('95271428','ROLE_PROF','유남규','561017-2794735','F','국어국문학과','경상남도 밀양시 부북면 운전1길 7 (부북면, 대전회관)','660-575-1772','dbrealey39@paginegialle.it','UycyfU','대한민국',NULL),('95276513','ROLE_PROF','정린','600222-1502362','M','물리학과','강원도 삼척시 근덕면 삼척로 2125 (근덕면, 대전회타운)','429-154-7840','kheelis9k@bravesites.com','NsVsUc','대한민국',NULL),('95296459','ROLE_PROF','추현','601209-2209453','F','의류학과','경상남도 창원시 의창구 대산면 모산길 17 (대산면, 부산횟집)','851-239-0760','rcicchinelli56@icq.com','s4kQNBfU','대한민국',NULL),('95299906','ROLE_PROF','탁한별','480209-2835638','F','체육학과','경상남도 진주시 남강로959번길 10 (상평동, 서울빌라)','485-459-4492','kcowden5j@barnesandnoble.com','JYaDe7','대한민국',NULL),('96101273','ROLE_STU','하채윤','770612-1723166','M','국어국문학과','강원도 홍천군 화촌면 야시대로 907 (화촌면)','788-583-3379','mbyrkmyrb6@omniture.com','ZuLvN9','대한민국',NULL),('96101431','ROLE_STU','설해남','750621-2060244','F','사회복지학과','대구광역시 남구 대명로 29 (대명동, 대구광역시 시설관리공단)','326-155-9363','lmaccracken9z@clickbank.net','S6NCz6W','대한민국',NULL),('96102369','ROLE_STU','예가영','750703-2750627','F','물리학과','경상남도 거창군 신원면 신차로 3050 (신원면, 부산철물)','220-523-6853','odarycott50@taobao.com','mwj3c2VAN2W7','대한민국',NULL),('96102476','ROLE_STU','풍가을','761019-2287740','F','경영학과','경상남도 함양군 안의면 종로길 28 (안의면, 부산천막)','790-200-5533','pkellickde@php.net','7QrDK7','대한민국',NULL),('96109664','ROLE_STU','Wickenden','750412-2242052','F','사회학과','강원도 평창군 대화면 평창대로 536-6 (대화면)','574-861-5469','cwickendenm@cocolog-nifty.com','bVaOOBXrSh','Russia',NULL),('96112210','ROLE_STU','배민들레','760305-2678959','F','사회학과','경상남도 통영시 항남1번가길 12 (항남동, 서울치과)','205-724-4011','nkohlert25@independent.co.uk','3iZK4Ce2','대한민국',NULL),('96115369','ROLE_STU','하달','761117-1017358','M','건축학과','세종특별자치시 전의면 가톨릭대학로 30','499-925-5546','hjoseyau@amazon.de','QhPUY9Suw','대한민국',NULL),('96122544','ROLE_STU','Cooke','740626-1585102','M','물리학과','부산광역시 사하구 다대동로8번길 40 (다대동, 부산시수협다대공판장)','340-979-7191','dcookeq@mac.com','BXMjQ69mRP3','Philippines',NULL),('96124567','ROLE_STU','정담비','741210-1107804','M','국어국문학과','경상남도 창원시 진해구 용재로67번길 11 (용원동, 부산원룸)','942-600-7924','rdowner4b@histats.com','m1ALXpbN','대한민국',NULL),('96131880','ROLE_STU','송재','760628-1480998','M','수학과','충청남도 금산군 금산읍 인삼약초로 4 (금산읍, 대전한약방)','833-531-7367','vshallcrass2l@google.es','XBSKjS3a','대한민국',NULL),('96133704','ROLE_STU','Caldicot','750718-2565768','F','건축학과','대구광역시 북구 구암로 155 (동천동, 대구광역시 동천소방관 파출소)','657-510-3025','acaldicot3b@google.de','OCbtKw0','Colombia',NULL),('96140559','ROLE_STU','제갈다솜','740128-1160208','M','건축학과','인천광역시 옹진군 영흥면 내동로 183 (영흥면, 서울특별시 향교재단 연수원)','241-636-9103','mlepruvostbk@ftc.gov','T2dI0JECcid','대한민국',NULL),('96140562','ROLE_STU','하미란','751006-2739034','F','수학과','경상남도 창원시 마산회원구 합성서11길 22 (합성동, 대구여인숙)','778-714-2146','cwoonton20@epa.gov','vQdEys','대한민국',NULL),('96141370','ROLE_STU','한미래','770313-1607556','M','컴퓨터공학과','경기도 광주시 포은대로 692-6 (장지동, 광주시차량등록사업소)','778-687-8461','lmohring40@elegantthemes.com','qyGQlPnvvxU','대한민국',NULL),('96141738','ROLE_STU','서일성','751018-1936076','M','체육학과','강원도 삼척시 원덕읍 호산중앙로 5-66 (원덕읍, 대구상회)','406-934-0713','swinstone93@cbslocal.com','1AI3hdfh1z','대한민국',NULL),('96143888','ROLE_STU','임으뜸','770824-1141716','M','물리학과','강원도 철원군 서면 와수로 29-10 (서면, 대로 목장)','909-651-0888','nmaccoveney4q@discovery.com','FmaW6HOD','대한민국',NULL),('96145460','ROLE_STU','홍믿음','740816-2955402','F','컴퓨터공학과','서울특별시 중구 세종대로 125 (태평로1가, 서울시의회)','187-372-0216','gtribella8@angelfire.com','ApjmpG62Cj','대한민국',NULL),('96148872','ROLE_STU','노건','750213-2519573','F','컴퓨터공학과','경상북도 영주시 광복로24번길 5 (영주동, 대구오락실)','327-772-8198','aschulze7d@live.com','T47Y6MOP8e','대한민국',NULL),('96158904','ROLE_STU','이빛가람','770308-1212758','M','기계공학과','충청북도 단양군 어상천면 어상천로 972 (어상천면, 대전식당식육점)','425-236-4027','mkenwortheyac@shareasale.com','FxjVJam','대한민국',NULL),('96162208','ROLE_STU','강선호','740708-2524159','F','의류학과','부산광역시 중구 용미길10번길 1 (남포동1가, 부산시수협)','121-894-0212','llintallaf@vistaprint.com','sOXrZhgfkvR','대한민국',NULL),('96163840','ROLE_STU','서다래','760313-2130052','F','국어국문학과','부산광역시 해운대구 수영강변대로 590 (반여동, 부산광안대로주유소)','738-288-5175','utreherne8v@newyorker.com','R5kmEKk','대한민국',NULL),('96163982','ROLE_STU','윤남순','740502-2920942','F','심리학과','강원도 양양군 현북면 동해대로 1536-14 (현북면)','391-628-3404','ahatfull4s@naver.com','CvsnuPA','대한민국',NULL),('96172390','ROLE_STU','Rotte','750117-2841499','F','국어국문학과','강원도 동해시 동해대로 5453 (평릉동)','887-566-0978','grotte3m@xing.com','sT0vmVnMc','Philippines',NULL),('96174387','ROLE_STU','한연희','760827-2184799','F','통계학과','경상남도 통영시 중앙시장2길 11 (중앙동, 부산상회)','525-861-6540','lolyunina5@msn.com','1NpuJwKe','대한민국',NULL),('96181248','ROLE_STU','성상','760614-2665319','F','철학과','경상남도 창원시 진해구 신항4로 15-82 (용원동, 부산크로스독)','346-435-0851','vnolton6g@devhub.com','laD8GJI1Y','대한민국',NULL),('96182990','ROLE_STU','허영식','770406-2243867','F','체육학과','전라남도 해남군 현산면 시등리길 52 (현산면, 대구양복점)','663-781-6957','ldeatta9n@home.pl','Zku3HKIfQFWd','대한민국',NULL),('96183431','ROLE_STU','Andreazzi','760707-1791544','M','심리학과','강원도 평창군 용평면 평창대로 1742-8 (용평면)','689-238-5576','aandreazzi2b@ox.ac.uk','rjnhSe','Indonesia',NULL),('96185360','ROLE_STU','복버들','760307-1890624','M','언론정보학과','강원도 철원군 동송읍 이평1로45번길 12 (동송읍, 대구슈퍼)','214-191-9816','mdulsonct@jiathis.com','SKCCarZq67','대한민국',NULL),('96185555','ROLE_STU','권버들','761211-1254115','M','수학과','제주특별자치도 서귀포시 칠십리로 383 (보목동, 부산천막)','759-893-7804','dohanessian2n@umn.edu','at83NNReT','대한민국',NULL),('96188434','ROLE_STU','하병헌','770306-1361264','M','국어국문학과','대전광역시 동구 대전천동로 508 (원동, 대전광역시 청소년위캔센터)','254-893-1171','ajeannaud7t@un.org','UqJ0S2b','대한민국',NULL),('96190596','ROLE_STU','송혜빈','750711-2732076','F','컴퓨터공학과','경상남도 양산시 중앙로 99 (남부동, 부산식당)','982-624-6249','wloan83@wikimedia.org','acXmEf','대한민국',NULL),('96193666','ROLE_STU','노두리','740120-1619670','M','언론정보학과','충청남도 서산시 대산읍 영좌동길 120 (대산읍, 대로3리마을회관)','892-677-2608','dfellini3q@mtv.com','x1Pey2EwfUV','대한민국',NULL),('96194151','ROLE_STU','임재인','751030-1819882','M','언어학과','서울특별시 구로구 개봉로11길 38-7 (개봉동, 대로홈맨션)','375-636-2690','sdukes68@theguardian.com','J3T4hUU','대한민국',NULL),('96196690','ROLE_STU','풍정자','761026-2335860','F','사회복지학과','경상남도 창원시 진해구 용재로29번길 12-1 (용원동, 서울미용실)','614-310-9360','scorder4c@webeden.co.uk','jq1GYoiexuGh','대한민국',NULL),('96197424','ROLE_STU','류다운','750715-2087610','F','심리학과','경상북도 예천군 호명면 도청대로 201 (호명면, 대구은행)','780-477-8481','lmatchett4x@pinterest.com','pPbMR8BoN9','대한민국',NULL),('96200943','ROLE_PROF','임나라우람','580908-2983595','F','영어영문학과','경상남도 창원시 마산합포구 동서북10길 3 (부림동, 부산일보)','407-724-5110','nbirchall1s@themeforest.net','snVmdXKPj','대한민국',NULL),('96237399','ROLE_PROF','송경구','481124-2923686','F','사회복지학과','경상북도 영천시 시청로 28 (문외동, 대구은행)','969-484-2909','ifrankel31@samsung.com','fp8dzxC','대한민국',NULL),('96238195','ROLE_PROF','남연석','520324-1903339','M','국어국문학과','강원도 춘천시 신동면 순환대로 309-112 (신동면)','866-400-8745','agalpen3@creativecommons.org','qpNuYLKG','대한민국',NULL),('96251345','ROLE_PROF','김민지','540525-2125601','F','기계공학과','경상남도 거창군 위천면 원학길 419 (위천면, 대로축산작업장)','894-430-1403','fvossbf@multiply.com','g8fXACCtyt20','대한민국',NULL),('96261823','ROLE_PROF','Tzarkov','491104-2690317','F','영어영문학과','서울특별시 성동구 천호대로78길 15-48 (용답동, 서울시투자기관교육복지통합센터)','995-954-5049','rtzarkov1e@sphinn.com','SAd0ATalNWz3','France',NULL),('96266948','ROLE_PROF','강동우','591029-2578353','F','물리학과','경상남도 하동군 적량면 대티길 6 (적량면, 부산식당)','503-290-5695','ryouhillcr@godaddy.com','r96xJKGd6Jbg','대한민국',NULL),('96282034','ROLE_PROF','박성빈','630101-2965731','F','수학과','경상남도 남해군 미조면 미송로 14 (미조면, 부산낚시)','382-379-7826','rscrannager@mlb.com','VyXIOAeK','대한민국',NULL),('96285904','ROLE_PROF','하숙자','530420-2456717','F','수학과','대전광역시 동구 계족로 395 (성남동, 대전연와)','881-426-4158','ibartot1x@cornell.edu','Gt9tw29WkBF','대한민국',NULL),('96299428','ROLE_PROF','남은일','620614-1901807','M','기계공학과','경기도 과천시 장군마을3길 30 (주암동, 서울시보건환경연구원)','712-688-5174','lboulde4g@google.com.br','Zlgbqyti','대한민국',NULL),('97100631','ROLE_STU','허혁','771120-1310479','M','건축학과','충청북도 충주시 동량면 내동1길 19 (동량면, 대전보건진료소)','408-838-2509','fkrikorianb2@goodreads.com','lgIG5RXP','대한민국',NULL),('97104783','ROLE_STU','송다솜','760903-1766794','M','철학과','강원도 춘천시 동내면 순환대로 575 (동내면)','802-445-6149','lgillivrie6p@tiny.cc','NHh2fclF','대한민국',NULL),('97107569','ROLE_STU','송란','781104-1427438','M','통계학과','충청남도 금산군 금산읍 금산천1길 79-1 (금산읍, 대전철물설비)','331-307-5873','ebottoms76@sciencedirect.com','tyLfFCm','대한민국',NULL),('97110881','ROLE_STU','권철','761222-2172773','F','영어영문학과','경상남도 양산시 상북면 반회서4길 12-18 (상북면, 부산방앗간)','612-746-8656','mcurrm8w@chronoengine.com','d6caD2JuXG','대한민국',NULL),('97111017','ROLE_STU','표재신','751116-1035716','M','사회학과','경상북도 영천시 금호읍 대구대길 333 (금호읍, 대구대학교)','976-912-5064','jrhule11@msu.edu','uoqfmJmpqY','대한민국',NULL),('97111434','ROLE_STU','남바다','780306-1172324','M','건축학과','전라남도 함평군 함평읍 중앙길 90 (함평읍, 광주약국)','678-912-8517','bcaybc@dropbox.com','hYDUV1K','대한민국',NULL),('97113607','ROLE_STU','정란','770704-1024779','M','의류학과','대전광역시 중구 보문로 331 (선화동, 대전세무서)','644-474-0910','asharplessdu@prweb.com','xAhD87','대한민국',NULL),('97113662','ROLE_STU','신한결','751228-2634187','F','사회복지학과','인천광역시 미추홀구 길파로35번길 26 (주안동, 대로빌라)','499-798-7025','areisenbt@sakura.ne.jp','0hWFmfM65','대한민국',NULL),('97118253','ROLE_STU','백광','750806-2770184','F','사회학과','강원도 고성군 현내면 동해대로 8190-1 (현내면)','930-835-1161','lkeuneke60@ask.com','XmR3iRtNWQ','대한민국',NULL),('97119382','ROLE_STU','고미래','770904-1973212','M','경영학과','대전광역시 유성구 테크노2로 214 (탑립동, 대전세관)','691-468-1719','hburtwellca@amazon.co.jp','uwXA3pAf9tk','대한민국',NULL),('97119866','ROLE_STU','풍호','751122-2408921','F','국어국문학과','대구광역시 수성구 유니버시아드로42길 127 (대흥동, 대구광역시 체육회관)','508-886-2686','ddrohane30@amazon.de','VmgwYjcto','대한민국',NULL),('97122894','ROLE_STU','배광','760810-2669969','F','심리학과','경상남도 통영시 동문로 59-1 (정량동, 부산우유)','320-483-0620','gyggo7g@xing.com','VcbhzzXL6','대한민국',NULL),('97133338','ROLE_STU','Shortall','760217-1099477','M','심리학과','경상북도 영주시 중앙로80번길 33-23 (하망동, 대구두루막)','578-269-4954','dshortalldh@umich.edu','GgsoHyL','France',NULL),('97138436','ROLE_STU','안미르','760723-1659881','M','언어학과','서울특별시 용산구 독서당로20길 1-7 (한남동, 한국소비자연맹서울시지부)','693-562-7963','dginni6h@delicious.com','XGMCaw9EMWt','대한민국',NULL),('97140968','ROLE_STU','Jellings','760930-2271242','F','건축학과','부산광역시 사상구 강변대로 412 (엄궁동, 강변대로self주유소)','109-284-9485','ejellings84@icio.us','aLSInRDYWh4','China',NULL),('97145357','ROLE_STU','남궁수미','750219-1891506','M','철학과','강원도 춘천시 동내면 순환대로 555 (동내면)','400-635-2112','adowthwaited0@wikimedia.org','gGECIzzPNr6S','대한민국',NULL),('97146947','ROLE_STU','제갈고은','750915-1665068','M','통계학과','강원도 강릉시 강릉대로 447 (포남동)','826-933-3379','hbrimmell8x@ustream.tv','ZJyyETcQ','대한민국',NULL),('97150910','ROLE_STU','탁샘','760223-1027285','M','기계공학과','광주광역시 광산구 평동산단7번로 72-18 (연산동, 대로물산)','369-548-9235','kdowbakincx@gov.uk','FZuN48aa4','대한민국',NULL),('97151615','ROLE_STU','최혁','771206-1972476','M','체육학과','대구광역시 수성구 국채보상로207길 37 (만촌동, 68년 대구시 공영주택)','760-594-6406','sinott41@nih.gov','Xjnf8g','대한민국',NULL),('97161604','ROLE_STU','남궁다운','750616-1165675','M','건축학과','강원도 춘천시 동내면 순환대로 571 (동내면)','424-176-9507','ccamilleri4@dagondesign.com','Y1op49Y6VnmS','대한민국',NULL),('97163211','ROLE_STU','추훈','780301-2773915','F','수학과','경상남도 사천시 사남면 초전로 28 (사남면, 부산우유)','617-515-3434','fcollop4e@booking.com','HvpAGFIWLVN','대한민국',NULL),('97164788','ROLE_STU','풍성','750207-1535409','M','사회복지학과','부산광역시 동래구 사직로 77 (사직동, 부산광역시 체육회관)','609-701-1035','stookeyc8@skype.com','P2l2nBaz','대한민국',NULL),('97164854','ROLE_STU','손그루','750713-2949123','F','경영학과','경상남도 함안군 칠서면 계내2길 57 (칠서면, 서울횟집)','268-867-3501','amorratt19@springer.com','OAFoMqeGUrx','대한민국',NULL),('97165937','ROLE_STU','강무열','780321-2740613','F','물리학과','강원도 양양군 양양읍 동해대로 2772-4 (양양읍)','154-600-7906','esongust8y@globo.com','6puE6Nf','대한민국',NULL),('97177716','ROLE_STU','서송이','770306-1427680','M','의류학과','부산광역시 사상구 가야대로 326-11 (주례동, 대한노인회부산시사상구지회)','373-720-1666','cpeegrem9e@umich.edu','p3ta6g','대한민국',NULL),('97179741','ROLE_STU','유광조','760412-1892197','M','국어국문학과','충청남도 당진시 교동길 151 (읍내동, 대전약국)','535-554-7848','lstuddert33@yandex.ru','vms0qwf','대한민국',NULL),('97184914','ROLE_STU','배햇살','760924-2159921','F','사회복지학과','경상남도 양산시 웅상대로 841 (덕계동, 부산전기)','325-934-4796','anoraway9@nyu.edu','9rhTwrpEfq','대한민국',NULL),('97190513','ROLE_STU','윤가영','770712-1458135','M','사회학과','경상남도 사천시 서부시장길 89-1 (서동, 대구청과)','651-447-5624','hsalatinoby@free.fr','WavmVbY','대한민국',NULL),('97194954','ROLE_STU','안웅','761015-1675081','M','언론정보학과','경상남도 거제시 옥포로 178 (옥포동, 서울상가)','380-677-7494','jgawked5@homestead.com','EM9y4t8H3iq','대한민국',NULL),('97206870','ROLE_PROF','강아라','500621-2754373','F','언론정보학과','강원도 고성군 죽왕면 동해대로 5588-8 (죽왕면)','825-844-5117','nkoenen9t@livejournal.com','Gj9C72oL6E','대한민국',NULL),('97209783','ROLE_PROF','정자경','520622-2838285','F','경영학과','경상북도 포항시 북구 천마로72번길 22 (양덕동, 대구은행)','768-926-7433','sohallihane5s@prnewswire.com','aArvYGtZkIPj','대한민국',NULL),('97214089','ROLE_PROF','최상','541201-2624999','F','컴퓨터공학과','경상북도 포항시 북구 천마로72번길 21 (양덕동, 대구은행)','316-880-5078','mbertholin6m@ocn.ne.jp','RLlNKvuR','대한민국',NULL),('97214948','ROLE_PROF','김교수','570420-1124322','M','물리학과','부산광역시 남구 신선로 223 (감만동, 대로타이어)','439-454-8511','pandreou65@ca.gov','eCOcql','대한민국',NULL),('97223502','ROLE_PROF','정치원','490106-1326388','M','수학과','부산광역시 북구 함박봉로 98 (만덕동, 부산시노인전문병원)','200-479-3249','rballardo@oakley.com','29Qc0mq','대한민국',NULL),('97224411','ROLE_PROF','심현','510325-1451661','M','언론정보학과','제주특별자치도 제주시 천수로 89 (일도이동, 서울빌라)','592-541-6814','wjahns6n@foxnews.com','NOhqFLG9oEG','대한민국',NULL),('97236728','ROLE_PROF','복은별','520929-1841803','M','심리학과','경상남도 양산시 동면 산지로 61 (동면, 부산난원)','623-733-2060','mfantonetti2y@ucla.edu','y6yvUSQlELt8','대한민국',NULL),('97269644','ROLE_PROF','홍리','520501-2572652','F','철학과','경상북도 성주군 성주읍 시장길 14-1 (성주읍, 대구한의원)','173-849-1191','iocarney3a@blogs.com','KOzBBrHep','대한민국',NULL),('97270285','ROLE_PROF','한다솜','500104-1870431','M','사회학과','세종특별자치시 장군면 정동길 31-30','308-599-8099','dskudder18@google.co.uk','PDIICZhkH','대한민국',NULL),('97273893','ROLE_PROF','고영신','540917-2749148','F','사회복지학과','경상남도 창원시 진해구 용원로101번길 15 (용원동, 부산족발)','764-133-2280','rpollicottcv@nationalgeographic.com','vQL0chlO','대한민국',NULL),('97276721','ROLE_PROF','예힘찬','640102-1740459','M','언어학과','경상남도 창원시 진해구 용재로35번길 17 (용원동, 서울빌)','490-397-8335','siban6t@nbcnews.com','So0NviKR','대한민국',NULL),('97285470','ROLE_PROF','전현','600806-2802168','F','컴퓨터공학과','전라북도 익산시 고봉로18길 87-15 (영등동, 대로빌라)','712-988-7049','psturroran@intel.com','EHqJGV8fkqWo','대한민국',NULL),('97299813','ROLE_PROF','Domnin','630107-2281333','F','건축학과','경상북도 청도군 이서면 대전칠엽길 108 (이서면, 대전교회)','845-437-8412','jdomnin9p@cnbc.com','vNdzadg3PiL6','Mongolia',NULL),('97393234','ROLE_ADMIN','표나봄','500515-2289309','F','인사','서울특별시 강동구 고덕로 183 (고덕동, 서울특별시 동부기술교육원)','636-669-8705','hboarder1t@surveymonkey.com','du9GSc','대한민국',NULL),('98103194','ROLE_STU','신바람','781121-1623581','M','건축학과','경상남도 양산시 하북면 신평강변3길 6 (하북면, 부산우유)','526-922-3498','cbowheyc4@yellowpages.com','FAv53VCBHseh','대한민국',NULL),('98104620','ROLE_STU','남강민','790702-2361124','F','영어영문학과','대구광역시 북구 칠성남로 112 (칠성동2가, 대구광역시 소방안전본부, 북부소방서)','653-701-8646','oborastondd@illinois.edu','2CpPgXpDBb','대한민국',NULL),('98104890','ROLE_STU','Canero','781230-1994550','M','사회학과','대구광역시 서구 달서로14길 14-7 (비산동, 대로주택)','536-615-6947','kcanero57@ocn.ne.jp','5YU2SLAeB','Russia',NULL),('98106637','ROLE_STU','Abbs','780909-2740834','F','언론정보학과','서울특별시 구로구 개봉로15길 33 (개봉동, 대로빌라)','797-795-9648','babbs2d@miibeian.gov.cn','kPzyVR5','Russia',NULL),('98107476','ROLE_STU','황보철','770115-2982227','F','철학과','제주특별자치도 서귀포시 태평로371번길 29-1 (서귀동, 서울양복점)','191-162-2985','bjeynessc0@nifty.com','5tIKwjJ1cXu','대한민국',NULL),('98108958','ROLE_STU','박미란','770712-1048269','M','통계학과','경상남도 통영시 충렬로 18 (서호동, 서울슈퍼)','141-649-6103','nfrodshamay@epa.gov','oWOhogbVYGd','대한민국',NULL),('98112458','ROLE_STU','고미래','760416-1025031','M','체육학과','경상남도 의령군 부림면 신번로10길 7 (부림면, 부산장의사)','526-697-7422','fwinsomav@engadget.com','nYmhDEGvh','대한민국',NULL),('98120147','ROLE_STU','예훈','770317-1081209','M','체육학과','부산광역시 북구 낙동북로 737-1 (구포동, 부산광역시 학생예술문화회관)','466-408-6846','nroblett66@goo.ne.jp','cSOOZY','대한민국',NULL),('98123758','ROLE_STU','정성현','780620-1941947','M','사회학과','경상남도 통영시 욕지면 서촌아랫길 117 (욕지면, 부산미용실)','954-137-6598','smantrup4h@bing.com','4ZNXaaba1X','대한민국',NULL),('98127721','ROLE_STU','성상','780927-1439431','M','물리학과','강원도 속초시 동해대로 4320 (교동)','102-192-0498','isumpter1y@techcrunch.com','ewQeJh4','대한민국',NULL),('98128085','ROLE_STU','사공자경','760423-2269820','F','철학과','서울특별시 양천구 남부순환로 595 (신월동, 서울시개인택시운송사업조합)','383-647-2921','ealtoft98@e-recht24.de','An9zYnQ4Zlz','대한민국',NULL),('98128104','ROLE_STU','류민은','790210-1989382','M','언론정보학과','경상남도 거창군 고제면 지경길 119-87 (고제면, 부산농장)','510-312-3512','nthomann4v@mashable.com','sslKBdl','대한민국',NULL),('98130927','ROLE_STU','문태웅','790912-2716924','F','기계공학과','경기도 광주시 파발로 176 (경안동, 광주시공설운동장)','474-649-0331','oahmad47@istockphoto.com','e1ro89SGrco7','대한민국',NULL),('98138550','ROLE_STU','고웅','760724-2174379','F','컴퓨터공학과','경기도 파주시 문산읍 문산로40번길 15 (문산읍, 대전상회)','101-432-0743','awithringten9l@livejournal.com','wk32RZ44QYkK','대한민국',NULL),('98142303','ROLE_STU','손훈','760911-2349197','F','의류학과','충청북도 단양군 매포읍 평동19길 3 (매포읍, 대구막창)','461-269-5975','iliversleybq@etsy.com','GFUDIW','대한민국',NULL),('98142548','ROLE_STU','복이레','791215-2028067','F','체육학과','광주광역시 북구 암매길 80 (운정동, 광주광역시 위생매립장)','805-914-0244','gkeelin4o@cisco.com','pVNON4','대한민국',NULL),('98144004','ROLE_STU','추재','760210-2788606','F','사회복지학과','전라북도 부안군 부안읍 당산로 115 (부안읍, 대전열쇠)','459-342-7540','smoncurap@nasa.gov','ySZHoZyUSv','대한민국',NULL),('98144698','ROLE_STU','Jorn','780811-1392874','M','의류학과','전라남도 나주시 동강면 동강로 239 (동강면, 동강대전보건진료소)','436-577-8733','rjorn99@cornell.edu','JmhWbbJDXJCb','China',NULL),('98145272','ROLE_STU','최이경','790112-1240312','M','언론정보학과','경상남도 함안군 칠서면 회산2길 85 (칠서면, 대구공업사)','459-547-9075','ophilipsohn9h@storify.com','NeSI7JSg','대한민국',NULL),('98146439','ROLE_STU','오승헌','790122-2489572','F','물리학과','경상남도 창원시 진해구 대야남로 66-1 (태백동, 서울분식)','763-508-1437','chourihane3j@hubpages.com','IJpC7fMpT','대한민국',NULL),('98147857','ROLE_STU','탁나라','760621-1426523','M','건축학과','경상남도 거제시 거제중앙로 1898 (고현동, 서울의원)','988-528-3299','mrosenfelderg@clickbank.net','lKX0j8','대한민국',NULL),('98151670','ROLE_STU','신훈','780926-2883851','F','건축학과','경상남도 창원시 진해구 안골로108번길 36 (안골동, 서울식당)','950-288-5420','bbaguley67@purevolume.com','UuVECY4uA','대한민국',NULL),('98154539','ROLE_STU','문은채','790425-2073093','F','수학과','강원도 춘천시 동내면 순환대로 565-11 (동내면)','306-206-4752','ymanzell5a@theglobeandmail.com','GgTTUWex','대한민국',NULL),('98156951','ROLE_STU','전나라','761119-2245521','F','국어국문학과','경상북도 청송군 주왕산면 공원길 213 (주왕산면, 대구슈퍼)','867-738-1563','tmccrory75@ucoz.ru','aPF4kEADjffA','대한민국',NULL),('98157244','ROLE_STU','설훈','760929-2979118','F','수학과','부산광역시 동구 중앙대로251번길 13 (초량동, 천도교부산시교구)','424-921-6712','ehuygens8l@timesonline.co.uk','y3DkROULNbJ','대한민국',NULL),('98159767','ROLE_STU','송우람','781108-2935720','F','철학과','경상북도 예천군 지보면 지보로 203 (지보면, 대구오토바이)','916-223-8644','fmeth6s@etsy.com','ZceY7v','대한민국',NULL),('98161362','ROLE_STU','Inchbald','770719-2449705','F','컴퓨터공학과','제주특별자치도 제주시 진군길 56-11 (노형동, 대구원룸)','550-777-6877','minchbaldcq@ucsd.edu','RPjzCF','Indonesia',NULL),('98171416','ROLE_STU','Pretorius','770528-1601766','M','수학과','경상남도 창원시 마산합포구 진전면 의산삼일로 10-15 (진전면, 대전교회)','711-265-9304','npretorius9j@hp.com','J3V22gSofP','Nigeria',NULL),('98178800','ROLE_STU','Keling','780104-1321275','M','영어영문학과','경상남도 사천시 사천읍 평화2길 40-11 (사천읍, 부산식당)','922-233-5907','lkelingbl@biblegateway.com','uZD5XzZQ3eyB','Brazil',NULL),('98181064','ROLE_STU','안현','781111-1125052','M','기계공학과','충청북도 청주시 상당구 미원면 미원초정로 1 (미원면, 대전유리)','403-935-2818','jvest43@examiner.com','m34lnxJAJVjU','대한민국',NULL),('98182374','ROLE_STU','복재섭','781116-2124341','F','언어학과','경상북도 영주시 풍기읍 죽령로1381번길 136 (풍기읍, 대구농원)','461-513-3130','scushworth3l@mozilla.com','lVA83j','대한민국',NULL),('98187855','ROLE_STU','황하경','780926-2544194','F','경영학과','경상북도 경산시 진량읍 상림2길 10-8 (진량읍, 대구원룸)','732-407-0058','bbollinidi@apple.com','WRYwCx5D0b','대한민국',NULL),('98188599','ROLE_STU','황보설','780620-1073519','M','영어영문학과','경상남도 함안군 가야읍 중앙남1길 19-2 (가야읍, 서울헤어)','266-618-6528','jtradewellda@sohu.com','SvoiQe4vWFsq','대한민국',NULL),('98193195','ROLE_STU','Bettridge','780219-2466509','F','국어국문학과','경상북도 예천군 예천읍 효자로 108-1 (예천읍, 대구식당)','105-669-6295','jbettridge5x@state.gov','69banwIMZ','Lithuania',NULL),('98194905','ROLE_STU','봉경구','771226-1509327','M','통계학과','경상북도 영주시 풍기읍 동성로76번길 18 (풍기읍, 대구교복사)','753-132-4603','apudsallah@irs.gov','lgHx6rMg','대한민국',NULL),('98198172','ROLE_STU','문건','770402-2063340','F','언론정보학과','부산광역시 연제구 연제로 28 (연산동, 부산광역시 선거관리위원회)','116-254-7365','sjaumet7q@com.com','TdQ6TE','대한민국',NULL),('98204804','ROLE_PROF','문미르','510413-1682659','M','통계학과','경상북도 울릉군 울릉읍 도동1길 30 (울릉읍, 대구호텔)','308-387-9782','trillstonebj@illinois.edu','UFJEBh','대한민국',NULL),('98237637','ROLE_PROF','성혁','660605-1013279','M','건축학과','경기도 시흥시 공단2대로 127 (정왕동, 공단2대로43)','487-222-4139','bpetrovdg@theguardian.com','BxkLECbDe','대한민국',NULL),('98240713','ROLE_PROF','Chalke','610403-2942176','F','컴퓨터공학과','강원도 양양군 현남면 동해대로 959-10 (현남면)','856-913-8260','echalke6r@fema.gov','3VRYTXUbL','Iran',NULL),('98248569','ROLE_PROF','예영애','610327-1818280','M','심리학과','서울특별시 광진구 아차산로30길 36 (자양동, 서울특별시 동부여성발전센타)','492-101-3655','kdomoni8g@seesaa.net','k4WqsekE','대한민국',NULL),('98297800','ROLE_PROF','추재규','510310-1871361','M','의류학과','전라북도 임실군 운암면 강운로 1221-17 (운암면, 대전산장)','734-174-2238','ctanser8a@domainmarket.com','rroFL6LnFKLi','대한민국',NULL),('98350349','ROLE_ADMIN','전숙자','640628-1110536','M','재무','경기도 파주시 탄현면 필승로 330-102 (탄현면, 고려통일대전)','610-129-0046','dwinleycl@who.int','vd01Sve97Bqv','대한민국',NULL),('98372061','ROLE_ADMIN','Dreghorn','531106-2611046','F','기획','경기도 남양주시 금곡로 43 (금곡동, 대로빌딩)','553-480-9729','adreghorn1r@edublogs.org','MD63j3t','Indonesia',NULL),('99101175','ROLE_STU','임성','791130-2283511','F','물리학과','충청남도 당진시 당진중앙2로 53-9 (읍내동, 대전일보)','328-792-6020','rduxbury42@examiner.com','iGkCYxH','대한민국',NULL),('99107577','ROLE_STU','정웅','801205-1487957','M','체육학과','강원도 춘천시 신동면 순환대로 20-13 (신동면)','528-243-3682','dcardenasaj@spotify.com','1iXssfmWlAG','대한민국',NULL),('99111714','ROLE_STU','황보다운','790515-1695970','M','철학과','강원도 속초시 동해대로 4125 (조양동)','350-957-0474','bpodburyba@symantec.com','1TmcCvmEiIw','대한민국',NULL),('99117106','ROLE_STU','Bubbear','791027-1697612','M','컴퓨터공학과','강원도 춘천시 동내면 순환대로 565-3 (동내면)','178-424-3513','gbubbear6e@posterous.com','79kRIs','Sweden',NULL),('99124899','ROLE_STU','남무영','770801-1138036','M','언론정보학과','대전광역시 동구 중앙로 215 (정동, 대전역)','346-522-8340','pbard7@tmall.com','J4IyxL9bkGT','대한민국',NULL),('99128242','ROLE_STU','예나라우람','800409-1667908','M','수학과','경기도 파주시 파주읍 가마울길 135 (파주읍, 대구휠타)','279-394-3127','rfranceschelli7w@theatlantic.com','DciQWUM2eg7m','대한민국',NULL),('99132069','ROLE_STU','류상','780923-1473755','M','물리학과','경기도 파주시 조리읍 정문로 3-2 (조리읍, 대로애드)','783-229-6207','ecolumbine9d@nsw.gov.au','Pdk9CG','대한민국',NULL),('99134963','ROLE_STU','추철','770419-2336610','F','의류학과','대전광역시 대덕구 대전로 1283 (대화동, 대전기공)','867-962-8838','kmeas9r@economist.com','cwc75AqOnw','대한민국',NULL),('99135036','ROLE_STU','봉믿음','771220-2561227','F','사회복지학과','충청북도 청주시 서원구 현도면 우록1길 50 (현도면, 대전기공)','601-267-7229','swhitter2k@google.ru','c91bixYNMEMd','대한민국',NULL),('99135606','ROLE_STU','문웅','790208-2954697','F','경영학과','서울특별시 송파구 동남로4길 6 (문정동, 대전빌딩)','274-884-2422','khlavecek1b@opensource.org','TVrRj29bexF','대한민국',NULL),('99136955','ROLE_STU','박덕수','770712-2885875','F','언어학과','경상남도 창원시 마산합포구 동서동4길 16 (신포동2가, 부산공업)','574-399-8295','tchesters7j@homestead.com','WIclfEvBM','대한민국',NULL),('99140982','ROLE_STU','Grindley','781121-2087949','F','영어영문학과','서울특별시 중구 퇴계로26길 52 (예장동, 서울시소방재난본부)','334-184-1946','tgrindley6b@webnode.com','Vx7xcxA','Indonesia',NULL),('99146775','ROLE_STU','탁건','770304-1920839','M','사회복지학과','전라북도 익산시 고봉로18길 83-13 (영등동, 대로빌라)','397-978-9855','tthiolier9g@elegantthemes.com','zBAdj9','대한민국',NULL),('99154775','ROLE_STU','Pollins','800214-1704533','M','기계공학과','충청북도 괴산군 청천면 청천3길 15-1 (청천면, 대구수석)','787-197-5418','cpollins5y@slashdot.org','di4Nr0Toxpzm','Philippines',NULL),('99157379','ROLE_STU','Gansbuhler','771214-2138459','F','컴퓨터공학과','충청남도 당진시 합덕읍 도란말2길 61 (합덕읍, (주)대로)','533-277-5794','ngansbuhler6u@illinois.edu','Vqe3f3IlrJv','Poland',NULL),('99158834','ROLE_STU','권병헌','780215-1833657','M','철학과','충청북도 보은군 속리산면 법주사로 252-1 (속리산면, 대구상회)','328-894-9958','ffowlestone6a@hexun.com','pUDiNKKlP9n','대한민국',NULL),('99159042','ROLE_STU','표우람','770103-1225630','M','체육학과','대구광역시 서구 달서로14길 20-2 (비산동, 대로하이츠)','600-825-2404','rprinettt@desdev.cn','Z1xsNWcUb','대한민국',NULL),('99161386','ROLE_STU','풍훈','800918-2931742','F','수학과','충청남도 천안시 서북구 쌍용대로 129-1 (쌍용동, 대로부동산)','477-789-2065','lbyrcher69@uiuc.edu','V8KHz8','대한민국',NULL),('99162332','ROLE_STU','최건','790328-1342379','M','심리학과','경상남도 함안군 군북면 중암5길 11 (군북면, 부산식당)','786-974-7465','cmcnairaz@themeforest.net','MKFS89RjlH','대한민국',NULL),('99164679','ROLE_STU','안현승','771105-1610232','M','의류학과','울산광역시 중구 해오름14길 40 (남외동, 대로전원빌라)','877-407-9417','bkristufekae@weibo.com','YSVp6y97','대한민국',NULL),('99167651','ROLE_STU','김샘','771110-1745347','M','경영학과','전라남도 담양군 대전면 대전로 4 (대전면, 대전파출소)','898-711-2639','ywolver8h@odnoklassniki.ru','YvfyplLbBlKY','대한민국',NULL),('99170018','ROLE_STU','김성혁','771229-1410089','M','경영학과','인천광역시 남동구 에코중앙로 25-55 (고잔동, 대로수출포장)','185-162-9157','lboyton38@reference.com','BoQ5GeT','대한민국',NULL),('99171742','ROLE_STU','표요한','771104-2457036','F','컴퓨터공학과','경상남도 양산시 물금읍 황산로 351 (물금읍, 서울식당)','711-919-4968','gkitchaside9o@cpanel.net','mx5rHU5','대한민국',NULL),('99172098','ROLE_STU','제갈한결','770305-1915575','M','언어학과','대전광역시 대덕구 동서대로 1790 (비래동, 대전한성교회)','753-983-2530','cmathewcf@ask.com','8gTd5o','대한민국',NULL),('99172969','ROLE_STU','유샛별','801019-2125188','F','언론정보학과','충청남도 금산군 진산면 만악길 25-12 (진산면, 대전ATV체험장)','612-279-2240','dschwandermanndn@hc360.com','OzXhaRtFd','대한민국',NULL),('99173220','ROLE_STU','제갈으뜸','780322-2543171','F','경영학과','강원도 춘천시 동내면 순환대로 565-10 (동내면)','210-336-9750','adeeley5l@goodreads.com','2LPPx3fp','대한민국',NULL),('99178514','ROLE_STU','윤현','780629-2579591','F','국어국문학과','서울특별시 중랑구 양원역로 38 (망우동, 서울시북부병원 및 시립중랑노인전문요양원)','569-726-2135','ematokhninbo@samsung.com','YL3Q9z','대한민국',NULL),('99179911','ROLE_STU','윤치원','781112-2355821','F','체육학과','광주광역시 동구 중앙로160번길 31-37 (황금동, 광주광역시 청소년 삶디자인센터)','635-241-8600','cveracruysseb8@elpais.com','RMhaGi2n2D','대한민국',NULL),('99181013','ROLE_STU','남치원','790407-1301557','M','사회학과','경상남도 통영시 해송정2길 13 (동호동, 부산보살)','765-985-8927','abrawley2h@networksolutions.com','Z4sxymJ6qtkl','대한민국',NULL),('99185489','ROLE_STU','김우영','801228-2509098','F','기계공학과','전라북도 정읍시 서부산업도로 168-61 (상평동, 대전해외관광)','908-939-8411','eelegoodcg@earthlink.net','PgF9wepL','대한민국',NULL),('99187512','ROLE_STU','Maass','791023-2280808','F','물리학과','경상남도 남해군 고현면 탑동로 55-1 (고현면, 서울의원)','761-807-5872','kmaassa7@yahoo.com','q1Qn6UV','Nicaragua',NULL),('99188532','ROLE_STU','권미란','781207-2857887','F','사회학과','경상남도 양산시 덕계로 91 (덕계동, 부산은행)','744-123-7096','mturton36@china.com.cn','9vZBfJPihax','대한민국',NULL),('99188717','ROLE_STU','정이수','780622-1086071','M','사회복지학과','부산광역시 연제구 월드컵대로 399 (거제동, 부산광역시 개인택시운송사업조합)','948-484-2935','jphilippson9y@prnewswire.com','N1OqCm','대한민국',NULL),('99193449','ROLE_STU','손혜림','790303-1624278','M','영어영문학과','제주특별자치도 서귀포시 남원읍 위미중앙로 240 (남원읍, 대구청과)','110-178-2180','mabreheart88@go.com','hqU0SPuH','대한민국',NULL),('99194300','ROLE_STU','Tolson','780526-2159190','F','의류학과','충청남도 계룡시 두마면 사계로 184 (두마면, 대전우편집중국)','297-499-8455','mtolsondo@multiply.com','zdVpsNWzDfz4','Kazakhstan',NULL),('99195608','ROLE_STU','김웅','800603-2587765','F','영어영문학과','경상남도 양산시 공단로 78 (신기동, 부산세차장)','437-801-6131','lcockerill4j@mozilla.com','tA3z6WLjCg0','대한민국',NULL),('99203458','ROLE_PROF','송지해','580706-2201243','F','사회학과','경상남도 창원시 의창구 사림로29번길 1 (봉곡동, 서울석재)','552-651-9494','trivett80@hibu.com','2NS0Sved','대한민국',NULL),('99212905','ROLE_PROF','Wissby','620614-2204594','F','국어국문학과','강원도 삼척시 하장면 오두재로 4 (하장면, 대전슈퍼)','791-537-1007','awissby1c@techcrunch.com','27Dr4VPXJAJc','Colombia',NULL),('99242637','ROLE_PROF','정병헌','630322-1228114','M','경영학과','경상남도 양산시 삼호5길 36-1 (삼호동, 부산가든)','731-715-4069','echarlina2@pcworld.com','GlV5hk0eDByb','대한민국',NULL),('99249681','ROLE_PROF','황상','520723-2990341','F','철학과','경상남도 사천시 서부시장길 91 (서동, 부산천막사)','888-340-7487','lllewhellinat@nps.gov','XoM5MheO','대한민국',NULL),('99250159','ROLE_PROF','노혁','651117-2857577','F','건축학과','대전광역시 중구 학고개로34번길 56 (옥계동, 대구빌라)','974-989-4050','gfeldhuhnd6@w3.org','yN7rThYz','대한민국',NULL),('99253149','ROLE_PROF','사공훈','570409-2605496','F','사회학과','제주특별자치도 서귀포시 표선면 표선관정로104번길 8-1 (표선면, 서울상회)','814-160-1036','cnorthcliffec@blogtalkradio.com','7onKd1US','대한민국',NULL),('99255215','ROLE_PROF','Chipchase','670206-1120779','M','언어학과','경상남도 하동군 하동읍 중앙로 51 (하동읍, 서울바베큐)','599-909-7077','gchipchase2g@paypal.com','H3bZ7ELCVRV','Norway',NULL),('99261832','ROLE_PROF','Detoc','510515-2011330','F','체육학과','제주특별자치도 서귀포시 중앙로62번길 62 (서귀동, 서울 우유)','780-597-1680','cdetocb7@t-online.de','TZWr2dwXg8e','Vanuatu',NULL),('99289861','ROLE_PROF','Garthland','571221-2054490','F','심리학과','경상북도 청송군 부남면 나실길 80 (부남면, 대전3리경로당)','942-784-3451','cgarthlanddb@angelfire.com','RbrAtIq5','Papua New Guinea',NULL),('99295054','ROLE_PROF','풍나영','620804-2393511','F','사회복지학과','경상남도 양산시 하북면 신평로 45 (하북면, 서울뚝배기)','325-702-2873','esnalham1q@jigsy.com','oeTVvm','대한민국',NULL),('99333770','ROLE_ADMIN','유샛별','580412-1709461','M','재무','경상남도 양산시 서창서1길 27-1 (삼호동, 부산식육점)','672-522-0692','wpfleger74@dagondesign.com','WqQ5B90sSLwt','대한민국',NULL),('99376683','ROLE_ADMIN','Raffin','541112-2013227','F','기획','부산광역시 수영구 광일로 8-8 (광안동, 대로베스파빌)','125-454-3538','iraffindf@wufoo.com','rz2aH4A','China',NULL),('a12h0000','ROLE_STU','testname','001122-3333333','F','','경기도 광주시 중앙로 128 (경안동, 농협중앙회광주시지부)','','','$2a$10$dzznctHUqEoOFqed5BtWFOa2Y/JPTcRBU40.xbwe.KCugNvgd4yYC','대한민국',NULL),('test123','ROLE_STU','황하경','971113-2584784','F','컴퓨터공학과','충청북도 단양군 어상천면 대전1길 42 (어상천면, 대전2리마을회)','010-5187-1104','burnrare@naver.com','$2a$10$zKFX6Yi6Uk1.9jv.zDhDjeLDli1MbWd1sMuB76jNDWzwHQ83xPJiK','대한민국',NULL),('testprof','ROLE_PROF','용교수','810604-1846235','M','컴퓨터공학과','경상남도 사천시 동금4길 37 (동금동, 서울복집)','testphone2','testemail2','$2a$10$vwjohV1/0GL0ISm8hyZBe.teG5.E7aeYNagwOnQlRdl5115LU9.rq','testnation2',NULL);
/*!40000 ALTER TABLE `k_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matchigId_seq`
--

DROP TABLE IF EXISTS `matchigId_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matchigId_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matchigId_seq`
--

LOCK TABLES `matchigId_seq` WRITE;
/*!40000 ALTER TABLE `matchigId_seq` DISABLE KEYS */;
INSERT INTO `matchigId_seq` VALUES (3001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `matchigId_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_id_seq`
--

DROP TABLE IF EXISTS `notice_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_id_seq`
--

LOCK TABLES `notice_id_seq` WRITE;
/*!40000 ALTER TABLE `notice_id_seq` DISABLE KEYS */;
INSERT INTO `notice_id_seq` VALUES (5000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `notice_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_no_seq`
--

DROP TABLE IF EXISTS `notice_no_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice_no_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_no_seq`
--

LOCK TABLES `notice_no_seq` WRITE;
/*!40000 ALTER TABLE `notice_no_seq` DISABLE KEYS */;
INSERT INTO `notice_no_seq` VALUES (3001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `notice_no_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_d_id_seq`
--

DROP TABLE IF EXISTS `quiz_d_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_d_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_d_id_seq`
--

LOCK TABLES `quiz_d_id_seq` WRITE;
/*!40000 ALTER TABLE `quiz_d_id_seq` DISABLE KEYS */;
INSERT INTO `quiz_d_id_seq` VALUES (6001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_d_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_h_id_seq`
--

DROP TABLE IF EXISTS `quiz_h_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_h_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_h_id_seq`
--

LOCK TABLES `quiz_h_id_seq` WRITE;
/*!40000 ALTER TABLE `quiz_h_id_seq` DISABLE KEYS */;
INSERT INTO `quiz_h_id_seq` VALUES (7001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_h_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_r_id_seq`
--

DROP TABLE IF EXISTS `quiz_r_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_r_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_r_id_seq`
--

LOCK TABLES `quiz_r_id_seq` WRITE;
/*!40000 ALTER TABLE `quiz_r_id_seq` DISABLE KEYS */;
INSERT INTO `quiz_r_id_seq` VALUES (6001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_r_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_seq`
--

DROP TABLE IF EXISTS `quiz_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_seq`
--

LOCK TABLES `quiz_seq` WRITE;
/*!40000 ALTER TABLE `quiz_seq` DISABLE KEYS */;
INSERT INTO `quiz_seq` VALUES (7005,1,9223372036854775806,5,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduleSeq`
--

DROP TABLE IF EXISTS `scheduleSeq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduleSeq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduleSeq`
--

LOCK TABLES `scheduleSeq` WRITE;
/*!40000 ALTER TABLE `scheduleSeq` DISABLE KEYS */;
INSERT INTO `scheduleSeq` VALUES (8001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `scheduleSeq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_seq`
--

DROP TABLE IF EXISTS `schedule_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_seq`
--

LOCK TABLES `schedule_seq` WRITE;
/*!40000 ALTER TABLE `schedule_seq` DISABLE KEYS */;
INSERT INTO `schedule_seq` VALUES (1,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `schedule_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_seq`
--

DROP TABLE IF EXISTS `score_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_seq`
--

LOCK TABLES `score_seq` WRITE;
/*!40000 ALTER TABLE `score_seq` DISABLE KEYS */;
INSERT INTO `score_seq` VALUES (8000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `score_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seq_mysql`
--

DROP TABLE IF EXISTS `seq_mysql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seq_mysql` (
  `id` int(11) NOT NULL,
  `seq_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seq_mysql`
--

LOCK TABLES `seq_mysql` WRITE;
/*!40000 ALTER TABLE `seq_mysql` DISABLE KEYS */;
INSERT INTO `seq_mysql` VALUES (0,'scheduleSeq'),(0,'careerqid');
/*!40000 ALTER TABLE `seq_mysql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_career_h_id`
--

DROP TABLE IF EXISTS `sq_career_h_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_career_h_id` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_career_h_id`
--

LOCK TABLES `sq_career_h_id` WRITE;
/*!40000 ALTER TABLE `sq_career_h_id` DISABLE KEYS */;
INSERT INTO `sq_career_h_id` VALUES (5001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_career_h_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_career_list`
--

DROP TABLE IF EXISTS `sq_career_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_career_list` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_career_list`
--

LOCK TABLES `sq_career_list` WRITE;
/*!40000 ALTER TABLE `sq_career_list` DISABLE KEYS */;
INSERT INTO `sq_career_list` VALUES (3001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_career_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_career_q_id`
--

DROP TABLE IF EXISTS `sq_career_q_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_career_q_id` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_career_q_id`
--

LOCK TABLES `sq_career_q_id` WRITE;
/*!40000 ALTER TABLE `sq_career_q_id` DISABLE KEYS */;
INSERT INTO `sq_career_q_id` VALUES (7001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_career_q_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_mtr_id`
--

DROP TABLE IF EXISTS `sq_mtr_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_mtr_id` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_mtr_id`
--

LOCK TABLES `sq_mtr_id` WRITE;
/*!40000 ALTER TABLE `sq_mtr_id` DISABLE KEYS */;
INSERT INTO `sq_mtr_id` VALUES (6001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_mtr_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_code_seq`
--

DROP TABLE IF EXISTS `timetable_code_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_code_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_code_seq`
--

LOCK TABLES `timetable_code_seq` WRITE;
/*!40000 ALTER TABLE `timetable_code_seq` DISABLE KEYS */;
INSERT INTO `timetable_code_seq` VALUES (2000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `timetable_code_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_id_seq`
--

DROP TABLE IF EXISTS `timetable_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_id_seq`
--

LOCK TABLES `timetable_id_seq` WRITE;
/*!40000 ALTER TABLE `timetable_id_seq` DISABLE KEYS */;
INSERT INTO `timetable_id_seq` VALUES (2000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `timetable_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'kcy'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_terms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`kcy`@`%` FUNCTION `fn_terms`(p_sch_id varchar(100)
  ) RETURNS varchar(100) CHARSET utf8mb4
begin
  	declare v_sch_title varchar(100);
  
  SELECT sch_title
  into v_sch_title
  from k_schedule
  where sch_id = p_sch_id;
 
 return v_sch_title;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`kcy`@`%` PROCEDURE `test`(classId varchar(100))
BEGIN
	declare sch_start  Date;
declare x int;
	set x = 1;
	set sch_start = 2022-03-08;
	loop_label:LOOP
		if x < 10 then
			leave loop_label;
			end if;
		set sch_start = DATE_ADD(sch_start, INTERVAL 1 week);
	insert  k_class_schedule(class_id,class_sch_date,class_sch_id) values (classId,sch_start,nextval(schedule_seq));
	END LOOP;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-12 19:59:01
