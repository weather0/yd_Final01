-- MySQL dump 10.13  Distrib 5.5.62, for Win64 (AMD64)
--
-- Host: ydmariadbinstance.cmnybkzgfijn.ap-northeast-2.rds.amazonaws.com    Database: kcy
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.8-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aca_id_seq`
--

DROP TABLE IF EXISTS `aca_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aca_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aca_id_seq`
--

LOCK TABLES `aca_id_seq` WRITE;
/*!40000 ALTER TABLE `aca_id_seq` DISABLE KEYS */;
INSERT INTO `aca_id_seq` VALUES (3001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `aca_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_member_seq`
--

DROP TABLE IF EXISTS `class_member_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_member_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_member_seq`
--

LOCK TABLES `class_member_seq` WRITE;
/*!40000 ALTER TABLE `class_member_seq` DISABLE KEYS */;
INSERT INTO `class_member_seq` VALUES (7000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `class_member_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_no_seq`
--

DROP TABLE IF EXISTS `class_no_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_no_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_no_seq`
--

LOCK TABLES `class_no_seq` WRITE;
/*!40000 ALTER TABLE `class_no_seq` DISABLE KEYS */;
INSERT INTO `class_no_seq` VALUES (3000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `class_no_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_seq`
--

DROP TABLE IF EXISTS `evaluation_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluation_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation_seq`
--

LOCK TABLES `evaluation_seq` WRITE;
/*!40000 ALTER TABLE `evaluation_seq` DISABLE KEYS */;
INSERT INTO `evaluation_seq` VALUES (2000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `evaluation_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_admins`
--

DROP TABLE IF EXISTS `k_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_admins` (
  `admin_rank` varchar(100) DEFAULT NULL,
  `admin_job` varchar(100) DEFAULT NULL,
  `admin_id` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`),
  CONSTRAINT `R_92` FOREIGN KEY (`admin_id`) REFERENCES `k_users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_admins`
--

LOCK TABLES `k_admins` WRITE;
/*!40000 ALTER TABLE `k_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_alarm`
--

DROP TABLE IF EXISTS `k_alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_alarm` (
  `sch_id` varchar(100) NOT NULL,
  `alarm_target` varchar(100) DEFAULT NULL,
  `alarm_type` varchar(100) DEFAULT NULL,
  `alarm_day` date DEFAULT NULL,
  `alarm_hour` date DEFAULT NULL,
  `alarm_content` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`sch_id`),
  CONSTRAINT `R_71` FOREIGN KEY (`sch_id`) REFERENCES `k_schedule` (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_alarm`
--

LOCK TABLES `k_alarm` WRITE;
/*!40000 ALTER TABLE `k_alarm` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_alarm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_attendance`
--

DROP TABLE IF EXISTS `k_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_attendance` (
  `stu_id` varchar(100) DEFAULT NULL,
  `attn_type` varchar(100) DEFAULT NULL,
  `class_sch_id` varchar(100) DEFAULT NULL,
  KEY `R_113` (`stu_id`),
  KEY `R_119` (`class_sch_id`),
  CONSTRAINT `R_113` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`),
  CONSTRAINT `R_119` FOREIGN KEY (`class_sch_id`) REFERENCES `k_class_schedule` (`class_sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_attendance`
--

LOCK TABLES `k_attendance` WRITE;
/*!40000 ALTER TABLE `k_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_bills`
--

DROP TABLE IF EXISTS `k_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_bills` (
  `bill_id` varchar(100) NOT NULL,
  `bill_year` int(11) DEFAULT NULL,
  `bill_sem` int(11) DEFAULT NULL,
  `bill_amount` int(11) DEFAULT NULL,
  `major_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`bill_id`),
  KEY `R_93` (`major_id`),
  CONSTRAINT `R_93` FOREIGN KEY (`major_id`) REFERENCES `k_major` (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_bills`
--

LOCK TABLES `k_bills` WRITE;
/*!40000 ALTER TABLE `k_bills` DISABLE KEYS */;
INSERT INTO `k_bills` VALUES ('202111010',2021,1,1000000,'1010'),('202121010',2021,2,1000000,'1010'),('202211010',2022,1,1000000,'1010'),('202221010',2022,2,1000000,'1010'),('202311010',2023,1,1000000,'1010'),('202311026',2023,1,1000000,'1026');
/*!40000 ALTER TABLE `k_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_d`
--

DROP TABLE IF EXISTS `k_career_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_d` (
  `career_h_id` varchar(100) DEFAULT NULL,
  `career_q_result` varchar(100) DEFAULT NULL,
  `career_q_id` varchar(100) DEFAULT NULL,
  KEY `R_108` (`career_h_id`),
  KEY `k_career_d_FK` (`career_q_id`),
  CONSTRAINT `R_108` FOREIGN KEY (`career_h_id`) REFERENCES `k_career_h` (`career_h_id`),
  CONSTRAINT `k_career_d_FK` FOREIGN KEY (`career_q_id`) REFERENCES `k_career_q` (`career_q_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_d`
--

LOCK TABLES `k_career_d` WRITE;
/*!40000 ALTER TABLE `k_career_d` DISABLE KEYS */;
INSERT INTO `k_career_d` VALUES (NULL,'5151','2002'),(NULL,'5151','2003'),(NULL,'151','2004'),(NULL,'515','2005'),(NULL,'151','2006'),(NULL,'15','2007'),('1008','12512','2002'),('1008','23','2003'),('1008','251','2004'),('1008','1251','2005'),('1008','125','2006'),('1008','125','2007'),('1008','1251','2002'),('1008','12512','2003'),('1008','251','2004'),('1008','1251','2005'),('1008','125','2006'),('1008','125','2007'),('1008','25125','2002'),('1008','251','2003'),('1008','51','2004'),('1008','2512','2005'),('1008','51','2006'),('1008','512','2007'),('1008','125','2002'),('1008','125','2003'),('1008','125','2004'),('1008','125','2005'),('1008','125','2006'),('1008','1251','2007'),('1008','125125','2002'),('1008','125','2003'),('1008','125','2004'),('1008','125','2005'),('1008','125','2006'),('1008','125','2007'),('1008','125','2002'),('1008','125','2003'),('1008','125','2004'),('1008','125','2005'),('1008','125','2006'),('1008','125','2007'),('1008','25125','2002'),('1008','251','2003'),('1008','251','2004'),('1008','251','2005'),('1008','1251','2006'),('1008','125','2007'),('1008','125125','2002'),('1008','1251','2003'),('1008','125','2004'),('1008','125','2005'),('1008','125','2006'),('1008','5125','2007'),('1008','125125','2002'),('1008','1251','2003'),('1008','125','2004'),('1008','125','2005'),('1008','125','2006'),('1008','5125','2007'),('1008','678','2002'),('1008','6786876','2003'),('1008','786786','2004'),('1008','86','2005'),('1008','786','2006'),('1008','8678','2007'),('1018','5','2002'),('1018','678','2003'),('1018','687','2004'),('1018','687','2005'),('1018','678','2006'),('1018','685','2007'),('1022','7897','2002'),('1022','98798','2003'),('1022','798798','2004'),('1022','7987','2005'),('1022','9879','2006'),('1022','879879','2007'),('1023','123','2002'),('1023','123','2003'),('1023','7897','2004'),('1023','98798','2005'),('1023','79879','2006'),('1023','7979','2007'),('1024','ㅇ','2002'),('1024','ㅈㅇㅁㅈ','2003'),('1024','ㅈㅇㅁ','2004'),('1024','ㅁㅈㅇ','2005'),('1024','ㅁㅈㅇ','2006'),('1024','ㅁㅈㅇ','2007'),('1026','123','2002'),('1027','','2002'),('1027','','2003'),('1027','','2004'),('1027','','2005'),('1027','','2006'),('1027','','2007'),('1028','','2002'),('1028','','2003'),('1028','','2004'),('1028','','2005'),('1028','','2006'),('1028','','2007'),('1029','','2002'),('1029','','2003'),('1029','','2004'),('1029','','2005'),('1029','','2006'),('1029','','2007'),('1030','','2002'),('1030','','2003'),('1030','','2004'),('1030','','2005'),('1030','','2006'),('1030','','2007'),('1031','','2002'),('1031','','2003'),('1031','','2004'),('1031','','2005'),('1031','','2006'),('1031','','2007'),('1032','123','2002'),('1032','798','2003'),('1032','798','2004'),('1032','7987','2005'),('1032','98798','2006'),('1032','79','2007'),('1033','안녕하세요','2002'),('1033','반갑습니다','2003'),('1033','정철우입니다','2004'),('1033','어찌합니까','2005'),('1033','오키','2006'),('1033','도키','2007'),('1034','11','2002'),('1034','11','2003'),('1034','22','2004'),('1034','33','2005'),('1034','44','2006'),('1034','55','2007'),('1035','1','2002'),('1035','2','2003'),('1035','3','2004'),('1035','4','2005'),('1035','5','2006'),('1035','6','2007'),('1036','1','2002'),('1036','12','2003'),('1036','1','2004'),('1036','2','2005'),('1036','1','2006'),('1036','2','2007');
/*!40000 ALTER TABLE `k_career_d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_h`
--

DROP TABLE IF EXISTS `k_career_h`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_h` (
  `career_h_id` varchar(100) NOT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `career_h_date` date DEFAULT current_timestamp(),
  PRIMARY KEY (`career_h_id`),
  KEY `R_63` (`stu_id`),
  CONSTRAINT `R_63` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_h`
--

LOCK TABLES `k_career_h` WRITE;
/*!40000 ALTER TABLE `k_career_h` DISABLE KEYS */;
INSERT INTO `k_career_h` VALUES ('1007',NULL,'2022-08-31'),('1008','test123','2022-08-31'),('1009',NULL,'2022-08-31'),('1010',NULL,'2022-08-31'),('1011',NULL,'2022-08-31'),('1012',NULL,'2022-08-31'),('1013',NULL,'2022-08-31'),('1014',NULL,'2022-08-31'),('1015',NULL,'2022-08-31'),('1016',NULL,'2022-08-31'),('1017',NULL,'2022-08-31'),('1018','test123','2022-08-31'),('1019','test123','2022-08-31'),('1022','test123','2022-08-31'),('1023','test123','2022-08-31'),('1024','test123','2022-08-31'),('1025','test123','2022-08-31'),('1026','test123','2022-08-31'),('1027','test123','2022-08-31'),('1028','test123','2022-08-31'),('1029','test123','2022-08-31'),('1030','test123','2022-08-31'),('1031','test123','2022-08-31'),('1032','test123','2022-08-31'),('1033','test123','2022-08-31'),('1034','test123','2022-08-31'),('1035','test123','2022-08-31'),('1036','test123','2022-08-31');
/*!40000 ALTER TABLE `k_career_h` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_list`
--

DROP TABLE IF EXISTS `k_career_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_list` (
  `career_list_id` varchar(100) NOT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `career_list_date` date DEFAULT current_timestamp(),
  PRIMARY KEY (`career_list_id`),
  KEY `R_61` (`prof_id`),
  CONSTRAINT `R_61` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_list`
--

LOCK TABLES `k_career_list` WRITE;
/*!40000 ALTER TABLE `k_career_list` DISABLE KEYS */;
INSERT INTO `k_career_list` VALUES ('1','00265609','2022-08-26'),('1002','00149383','2022-08-26'),('2022','testprof','2022-08-30');
/*!40000 ALTER TABLE `k_career_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_career_q`
--

DROP TABLE IF EXISTS `k_career_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_career_q` (
  `career_q_id` varchar(100) NOT NULL,
  `career_q_content` varchar(500) DEFAULT NULL,
  `career_list_id` varchar(100) DEFAULT NULL,
  `career_q_yn` varchar(100) DEFAULT 'Y',
  PRIMARY KEY (`career_q_id`),
  KEY `k_career_q_FK` (`career_list_id`),
  CONSTRAINT `R_105` FOREIGN KEY (`career_list_id`) REFERENCES `k_career_list` (`career_list_id`),
  CONSTRAINT `k_career_q_FK` FOREIGN KEY (`career_list_id`) REFERENCES `k_career_list` (`career_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_career_q`
--

LOCK TABLES `k_career_q` WRITE;
/*!40000 ALTER TABLE `k_career_q` DISABLE KEYS */;
INSERT INTO `k_career_q` VALUES ('1007','어떤 방식의 수업을 원하십니까?5','1002','N'),('1008','어떤 방식의 수업을 원하십니까?4','1002','Y'),('1009','어떤 방식의 수업을 원하십니까?3','1002','Y'),('1010','어떤 방식의 수업을 원하십니까?2','1002','Y'),('1011','어떤 방식의 수업을 원하십니까?1','1002','Y'),('1012','어떤 방식의 수업을 원하십니까?0','1002','Y'),('1013','어떤 방식의 수업을 원하십니까?6','1002','Y'),('1014','수업 만족?','1002','Y'),('1015','ㅇㅇㅇㅇㅇㅇㅇ','1002','Y'),('1016','zzz','1002','Y'),('1022','zz','2022','N'),('2002','awdawd','2022','Y'),('2003','ㅋㅋㅋ 질문이요','2022','Y'),('2004','추가합니다','2022','Y'),('2005','하하하하하','2022','Y'),('2006','zzz','2022','Y'),('2007','질문 추가','2022','Y'),('3','이 학과에 대해 어떻게 생각하십니까?','1','Y'),('3001','2','2022','Y'),('3002','d','2022','Y'),('3003','d','2022','Y'),('3004','dd','2022','Y'),('3005','aaa','2022','Y'),('4','이 학과에 대해 어떻게 생각하십니까?','1','Y');
/*!40000 ALTER TABLE `k_career_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class`
--

DROP TABLE IF EXISTS `k_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class` (
  `class_id` varchar(100) NOT NULL,
  `course_id` varchar(100) DEFAULT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `class_to` int(11) DEFAULT NULL,
  `class_year` int(11) DEFAULT NULL,
  `class_sem` int(11) DEFAULT NULL,
  `class_syl` varchar(100) DEFAULT NULL,
  `class_ck` int(11) DEFAULT 0,
  `class_syl_original` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `R_132` (`course_id`),
  KEY `R_133` (`prof_id`),
  CONSTRAINT `R_132` FOREIGN KEY (`course_id`) REFERENCES `k_course` (`course_id`),
  CONSTRAINT `R_133` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class`
--

LOCK TABLES `k_class` WRITE;
/*!40000 ALTER TABLE `k_class` DISABLE KEYS */;
INSERT INTO `k_class` VALUES ('A100','I1000','08268070',20,2022,1,'2191a3fb-05eb-453b-af04-66f73f166130_10_Nameserver.pdf',3,NULL),('A10011','I1000','08268070',20,100,1,'f27cec45-3f8e-466d-a4c9-0e89ca66cc4d_net_05.pdf',2,NULL),('A500','I1000','08268070',20,2022,1,'2203c0cc-024e-4ecc-9b6c-f769045d9ea2_06_user-account.pdf',1,NULL),('CL1001','I1000','testprof',20,2022,NULL,'705fd5a0-0b06-4b05-bba0-52e2aa8b8d38_main.txt',0,NULL),('CL1002','I1000','testprof',20,2022,NULL,'d0a4e8dc-9059-4c74-9539-9eb651080e93_ㅇㄴㄹㅇㄴㄹ.txt',0,NULL),('CL2000','I1003','testprof',20,2022,1,'c92e277e-6fff-4301-8487-2389f59b05e4_OPEN API.pdf',0,NULL),('CL2001','I1002','testprof',20,2022,1,'ce3992b6-0217-483e-bc53-4cdad695ee7c_OPEN API.pdf',0,NULL),('fff1000','Sc1000','08268070',20,222,1,'560fccb0-46c0-4242-aee3-e8f73547b0a0_jsp기본개념0607.txt',0,NULL),('I10016','I1000','08268070',20,2022,1,'계획서',1,NULL),('I1111','I1000','08268070',20,2022,1,'강의계획서',0,NULL),('I220824','I1000','08268070',20,2022,1,'핫한 용강사 계획서',1,NULL),('s10005','Sc1000','08268070',20,2222,1,'ddd',2,NULL),('s10013','I1000','08268070',20,2022,1,'계획서',1,NULL),('s10014','I1000','08268070',20,2022,1,'계획서',0,NULL),('s10015','I1000','08268070',20,2022,1,'계획서',1,NULL),('s10016','I1000','08268070',20,2022,1,'계획서',0,NULL),('s10018','I1000','08268070',20,2022,1,'계획서',1,NULL),('s1564','Sc1000','08268070',20,2022,1,'a1f75768-4c1d-444b-bcad-b932ca0d4f25_08_Web server.pdf',1,NULL),('s789','I1000','08268070',20,2022,1,'계획서',0,NULL),('s7890','I1000','08268070',20,2022,1,'계획서',0,NULL),('sc2001','Sc1000','00265609',20,2011,1,NULL,0,NULL);
/*!40000 ALTER TABLE `k_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_member`
--

DROP TABLE IF EXISTS `k_class_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_member` (
  `class_id` varchar(100) DEFAULT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `class_member_id` varchar(100) NOT NULL,
  PRIMARY KEY (`class_member_id`),
  KEY `R_32` (`class_id`),
  KEY `R_112` (`stu_id`),
  CONSTRAINT `R_112` FOREIGN KEY (`stu_id`) REFERENCES `k_users` (`user_id`),
  CONSTRAINT `R_32` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_member`
--

LOCK TABLES `k_class_member` WRITE;
/*!40000 ALTER TABLE `k_class_member` DISABLE KEYS */;
INSERT INTO `k_class_member` VALUES ('A100','00000000','CMI4003'),('A100','11123456','CMI4004'),('A100','test123','CMI5000'),('s10013','00000000','CMI6003');
/*!40000 ALTER TABLE `k_class_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_notice`
--

DROP TABLE IF EXISTS `k_class_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_notice` (
  `class_notice_no` int(11) DEFAULT NULL,
  `class_id` varchar(100) DEFAULT NULL,
  `class_notice_title` varchar(500) DEFAULT NULL,
  `class_notice_date` date DEFAULT NULL,
  `class_notice_hit` int(11) DEFAULT NULL,
  `class_notice_file` varchar(500) DEFAULT NULL,
  `class_notice_id` varchar(100) NOT NULL,
  `class_notice_type` varchar(100) DEFAULT NULL,
  `class_notice_con` varchar(5000) DEFAULT NULL,
  `class_notice_original` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`class_notice_id`),
  KEY `R_42` (`class_id`),
  CONSTRAINT `R_42` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_notice`
--

LOCK TABLES `k_class_notice` WRITE;
/*!40000 ALTER TABLE `k_class_notice` DISABLE KEYS */;
INSERT INTO `k_class_notice` VALUES (10,'A100','dsgswrh','2022-08-30',1,'85983f4b-7f5b-4350-984b-969ccd3487b1_net_03.pdf','1000','noticedata','regsegfsefsese','net_03.pdf'),(2,'fff1000','공지지롱','2022-08-31',NULL,'39143ac8-c729-4269-aa94-a89b73db8921_net_06.pdf','2001','notice','공지지롱','net_06.pdf'),(3,'s10014','dgsgd','2022-08-31',NULL,'fd965223-89a8-4e31-8e28-49a57fca1dcb_09_FTP.pdf','2002','notice','ㅎㄴㄷㅇㅎ논','09_FTP.pdf');
/*!40000 ALTER TABLE `k_class_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_reg`
--

DROP TABLE IF EXISTS `k_class_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_reg` (
  `class_id` varchar(100) NOT NULL,
  `course_id` varchar(100) DEFAULT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `class_to` int(11) DEFAULT NULL,
  `class_year` int(11) DEFAULT NULL,
  `class_sem` int(11) DEFAULT NULL,
  `class_syl` varchar(500) DEFAULT NULL,
  `class_yn` varchar(100) DEFAULT 'n',
  `class_title` varchar(100) DEFAULT NULL,
  `class_syl_original` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `R_97` (`prof_id`),
  KEY `R_96` (`course_id`),
  CONSTRAINT `R_96` FOREIGN KEY (`course_id`) REFERENCES `k_course` (`course_id`),
  CONSTRAINT `R_97` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_reg`
--

LOCK TABLES `k_class_reg` WRITE;
/*!40000 ALTER TABLE `k_class_reg` DISABLE KEYS */;
INSERT INTO `k_class_reg` VALUES ('CL1001','I1000','testprof',20,2022,NULL,'705fd5a0-0b06-4b05-bba0-52e2aa8b8d38_main.txt','y','하하하하하하','main.txt'),('CL1002','I1000','testprof',20,2022,NULL,'d0a4e8dc-9059-4c74-9539-9eb651080e93_ㅇㄴㄹㅇㄴㄹ.txt','y','하하하하하하','ㅇㄴㄹㅇㄴㄹ.txt'),('CL1003','I1000','testprof',20,2022,1,NULL,'n','하하하하하하',''),('CL1004','I1000','testprof',20,2022,1,NULL,'n','하하하하하하',''),('CL1005','I1000','testprof',20,2022,1,'a1381334-2ed4-4e9d-90f9-8c82b6024dd6_OPEN API.pdf','n','하하하하하하','OPEN API.pdf'),('CL1010','Sc1000','03205116',20,2022,1,'500d44be-fd07-47da-9d12-d77ed9472c1a_OPEN API.pdf','n','하하하하하하','OPEN API.pdf'),('CL2000','I1003','testprof',20,2022,1,'c92e277e-6fff-4301-8487-2389f59b05e4_OPEN API.pdf','y','신청합니다','OPEN API.pdf'),('CL2001','I1002','testprof',20,2022,1,'ce3992b6-0217-483e-bc53-4cdad695ee7c_OPEN API.pdf','y','빨리 허가 해주세요','OPEN API.pdf'),('CL2004','I1002','testprof',20,2022,1,'106d3b5c-b93a-4a4d-9930-fdc6d7da8425_OPEN API.pdf','n','빨리 허가 해주세요','OPEN API.pdf');
/*!40000 ALTER TABLE `k_class_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_schedule`
--

DROP TABLE IF EXISTS `k_class_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_schedule` (
  `class_id` varchar(100) DEFAULT NULL,
  `class_sch_date` date DEFAULT NULL,
  `class_sch_id` varchar(100) NOT NULL,
  PRIMARY KEY (`class_sch_id`),
  KEY `R_116` (`class_id`),
  CONSTRAINT `R_116` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_schedule`
--

LOCK TABLES `k_class_schedule` WRITE;
/*!40000 ALTER TABLE `k_class_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_class_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_time`
--

DROP TABLE IF EXISTS `k_class_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_time` (
  `class_id` varchar(100) NOT NULL,
  `class_timetable_id` varchar(100) DEFAULT NULL,
  `room_id` varchar(100) DEFAULT NULL,
  KEY `R_28` (`class_id`),
  KEY `R_89` (`class_timetable_id`),
  KEY `R_90` (`room_id`),
  CONSTRAINT `R_28` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`),
  CONSTRAINT `R_89` FOREIGN KEY (`class_timetable_id`) REFERENCES `k_class_timetable` (`class_timetable_id`),
  CONSTRAINT `R_90` FOREIGN KEY (`room_id`) REFERENCES `k_rooms` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_time`
--

LOCK TABLES `k_class_time` WRITE;
/*!40000 ALTER TABLE `k_class_time` DISABLE KEYS */;
INSERT INTO `k_class_time` VALUES ('A100','T1013','B200');
/*!40000 ALTER TABLE `k_class_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_class_timetable`
--

DROP TABLE IF EXISTS `k_class_timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_class_timetable` (
  `class_timetable_id` varchar(100) NOT NULL,
  `class_timetable_name` varchar(100) DEFAULT NULL,
  `class_timetable_code` varchar(100) DEFAULT NULL,
  `class_timetable_days` varchar(100) DEFAULT NULL,
  `class_timetable_start` time DEFAULT NULL,
  `class_timetable_end` time DEFAULT NULL,
  `sch_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_timetable_id`),
  KEY `R_136` (`sch_id`),
  CONSTRAINT `R_136` FOREIGN KEY (`sch_id`) REFERENCES `k_schedule` (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_class_timetable`
--

LOCK TABLES `k_class_timetable` WRITE;
/*!40000 ALTER TABLE `k_class_timetable` DISABLE KEYS */;
INSERT INTO `k_class_timetable` VALUES ('T1013','1교시','TC1013','D1000','09:00:00','09:50:00','a1000'),('T1014','2교시','TC1014','D1001','10:00:00','10:50:00','a1000'),('T1015','3교시','TC1015','D1002','11:00:00','11:50:00','a1000'),('T1016','4교시','TC1016','D1003','12:00:00','12:50:00','a1000'),('T1017','점심시간','TC1017','D1004','12:50:00','14:00:00','a1000'),('T1018','5교시','TC1018','D1005','14:00:00','14:50:00','a1000'),('T1019','6교시','TC1019','D1006','15:00:00','15:50:00','a1000'),('T1020','7교시','TC1020','D1007','16:00:00','16:50:00','a1000'),('T1021','8교시','TC1021','D1008','17:00:00','17:50:00','a1000');
/*!40000 ALTER TABLE `k_class_timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_course`
--

DROP TABLE IF EXISTS `k_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_course` (
  `major_id` varchar(100) DEFAULT NULL,
  `course_id` varchar(100) NOT NULL,
  `course_title` varchar(100) DEFAULT NULL,
  `course_content` varchar(5000) DEFAULT NULL,
  `course_type` varchar(100) DEFAULT NULL,
  `course_credit` double DEFAULT 0,
  `course_openday` date DEFAULT NULL,
  `course_closeday` date DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `R_11` (`major_id`),
  CONSTRAINT `R_11` FOREIGN KEY (`major_id`) REFERENCES `k_major` (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_course`
--

LOCK TABLES `k_course` WRITE;
/*!40000 ALTER TABLE `k_course` DISABLE KEYS */;
INSERT INTO `k_course` VALUES ('1015','I1000','Spring','spring배우는 수업','필수전공',3,'2020-07-16','2022-07-16'),('1015','I1001','Spring Boot','spring Boot 배우는 수업','선택전공',2,'2022-08-30','2024-08-30'),('1015','I1002','Html',' Html 배우는 수업','필수전공',3,'2022-08-30','2024-08-30'),('1015','I1003','javaScript','javaScript 배우는 수업','필수전공',3,'2022-08-30','2024-08-30'),('1015','I1004','jquery','jquery 배우는 수업','선택전공',3,'2022-08-30','2024-08-30'),('1015','I1005','DB베이스','DB 배우는 수업','필수전공',3,'2022-08-30','2024-08-30'),('1014','Sc1000','사회의 악','사회는 악이라는 것을 가르친다','필수전공',2,'2020-07-16','2022-07-16');
/*!40000 ALTER TABLE `k_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_credit`
--

DROP TABLE IF EXISTS `k_credit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_credit` (
  `credit_total` int(11) DEFAULT NULL,
  `credit_major` int(11) DEFAULT NULL,
  `credit_lib` int(11) DEFAULT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  KEY `R_137` (`stu_id`),
  CONSTRAINT `R_137` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_credit`
--

LOCK TABLES `k_credit` WRITE;
/*!40000 ALTER TABLE `k_credit` DISABLE KEYS */;
INSERT INTO `k_credit` VALUES (100,70,30,'01174314'),(110,82,28,'11123456');
/*!40000 ALTER TABLE `k_credit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_gpa`
--

DROP TABLE IF EXISTS `k_gpa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_gpa` (
  `score_id` varchar(100) DEFAULT NULL,
  `gpa_id` varchar(100) NOT NULL,
  `gpa_point` double DEFAULT NULL,
  `gpa_grade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`gpa_id`),
  KEY `R_37` (`score_id`),
  CONSTRAINT `R_37` FOREIGN KEY (`score_id`) REFERENCES `k_scores` (`score_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_gpa`
--

LOCK TABLES `k_gpa` WRITE;
/*!40000 ALTER TABLE `k_gpa` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_gpa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_gpa_standard`
--

DROP TABLE IF EXISTS `k_gpa_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_gpa_standard` (
  `gpa_standard_attn` int(11) DEFAULT NULL,
  `gpa_standard_quiz` int(11) DEFAULT NULL,
  `gpa_standard_mid` int(11) DEFAULT NULL,
  `gpa_standard_final` int(11) DEFAULT NULL,
  `class_id` varchar(100) NOT NULL,
  PRIMARY KEY (`class_id`),
  CONSTRAINT `R_18` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_gpa_standard`
--

LOCK TABLES `k_gpa_standard` WRITE;
/*!40000 ALTER TABLE `k_gpa_standard` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_gpa_standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_grad`
--

DROP TABLE IF EXISTS `k_grad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_grad` (
  `grad_credit` double DEFAULT NULL,
  `grad_major_credit` double DEFAULT NULL,
  `grad_lib_credit` double DEFAULT NULL,
  `major_id` varchar(100) DEFAULT NULL,
  `grad_id` varchar(100) NOT NULL,
  PRIMARY KEY (`grad_id`),
  KEY `R_77` (`major_id`),
  CONSTRAINT `R_77` FOREIGN KEY (`major_id`) REFERENCES `k_major` (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_grad`
--

LOCK TABLES `k_grad` WRITE;
/*!40000 ALTER TABLE `k_grad` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_grad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_major`
--

DROP TABLE IF EXISTS `k_major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_major` (
  `major_id` varchar(100) NOT NULL,
  `major_name` varchar(100) DEFAULT NULL,
  `major_openday` date DEFAULT NULL,
  `major_closeday` date DEFAULT NULL,
  PRIMARY KEY (`major_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_major`
--

LOCK TABLES `k_major` WRITE;
/*!40000 ALTER TABLE `k_major` DISABLE KEYS */;
INSERT INTO `k_major` VALUES ('1002','중어중문학과','2004-05-15','2005-12-13'),('1003','화학과','2007-01-30','2008-02-12'),('1004','노어노문학과','2004-03-08','2005-10-27'),('1010','경영학과','2008-09-26',NULL),('1011','건축학과','2009-04-11',NULL),('1012','국어국문학과','2002-11-09',NULL),('1013','사회복지학과','1995-11-23',NULL),('1014','사회학과','2004-06-16',NULL),('1015','컴퓨터공학과','1997-10-15',NULL),('1016','심리학과','2004-02-04',NULL),('1017','언론정보학과','2009-04-04',NULL),('1018','언어학과','2002-12-22',NULL),('1019','영어영문학과','1998-08-01',NULL),('1020','의류학과','2000-03-18',NULL),('1021','철학과','2007-03-03',NULL),('1022','통계학과','2006-04-18',NULL),('1023','물리학과','2001-05-21',NULL),('1024','기계공학과','1997-07-02',NULL),('1025','수학과','2000-01-19',NULL),('1026','체육학과','2007-11-07',NULL);
/*!40000 ALTER TABLE `k_major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_matching`
--

DROP TABLE IF EXISTS `k_matching`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_matching` (
  `prof_id` varchar(100) DEFAULT NULL,
  `matching_date` date DEFAULT NULL,
  `matching_type` varchar(100) DEFAULT NULL,
  `matching_id` varchar(100) NOT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`matching_id`),
  KEY `R_55` (`stu_id`),
  KEY `R_56` (`prof_id`),
  CONSTRAINT `R_55` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`),
  CONSTRAINT `R_56` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_matching`
--

LOCK TABLES `k_matching` WRITE;
/*!40000 ALTER TABLE `k_matching` DISABLE KEYS */;
INSERT INTO `k_matching` VALUES ('00217253','2022-08-26','1','1','01115942'),('00217253','2022-08-29','1','1001','test123'),('00265609','2022-08-26','1','2','01132538'),('00265609','2022-08-30','1','2001','00103086'),('00217253','2022-08-30','1','2002','00149383'),('00265609','2022-08-30','1','2003','00149776'),('00217253','2022-08-30','1','2004','01103888'),('00265609','2022-08-30','1','2006','test123'),('testprof','2022-08-30','0','2007','test123'),('testprof','2022-08-30','0','5','01119665'),('testprof','2022-08-30','0','6','01103888'),('testprof','2022-08-30','0','7','00103086'),('testprof','2022-08-30','0','8','00149383'),('testprof','2022-08-30','0','9','01132538');
/*!40000 ALTER TABLE `k_matching` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_matching_change`
--

DROP TABLE IF EXISTS `k_matching_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_matching_change` (
  `stu_id` varchar(100) DEFAULT NULL,
  `matching_change_yn` varchar(100) DEFAULT NULL,
  `matching_change_date` date DEFAULT NULL,
  `matching_change_reject` varchar(500) DEFAULT NULL,
  `prof_id` varchar(100) DEFAULT NULL,
  `matching_change_reason` varchar(500) DEFAULT NULL,
  `matching_want` varchar(100) DEFAULT NULL,
  KEY `R_125` (`stu_id`),
  CONSTRAINT `R_125` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_matching_change`
--

LOCK TABLES `k_matching_change` WRITE;
/*!40000 ALTER TABLE `k_matching_change` DISABLE KEYS */;
INSERT INTO `k_matching_change` VALUES ('01115942','0','2022-08-26','테스트 거부 사유','00217253','적절한 사유','00265609'),('test123','1','2022-08-29',NULL,'00217253','asdasdd','00265609');
/*!40000 ALTER TABLE `k_matching_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring`
--

DROP TABLE IF EXISTS `k_mentoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring` (
  `matching_id` varchar(100) DEFAULT NULL,
  `mtr_count` int(11) DEFAULT NULL,
  `mtr_status` varchar(100) DEFAULT 'ing',
  `mtr_id` varchar(100) NOT NULL,
  `mtr_sch_id` varchar(100) DEFAULT NULL,
  `mtr_cancel` varchar(100) DEFAULT '0',
  `mtr_fileName` varchar(500) DEFAULT '0',
  `prof_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mtr_id`),
  KEY `R_131` (`mtr_sch_id`),
  KEY `R_68` (`matching_id`),
  KEY `k_mentoring_FK` (`prof_id`),
  CONSTRAINT `R_131` FOREIGN KEY (`mtr_sch_id`) REFERENCES `k_mentoring_schedule` (`mtr_sch_id`),
  CONSTRAINT `R_68` FOREIGN KEY (`matching_id`) REFERENCES `k_matching` (`matching_id`),
  CONSTRAINT `k_mentoring_FK` FOREIGN KEY (`prof_id`) REFERENCES `k_professors` (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring`
--

LOCK TABLES `k_mentoring` WRITE;
/*!40000 ALTER TABLE `k_mentoring` DISABLE KEYS */;
INSERT INTO `k_mentoring` VALUES ('2007',0,'end','1022','3011','0','0','testprof'),('2007',1,'ing','1023','3013','0','0','testprof'),('5',1,'ing','5','3012','0','0','testprof');
/*!40000 ALTER TABLE `k_mentoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring_log`
--

DROP TABLE IF EXISTS `k_mentoring_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring_log` (
  `mtr_id` varchar(100) NOT NULL,
  `mtr_log_subject` varchar(500) DEFAULT NULL,
  `mtr_log_content` varchar(7000) DEFAULT NULL,
  `mtr_log_comment` varchar(7000) DEFAULT NULL,
  `mtr_home` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mtr_id`),
  CONSTRAINT `R_69` FOREIGN KEY (`mtr_id`) REFERENCES `k_mentoring` (`mtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring_log`
--

LOCK TABLES `k_mentoring_log` WRITE;
/*!40000 ALTER TABLE `k_mentoring_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_mentoring_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring_memo`
--

DROP TABLE IF EXISTS `k_mentoring_memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring_memo` (
  `mtr_id` varchar(100) NOT NULL,
  `mtr_memo_content` varchar(10000) DEFAULT NULL,
  PRIMARY KEY (`mtr_id`),
  CONSTRAINT `R_143` FOREIGN KEY (`mtr_id`) REFERENCES `k_mentoring` (`mtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring_memo`
--

LOCK TABLES `k_mentoring_memo` WRITE;
/*!40000 ALTER TABLE `k_mentoring_memo` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_mentoring_memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_mentoring_schedule`
--

DROP TABLE IF EXISTS `k_mentoring_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_mentoring_schedule` (
  `mtr_sch_id` varchar(100) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `mtr_sch_date` date DEFAULT NULL,
  `mtr_sch_timecode` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`mtr_sch_id`),
  KEY `R_127` (`user_id`),
  KEY `k_mentoring_schedule_FK` (`mtr_sch_timecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_mentoring_schedule`
--

LOCK TABLES `k_mentoring_schedule` WRITE;
/*!40000 ALTER TABLE `k_mentoring_schedule` DISABLE KEYS */;
INSERT INTO `k_mentoring_schedule` VALUES ('2081','testprof','2022-02-10','1'),('2082','testprof','2022-02-11','1'),('2083','testprof','2022-02-09','0'),('2084','testprof','2022-02-17','1'),('2085','testprof','2022-02-17','2'),('2086','testprof','2022-02-16','0'),('2088','testprof','2022-02-01','1'),('2089','testprof','2022-02-01','3'),('2090','testprof','2022-02-01','4'),('3001','testprof','2022-02-03','3'),('3002','testprof','2022-02-04','3'),('3003','testprof','2022-02-04','4'),('3004','testprof','2022-02-04','5'),('3005','testprof','2022-08-16','1'),('3006','testprof','2022-08-16','3'),('3007','testprof','2022-08-16','4'),('3008','testprof','2022-08-22','3'),('3009','testprof','2022-08-22','5'),('3010','testprof','2022-08-22','6'),('3011','testprof','2022-08-12','0'),('3012','testprof','2022-08-12','1'),('3013','testprof','2022-08-12','4'),('3014','testprof','2022-08-12','5'),('3015','testprof','2022-08-08','2'),('3016','testprof','2022-08-26','5');
/*!40000 ALTER TABLE `k_mentoring_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_notice`
--

DROP TABLE IF EXISTS `k_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_notice` (
  `notice_id` varchar(100) NOT NULL,
  `notice_title` varchar(1000) DEFAULT NULL,
  `notice_content` varchar(10000) DEFAULT NULL,
  `notice_date` date DEFAULT NULL,
  `notice_writer` varchar(100) DEFAULT NULL,
  `notice_hit` int(11) DEFAULT NULL,
  `notice_file` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_notice`
--

LOCK TABLES `k_notice` WRITE;
/*!40000 ALTER TABLE `k_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_pay_d`
--

DROP TABLE IF EXISTS `k_pay_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_pay_d` (
  `pay_d_amount` int(11) DEFAULT NULL,
  `pay_d_count` int(11) DEFAULT NULL,
  `pay_d_bank` varchar(100) DEFAULT NULL,
  `pay_d_day` date DEFAULT NULL,
  `pay_id` varchar(100) DEFAULT NULL,
  KEY `R_95` (`pay_id`),
  CONSTRAINT `R_95` FOREIGN KEY (`pay_id`) REFERENCES `k_pay_h` (`pay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_pay_d`
--

LOCK TABLES `k_pay_d` WRITE;
/*!40000 ALTER TABLE `k_pay_d` DISABLE KEYS */;
INSERT INTO `k_pay_d` VALUES (1000000,1,'KB','2021-03-02','test123202111010'),(1000000,1,'KB','2021-09-02','test123202121010'),(250000,1,'KB','2022-03-02','test123202211010'),(250000,2,'KB','2022-04-02','test123202211010'),(250000,3,'KB','2022-05-02','test123202211010'),(250000,4,'KB','2022-06-02','test123202211010');
/*!40000 ALTER TABLE `k_pay_d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_pay_h`
--

DROP TABLE IF EXISTS `k_pay_h`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_pay_h` (
  `pay_id` varchar(100) NOT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `bill_id` varchar(100) DEFAULT NULL,
  `pay_h_total` int(11) DEFAULT 1,
  `pay_h_remain` int(11) DEFAULT 1,
  `pay_h_bal` int(11) DEFAULT NULL,
  `pay_h_yn` varchar(100) DEFAULT 'n',
  `pay_h_acc` varchar(100) DEFAULT NULL,
  `pay_h_grade` int(11) DEFAULT NULL,
  `pay_h_sem` int(11) DEFAULT NULL,
  `pay_h_div` varchar(100) DEFAULT 'b',
  PRIMARY KEY (`pay_id`),
  KEY `R_39` (`stu_id`),
  KEY `R_40` (`bill_id`),
  CONSTRAINT `R_39` FOREIGN KEY (`stu_id`) REFERENCES `k_users` (`user_id`),
  CONSTRAINT `R_40` FOREIGN KEY (`bill_id`) REFERENCES `k_bills` (`bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_pay_h`
--

LOCK TABLES `k_pay_h` WRITE;
/*!40000 ALTER TABLE `k_pay_h` DISABLE KEYS */;
INSERT INTO `k_pay_h` VALUES ('00149383202221010','00149383','202221010',1,1,1000000,'n',NULL,4,2,'b'),('00149383202311010','00149383','202311010',1,1,1000000,'n',NULL,4,2,'b'),('00149776202311026','00149776','202311026',1,1,1000000,'n',NULL,1,2,'b'),('01115942202311026','01115942','202311026',1,1,1000000,'n',NULL,3,2,'b'),('test123202111010','test123','202111010',1,0,0,'y',NULL,2,1,'b'),('test123202121010','test123','202121010',1,0,0,'y',NULL,2,2,'b'),('test123202211010','test123','202211010',4,0,0,'y',NULL,3,1,'s'),('test123202221010','test123','202221010',1,1,1000000,'n',NULL,3,1,'b'),('test123202311010','test123','202311010',1,1,1000000,'n',NULL,3,1,'b');
/*!40000 ALTER TABLE `k_pay_h` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_prof_q`
--

DROP TABLE IF EXISTS `k_prof_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_prof_q` (
  `prof_q_id` varchar(100) NOT NULL,
  `prof_q_content` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`prof_q_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_prof_q`
--

LOCK TABLES `k_prof_q` WRITE;
/*!40000 ALTER TABLE `k_prof_q` DISABLE KEYS */;
INSERT INTO `k_prof_q` VALUES ('EV1000','강의계획서가 강좌의 목표,내용,성적평가 방법 등 과목의 성격을 이해하기 쉽게 구성되었다.'),('EV1001','강의계획서 진도에 맞게 해당 주차에 온라인 수업 콘텐츠가 게시되었다'),('EV1002','강의교재나 참고자료가 수업내용을 이해하는데 적절하게 구성되었으며 다양한 학습자료가 제공되\r\n었다.\r\n'),('EV1003','학생들의 질의응답 게시판 또는 이메일, 모바일 등을 활용하여 질의 내용에 성실하게 답변하였다.\r\n'),('EV1004','과제의 방법과 성적 평가기준 및 방식은 객관적이고 합리적으로 제시되었다.\r\n'),('EV1005','과제의 내용 및 분량은 적절하였으며 강의 내용을 이해하는데 도움을 주었다'),('EV1006','이 강의를 통해 관련 지식과 전공능력(핵심역량)이 증진되었다.\r\n');
/*!40000 ALTER TABLE `k_prof_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_prof_r`
--

DROP TABLE IF EXISTS `k_prof_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_prof_r` (
  `class_id` varchar(100) DEFAULT NULL,
  `prof_r_result` varchar(500) DEFAULT NULL,
  `prof_r_date` date DEFAULT NULL,
  `prof_q_id` varchar(100) DEFAULT NULL,
  `class_member_id` varchar(100) DEFAULT NULL,
  KEY `R_54` (`class_id`),
  KEY `R_85` (`prof_q_id`),
  KEY `R_53` (`class_member_id`),
  CONSTRAINT `R_53` FOREIGN KEY (`class_member_id`) REFERENCES `k_class_member` (`class_member_id`),
  CONSTRAINT `R_54` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`),
  CONSTRAINT `R_85` FOREIGN KEY (`prof_q_id`) REFERENCES `k_prof_q` (`prof_q_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_prof_r`
--

LOCK TABLES `k_prof_r` WRITE;
/*!40000 ALTER TABLE `k_prof_r` DISABLE KEYS */;
INSERT INTO `k_prof_r` VALUES ('A100','매우좋음','2022-08-31','EV1000','CMI4003'),('A100','좋음','2022-08-31','EV1001','CMI4003'),('A100','보통이다','2022-08-31','EV1002','CMI4003'),('A100','별로다','2022-08-31','EV1003','CMI4003'),('A100','매우별로다','2022-08-31','EV1004','CMI4003'),('A100','매우별로다','2022-08-31','EV1005','CMI4003'),('A100','매우별로다','2022-08-31','EV1006','CMI4003');
/*!40000 ALTER TABLE `k_prof_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_professors`
--

DROP TABLE IF EXISTS `k_professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_professors` (
  `prof_id` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `prof_field` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_edu` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_career` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_paper` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_lab` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `prof_mentee` int(2) DEFAULT NULL,
  PRIMARY KEY (`prof_id`),
  CONSTRAINT `R_1` FOREIGN KEY (`prof_id`) REFERENCES `k_users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_estonian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_professors`
--

LOCK TABLES `k_professors` WRITE;
/*!40000 ALTER TABLE `k_professors` DISABLE KEYS */;
INSERT INTO `k_professors` VALUES ('00149383','ㅋㅋㅋ','00대학','00대학 임원','논문없음','202호실',10),('00217253','철학','00대학 00박사','00대학 소장','테스트용 논문','203호실',10),('00265609','사회복지','00대학 00박사','00대학 부소장','테스트용 논문2','503호실',10),('03205116','사회','00대학','00박사','없음','201호',10),('08268070','IT','00대학 00박','00대학 소장','시험용 논문','201호실',10),('testprof','몰루','00대학','00대학 임원','논문없음','202호실',10);
/*!40000 ALTER TABLE `k_professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_quiz_d`
--

DROP TABLE IF EXISTS `k_quiz_d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_quiz_d` (
  `quiz_d_date` date DEFAULT NULL,
  `quiz_d_openday` date DEFAULT NULL,
  `quiz_d_closeday` date DEFAULT NULL,
  `quiz_d_id` varchar(100) NOT NULL,
  `quiz_h_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`quiz_d_id`),
  KEY `R_145` (`quiz_h_id`),
  CONSTRAINT `R_145` FOREIGN KEY (`quiz_h_id`) REFERENCES `k_quiz_h` (`quiz_h_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_quiz_d`
--

LOCK TABLES `k_quiz_d` WRITE;
/*!40000 ALTER TABLE `k_quiz_d` DISABLE KEYS */;
INSERT INTO `k_quiz_d` VALUES ('2022-08-30','2022-08-05','2022-08-18','D10','HD93'),('2022-08-31','2022-08-11','2022-08-27','D1001','HD1001'),('2022-08-31','2022-08-10','2022-08-31','D1002','HD1002'),('2022-08-31','2022-08-13','2022-09-01','D1003','HD1003'),('2022-08-30','2022-08-01','2022-08-31','D11','HD94'),('2022-08-30','2022-08-01','2022-08-31','D9','HD92');
/*!40000 ALTER TABLE `k_quiz_d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_quiz_h`
--

DROP TABLE IF EXISTS `k_quiz_h`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_quiz_h` (
  `class_id` varchar(100) DEFAULT NULL,
  `quiz_h_title` varchar(500) DEFAULT NULL,
  `quiz_h_content` varchar(10000) DEFAULT NULL,
  `quiz_h_file` varchar(500) DEFAULT NULL,
  `quiz_h_id` varchar(100) NOT NULL,
  `quiz_h_seq` int(11) DEFAULT NULL,
  `quiz_h_original` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`quiz_h_id`),
  KEY `R_144` (`class_id`),
  CONSTRAINT `R_144` FOREIGN KEY (`class_id`) REFERENCES `k_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_quiz_h`
--

LOCK TABLES `k_quiz_h` WRITE;
/*!40000 ALTER TABLE `k_quiz_h` DISABLE KEYS */;
INSERT INTO `k_quiz_h` VALUES ('A100','과제지롱','과제지롱','4776b7ce-d0ef-49fb-946a-1af92e0bf231_09_FTP.pdf','HD1001',2005,'09_FTP.pdf'),('I10016','과제','과제','8f4abf7d-0c32-4e0c-a5be-c1939127b7c7_06_user-account.pdf','HD1002',2006,'06_user-account.pdf'),('s10014','과자자자자자','괒자아ㅏ앙','2d6599d0-c10b-45a4-9b23-c5e7a086686b_07_sw.pdf','HD1003',2007,'07_sw.pdf'),('A100','과제입니다','과제과제','bb0bc5ab-a8f9-4a75-8621-1127d5380b12_09_FTP.pdf','HD92',1030,'09_FTP.pdf'),('I10016','과제입니다','fdgsgsgs','f643a5eb-0897-4938-9bfb-4d6e4f598f57_net_02.pdf','HD93',1031,'net_02.pdf'),('A100','과제입니다','과제','ac641c1c-a3bb-4548-a5bf-8e11df9cf78f_10_Nameserver.pdf','HD94',1032,'10_Nameserver.pdf');
/*!40000 ALTER TABLE `k_quiz_h` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_quiz_r`
--

DROP TABLE IF EXISTS `k_quiz_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_quiz_r` (
  `quiz_r_content` varchar(10000) DEFAULT NULL,
  `quiz_r_date` date DEFAULT NULL,
  `quiz_r_file` varchar(500) DEFAULT NULL,
  `quiz_d_id` varchar(100) DEFAULT NULL,
  `quiz_r_point` int(11) DEFAULT NULL,
  `quiz_r_id` varchar(100) NOT NULL,
  `quiz_r_orginal` varchar(500) DEFAULT NULL,
  `class_member_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`quiz_r_id`),
  KEY `R_121` (`quiz_d_id`),
  KEY `class_member_id` (`class_member_id`),
  CONSTRAINT `R_121` FOREIGN KEY (`quiz_d_id`) REFERENCES `k_quiz_d` (`quiz_d_id`),
  CONSTRAINT `k_quiz_r_ibfk_1` FOREIGN KEY (`class_member_id`) REFERENCES `k_class_member` (`class_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_quiz_r`
--

LOCK TABLES `k_quiz_r` WRITE;
/*!40000 ALTER TABLE `k_quiz_r` DISABLE KEYS */;
INSERT INTO `k_quiz_r` VALUES ('ㅛㅅㅁㄹㄴㅎㄴ','2022-08-31','47a2ea9d-9617-45ed-9d25-826f691de34a_net_03.pdf','D1001',30,'R1001','net_03.pdf','CMI4003'),('ㅎㅇㅎㄴ혹노','2022-08-30','3db7a21a-69be-4db5-8d42-82c6b7a4390a_05_command.pdf','D11',NULL,'R4','05_command.pdf','CMI4003');
/*!40000 ALTER TABLE `k_quiz_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_rooms`
--

DROP TABLE IF EXISTS `k_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_rooms` (
  `room_id` varchar(100) NOT NULL,
  `room_building` varchar(100) DEFAULT NULL,
  `room_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_rooms`
--

LOCK TABLES `k_rooms` WRITE;
/*!40000 ALTER TABLE `k_rooms` DISABLE KEYS */;
INSERT INTO `k_rooms` VALUES ('A100','rolling',300),('B200','vuevuevue',700),('C300','abc',300);
/*!40000 ALTER TABLE `k_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_sch_times`
--

DROP TABLE IF EXISTS `k_sch_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_sch_times` (
  `mtr_sch_timecode` varchar(500) NOT NULL,
  `mtr_sch_start` time DEFAULT NULL,
  `mtr_sch_end` time DEFAULT NULL,
  PRIMARY KEY (`mtr_sch_timecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_sch_times`
--

LOCK TABLES `k_sch_times` WRITE;
/*!40000 ALTER TABLE `k_sch_times` DISABLE KEYS */;
INSERT INTO `k_sch_times` VALUES ('0','09:00:00','09:50:00'),('1','10:00:00','10:50:00'),('2','11:00:00','11:50:00'),('3','12:00:00','12:50:00'),('4','13:00:00','13:50:00'),('5','14:00:00','14:50:00'),('6','15:00:00','15:50:00'),('7','16:00:00','16:50:00'),('8','17:00:00','17:50:00'),('9','18:00:00','18:50:00');
/*!40000 ALTER TABLE `k_sch_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_schedule`
--

DROP TABLE IF EXISTS `k_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_schedule` (
  `sch_id` varchar(100) NOT NULL,
  `sch_start` date DEFAULT NULL,
  `sch_end` date DEFAULT NULL,
  `sch_title` varchar(500) DEFAULT NULL,
  `sch_manager` varchar(100) DEFAULT NULL,
  `sch_type` varchar(100) DEFAULT NULL,
  `sch_color` varchar(100) DEFAULT NULL,
  `sch_alarm` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_schedule`
--

LOCK TABLES `k_schedule` WRITE;
/*!40000 ALTER TABLE `k_schedule` DISABLE KEYS */;
INSERT INTO `k_schedule` VALUES ('A1000',NULL,NULL,'',NULL,NULL,NULL,NULL),('S202201','2022-03-02','2022-06-30','2022년1학기','공통','SEMESTER',NULL,NULL),('S202202','2022-09-01','2022-12-30','2022년2학기','공통','SEMESTER',NULL,NULL),('S202301','2023-03-02','2023-06-30','2023년1학기','공통','SEMESTER',NULL,NULL),('S202302','2023-09-01','2023-12-30','2023년2학기','공통','SEMESTER',NULL,NULL),('S202401','2024-03-04','2024-06-30','2024년1학기','공통','SEMESTER',NULL,NULL),('S202402','2024-09-02','2024-12-30','2024년2학기','공통','SEMESTER',NULL,NULL),('S202501','2025-03-04','2025-06-30','2025년1학기','공통','SEMESTER',NULL,NULL),('S202502','2025-09-01','2025-12-30','2025년2학기','공통','SEMESTER',NULL,NULL),('S202601','2026-03-03','2026-06-30','2026년1학기','공통','SEMESTER',NULL,NULL),('S202602','2026-09-01','2026-12-30','2026년2학기','공통','SEMESTER',NULL,NULL),('S202701','2027-03-02','2027-06-30','2027년1학기','공통','SEMESTER',NULL,NULL),('S202702','2027-09-01','2027-12-30','2027년2학기','공통','SEMESTER',NULL,NULL),('S202801','2028-03-02','2028-06-30','2028년1학기','공통','SEMESTER',NULL,NULL),('S202802','2028-09-01','2028-12-30','2028년2학기','공통','SEMESTER',NULL,NULL),('S202901','2029-03-02','2029-06-30','2029년1학기','공통','SEMESTER',NULL,NULL),('S202902','2029-09-03','2029-12-30','2029년2학기','공통','SEMESTER',NULL,NULL),('S203001','2030-03-04','2030-06-30','2030년1학기','공통','SEMESTER',NULL,NULL),('S203002','2030-09-02','2030-12-30','2030년2학기','공통','SEMESTER',NULL,NULL),('S203101','2031-03-04','2031-06-30','2031년1학기','공통','SEMESTER',NULL,NULL),('S203102','2031-09-01','2031-12-30','2031년2학기','공통','SEMESTER',NULL,NULL);
/*!40000 ALTER TABLE `k_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_scores`
--

DROP TABLE IF EXISTS `k_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_scores` (
  `score_id` varchar(100) NOT NULL,
  `class_member_id` varchar(100) DEFAULT NULL,
  `score_attn` int(11) DEFAULT NULL,
  `score_quiz` int(11) DEFAULT NULL,
  `score_mid` int(11) DEFAULT NULL,
  `score_final` int(11) DEFAULT NULL,
  PRIMARY KEY (`score_id`),
  KEY `R_124` (`class_member_id`),
  CONSTRAINT `R_124` FOREIGN KEY (`class_member_id`) REFERENCES `k_class_member` (`class_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_scores`
--

LOCK TABLES `k_scores` WRITE;
/*!40000 ALTER TABLE `k_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `k_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_student_aca`
--

DROP TABLE IF EXISTS `k_student_aca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_student_aca` (
  `aca_id` varchar(100) NOT NULL DEFAULT nextval(`kcy`.`aca_id_seq`),
  `aca_type` varchar(100) DEFAULT NULL,
  `aca_start` varchar(100) DEFAULT NULL,
  `aca_end` varchar(100) DEFAULT NULL,
  `aca_reason` varchar(100) DEFAULT NULL,
  `aca_reason_d` varchar(5000) DEFAULT NULL,
  `aca_yn` varchar(100) DEFAULT NULL,
  `aca_reject` varchar(500) DEFAULT NULL,
  `stu_id` varchar(100) DEFAULT NULL,
  `aca_date` date DEFAULT NULL,
  `aca_file` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`aca_id`),
  KEY `R_79` (`stu_id`),
  CONSTRAINT `R_79` FOREIGN KEY (`stu_id`) REFERENCES `k_students` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_student_aca`
--

LOCK TABLES `k_student_aca` WRITE;
/*!40000 ALTER TABLE `k_student_aca` DISABLE KEYS */;
INSERT INTO `k_student_aca` VALUES ('2004','더미데이터','2015-04-27',NULL,NULL,NULL,NULL,NULL,'11123456','2015-04-27',NULL),('2005','휴학','S202501','S202601','군입대','군입대하러 가요','신청중',NULL,'11123456','2022-08-31',NULL),('2006','입학','2011-03-01',NULL,NULL,NULL,NULL,NULL,'11123456','2011-03-01',NULL),('2007','휴학','S202301','S202402','수험','수험 휴학입니다!','신청중',NULL,'11123456','2022-08-31',NULL),('2009','복학','S202602',NULL,NULL,NULL,'신청중',NULL,'11123456','2022-08-31',NULL),('2010','휴학','S202602','S202602','건강문제','건강문제!!!!!!!!','신청중',NULL,'11123456','2022-08-31',NULL);
/*!40000 ALTER TABLE `k_student_aca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_students`
--

DROP TABLE IF EXISTS `k_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_students` (
  `stu_id` varchar(100) NOT NULL,
  `student_regdate` date DEFAULT NULL,
  `student_graddate` date DEFAULT NULL,
  `student_grade` int(11) DEFAULT NULL,
  `student_sem` int(11) DEFAULT NULL,
  `student_aca_yn` varchar(100) DEFAULT NULL,
  `student_prof` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`stu_id`),
  KEY `k_students_FK` (`student_prof`),
  CONSTRAINT `R_3` FOREIGN KEY (`stu_id`) REFERENCES `k_users` (`user_id`),
  CONSTRAINT `k_students_FK` FOREIGN KEY (`student_prof`) REFERENCES `k_professors` (`prof_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_students`
--

LOCK TABLES `k_students` WRITE;
/*!40000 ALTER TABLE `k_students` DISABLE KEYS */;
INSERT INTO `k_students` VALUES ('00103086',NULL,NULL,3,2,'재학','00265609'),('00149383',NULL,NULL,4,2,'재학','00217253'),('00149776',NULL,NULL,1,2,'재학','00265609'),('01103888',NULL,NULL,2,2,'재학','00217253'),('01115942',NULL,NULL,3,2,'재학','00217253'),('01119665',NULL,NULL,4,2,'재학',NULL),('01132538',NULL,NULL,1,2,'재학','00265609'),('01174314','2001-04-01',NULL,2,1,NULL,NULL),('11123456','2011-03-01',NULL,2,1,'재학',NULL),('test123',NULL,NULL,3,1,'재학','00265609');
/*!40000 ALTER TABLE `k_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `k_users`
--

DROP TABLE IF EXISTS `k_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `k_users` (
  `user_id` varchar(100) NOT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_ssn` varchar(100) DEFAULT NULL,
  `user_sex` varchar(100) DEFAULT NULL,
  `user_dept` varchar(100) DEFAULT NULL,
  `user_addr` varchar(500) DEFAULT NULL,
  `user_phone` varchar(100) DEFAULT NULL,
  `user_email` varchar(500) DEFAULT NULL,
  `user_pw` varchar(100) DEFAULT NULL,
  `user_nation` varchar(100) DEFAULT NULL,
  `user_pic` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `k_users`
--

LOCK TABLES `k_users` WRITE;
/*!40000 ALTER TABLE `k_users` DISABLE KEYS */;
INSERT INTO `k_users` VALUES ('00000000','ROLE_STU','testname','001122-3333333','F','컴퓨터공학과','','','','$2a$10$dzznctHUqEoOFqed5BtWFOa2Y/JPTcRBU40.xbwe.KCugNvgd4yYC','',NULL),('00103086','ROLE_STU','Surcombe','920603-1432965','M','물리학과','231.10.255.110','290-823-3740','bsurcombea6@samsung.com','$2a$10$7HGFkVIS6boPYEEYMm6AfusJlpfFK8XUayT8IWL1ujZYFjv.Aw.IK','China',NULL),('00149383','ROLE_STU','Bastick','990717-2063168','F','경영학과','126.200.143.232','965-264-6151','abastickcm@loc.gov','A9zPObeY1','China',NULL),('00149776','ROLE_STU','Birkmyre','830814-2555244','F','체육학과','229.222.170.27','857-851-7733','xbirkmyre1w@exblog.jp','PDun85w','Vietnam',NULL),('00217253','ROLE_PROF','Carverhill','890829-2424464','F','철학과','170.83.255.183','411-364-1115','acarverhilldc@quantcast.com','9gORyvusefy4','Sweden',NULL),('00265609','ROLE_PROF','Worvell','851226-2282172','F','사회복지학과','245.149.218.193','852-657-4821','hworvell5g@paypal.com','dDvglSCG','China',NULL),('01101225','ROLE_STU','Iles','881020-1111590','M','수학과','57.240.126.180','643-625-6708','hiles7b@tripod.com','0Mc2N90v','Greece',NULL),('01103888','ROLE_STU','Martine','820727-1262731','M','언어학과','234.61.80.67','759-424-6415','mmartine4i@accuweather.com','RhBNQcmU1OF','Japan',NULL),('01115942','ROLE_STU','Creedland','820720-2398448','F','체육학과','18.83.106.105','694-776-8562','ccreedland5@uiuc.edu','kjwN6KGn6riY','Portugal',NULL),('01119665','ROLE_STU','Rothman','860701-2313878','F','컴퓨터공학과','196.66.153.154','479-709-6694','arothman9s@geocities.com','Q4kR18soABGG','Bolivia',NULL),('01132538','ROLE_STU','Page','900725-2789155','F','사회복지학과','179.33.117.255','903-571-9514','mpage8b@friendfeed.com','TJ2ZZ0','Madagascar',NULL),('01152457','ROLE_STU','Jeremaes','991029-2551112','F','경영학과','125.48.159.38','674-637-0374','njeremaesaa@friendfeed.com','sDhYGv','China',NULL),('01158956','ROLE_STU','Pellew','930404-2616060','F','의류학과','138.103.253.23','954-844-4728','bpellew5k@guardian.co.uk','Iz06IhutgM','Sweden',NULL),('01170739','ROLE_STU','Paulley','820617-1036918','M','기계공학과','11.156.237.237','605-736-5006','epaulley3w@wisc.edu','KnTvZGf','China',NULL),('01174314','ROLE_STU','Myatt','990225-1568647','M','사회학과','94.173.119.53','754-250-8379','emyattaq@netwoeafvertising.org','$2a$10$8E.l0YPTJ.ozMt9XixQVqOo8y6IDt6IMCKDV50TqfMylMMVpROF1i','Canada',NULL),('01187591','ROLE_STU','Sheerin','911226-1235062','M','경영학과','129.79.142.20','399-475-4795','fsheerin7s@aboutads.info','DXGLUClgHe1F','Brazil',NULL),('02103984','ROLE_STU','McBeth','890119-1569375','M','언론정보학과','61.96.102.9','194-106-8930','mmcbeth7x@efawef','t74S87EWr6wX','Colombia',NULL),('02116466','ROLE_STU','Silverwood','881106-1310936','M','체육학과','157.217.207.227','746-630-7937','ssilverwooda@chronoengine.com','AAfxCaLCu','China',NULL),('02137760','ROLE_STU','Slaght','810919-1300409','M','통계학과','214.203.31.136','668-512-2755','cslaghtbb@amazon.de','08RAkqq','Canada',NULL),('02169057','ROLE_STU','Lynde','941030-2162270','F','사회복지학과','97.161.5.43','820-258-1403','tlyndea0@reference.com','4Snno40KjtO','Vietnam',NULL),('02185384','ROLE_STU','Armell','960220-1147080','M','언론정보학과','93.83.106.160','661-520-0252','larmell6j@cloudflare.com','7oWKeCR','Albania',NULL),('02186866','ROLE_STU','Mallison','870728-1728175','M','물리학과','12.142.143.237','447-193-5239','mmallison3u@arizona.edu','LH26daCSz0zO','Japan',NULL),('02281628','ROLE_PROF','McGrayle','980611-1652428','M','언론정보학과','93.43.161.56','479-167-1921','hmcgraylea1@opera.com','QmgTvb','Yemen',NULL),('02298076','ROLE_PROF','Burnsell','920330-1613584','M','물리학과','229.121.165.98','370-412-6137','pburnsellcu@dmoz.org','j8aNuUPBnR4b','China',NULL),('02345196','ROLE_ADMIN','Tuson','960530-2084287','F','인사','210.249.87.220','829-805-3631','ttuson4t@amazon.com','HXDu7A','China',NULL),('03104778','ROLE_STU','McCurlye','980808-1868807','M','심리학과','101.105.98.187','269-420-5257','dmccurlye62@infoseek.co.jp','uA3bRoPAX','China',NULL),('03115387','ROLE_STU','Sussans','900404-2719911','F','사회복지학과','251.142.247.240','737-672-7728','msussans8e@histats.com','UFjNuAEPiB','Tunisia',NULL),('03139643','ROLE_STU','Jeggo','811220-2287257','F','경영학과','102.128.143.222','195-314-5388','bjeggo5h@people.com.cn','MZ8vXr5dX8','Zambia',NULL),('03149991','ROLE_STU','Kinworthy','900111-1211625','M','국어국문학과','235.197.72.20','916-275-4289','lkinworthy7l@fc2.com','jamYJpJUDXJT','Bosnia and Herzegovina',NULL),('03158946','ROLE_STU','McBlain','900212-2131846','F','통계학과','27.121.52.140','104-884-7028','smcblain9u@tinyurl.com','DfyutHgeDY','Czech Republic',NULL),('03159576','ROLE_STU','Ashbolt','900221-1248159','M','컴퓨터공학과','2.216.193.14','514-504-8233','sashboltaw@google.fr','LTvoKO','France',NULL),('03167791','ROLE_STU','Ecclestone','850407-2018866','F','영어영문학과','96.82.121.136','652-324-7592','mecclestone6i@theguardian.com','VqBaE0','Portugal',NULL),('03169863','ROLE_STU','Cavell','960718-2551084','F','사회복지학과','84.128.195.158','396-941-6149','acavell6x@senate.gov','Is8Lie','China',NULL),('03176290','ROLE_STU','Dalby','890128-2395112','F','수학과','121.18.148.148','282-477-0934','cdalbydk@yahoo.co.jp','s0tmmrW90f4R','Portugal',NULL),('03180530','ROLE_STU','Grigorio','801220-1622346','M','체육학과','99.105.181.3','927-253-8146','sgrigoriocc@e-recht24.de','iQmKHOwwU4','Czech Republic',NULL),('03205116','ROLE_PROF','Rushworth','970102-1406849','M','사회학과','68.234.240.29','925-959-6780','lrushworth1o@loc.gov','$2a$10$8E.l0YPTJ.ozMt9XixQVqOo8y6IDt6IMCKDV50TqfMylMMVpROF1i','China',NULL),('03253506','ROLE_PROF','Phillott','831116-1787384','M','경영학과','18.204.140.206','573-157-0542','rphillott21@cdc.gov','bfGa48V','Netherlands',NULL),('03279944','ROLE_PROF','Coronas','820129-2476716','F','언어학과','202.172.213.232','835-956-3178','tcoronasc3@dagondesign.com','M7FPvOewpL','Philippines',NULL),('04102650','ROLE_STU','Brood','850212-2946240','F','철학과','194.94.54.207','191-232-5408','hbrood54@dmoz.org','WKECu9k81','Syria',NULL),('04106983','ROLE_STU','Sweetland','861015-2548733','F','심리학과','156.126.178.63','713-839-2076','ssweetland7m@arizona.edu','vFaLIjb0N','Russia',NULL),('04114599','ROLE_STU','Patten','890404-2863425','F','사회복지학과','254.61.53.131','848-476-3618','apatten1u@is.gd','xRoeQ4oNllNc','Pakistan',NULL),('04117070','ROLE_STU','Saleway','960424-1367655','M','컴퓨터공학과','201.148.175.189','852-517-8425','vsaleway5t@1688.com','mA6q0Q9','China',NULL),('04121831','ROLE_STU','Aliman','910701-2523230','F','건축학과','100.27.70.154','956-664-9249','paliman92@amazon.co.jp','O9VK9G','Philippines',NULL),('04125213','ROLE_STU','Forder','810928-2720056','F','사회복지학과','210.130.144.162','805-595-8512','rforder9w@wsj.com','aLwMPhcg','Malaysia',NULL),('04133177','ROLE_STU','Pordall','980308-1270499','M','언어학과','222.70.115.242','166-428-7947','kpordallbw@salon.com','ZhxdcZF8gTw5','Nigeria',NULL),('04165954','ROLE_STU','Sandy','810403-2667383','F','컴퓨터공학과','32.92.121.152','956-741-4543','ksandy3y@twitpic.com','qZ1Pd5pNh','Czech Republic',NULL),('04182065','ROLE_STU','Schermick','950913-2800087','F','경영학과','166.27.43.160','314-429-1876','aschermick15@cargocollective.com','oozrzwXDzw','Finland',NULL),('04256872','ROLE_PROF','Pattillo','811026-1231811','M','통계학과','78.231.121.252','884-256-9556','cpattilloz@google.ru','UpihdAzLL','Sweden',NULL),('04291160','ROLE_PROF','Eam','840319-1509109','M','통계학과','80.241.246.214','203-290-0643','meam2s@spiegel.de','PiWFb7gf','Brazil',NULL),('04345712','ROLE_ADMIN','Cardillo','940730-1984040','M','인사','138.255.40.204','579-643-0857','hcardillop@ted.com','k2FPDNXN8cw','China',NULL),('05120221','ROLE_STU','Reinbeck','931221-2573082','F','철학과','236.174.10.211','700-299-6618','vreinbeckdl@rediff.com','iN4d7qEGT','Portugal',NULL),('05134454','ROLE_STU','Holywell','880413-1711674','M','언론정보학과','105.242.134.118','478-825-2263','kholywellch@vinaora.com','uj8kJNQT4Ot','Indonesia',NULL),('05151227','ROLE_STU','Andrysiak','980507-2336352','F','체육학과','131.225.25.28','498-418-1104','randrysiak55@spiegel.de','vb7d1oaJ','Egypt',NULL),('05190097','ROLE_STU','Tale','800219-2362907','F','건축학과','24.71.92.21','516-741-4874','ktale4n@moonfruit.com','8jy9Ju3GDv','United States',NULL),('05193283','ROLE_STU','Farloe','980107-2213547','F','심리학과','91.242.156.13','797-285-6617','efarloecn@globo.com','xZGA6lD','Russia',NULL),('05205405','ROLE_PROF','Theunissen','820921-2177952','F','언어학과','114.240.108.120','458-707-8244','htheunissen3r@ebay.com','kc23kT','China',NULL),('05237415','ROLE_PROF','Calvard','841219-2315915','F','심리학과','222.13.151.6','179-522-8539','acalvard95@stanford.edu','u62VeH','China',NULL),('05348590','ROLE_ADMIN','Brandon','861215-1916731','M','재무','246.206.40.202','846-603-7749','rbrandonbv@amazon.co.uk','UPRMOfpAS','Russia',NULL),('06107937','ROLE_STU','Mathys','840421-2189988','F','사회학과','123.152.146.147','738-261-1996','bmathyscs@bigcartel.com','ZFMSywQl3s','United Kingdom',NULL),('06130692','ROLE_STU','Cunliffe','951129-1883796','M','컴퓨터공학과','186.192.96.70','933-420-7593','kcunliffe3x@scientificamerican.com','CdSALz1wc','Vietnam',NULL),('06139948','ROLE_STU','Hinstridge','850604-1669705','M','기계공학과','219.252.181.182','850-198-2583','thinstridgebi@so-net.ne.jp','ZM8eFCD','Poland',NULL),('06144158','ROLE_STU','Chillistone','981024-2945677','F','철학과','170.242.206.203','979-129-4105','nchillistone7v@usatoday.com','tohtp0xS2Iwu','Philippines',NULL),('06160685','ROLE_STU','Girodon','960903-1998142','M','영어영문학과','3.209.145.152','605-290-0414','jgirodon8j@nymag.com','OZlyhF','China',NULL),('06162353','ROLE_STU','Rushton','900320-2806703','F','건축학과','25.120.254.4','323-829-8446','nrushton3e@dagondesign.com','etVOhdvjDy4','Costa Rica',NULL),('06171730','ROLE_STU','Waple','940423-1285376','M','의류학과','173.43.121.111','270-766-0953','bwaple90@bandcamp.com','kmqaDPk2Hl9T','Indonesia',NULL),('06198626','ROLE_STU','De Maria','940906-2699415','F','경영학과','120.98.21.255','341-354-1908','rdemaria5f@blogspot.com','ID2WPZ7TTgHu','China',NULL),('06200595','ROLE_PROF','Aire','851016-2152979','F','심리학과','15.173.229.53','116-605-2733','aaire91@wix.com','mWuN7pF','Indonesia',NULL),('06281484','ROLE_PROF','Fissenden','840813-2936806','F','심리학과','156.163.92.39','417-935-4068','kfissenden24@youku.com','B5eDjHhNYgq','China',NULL),('06283617','ROLE_PROF','Varden','960703-2503814','F','기계공학과','133.205.1.200','282-631-2461','jvardenbu@people.com.cn','C2ea378','Indonesia',NULL),('07100951','ROLE_STU','Carpe','850712-1037140','M','수학과','182.230.147.245','953-983-0341','acarped4@etsy.com','VvIbiEWIQ1','China',NULL),('07126054','ROLE_STU','Desouza','910716-2058812','F','심리학과','248.16.162.24','887-584-8158','rdesouzac6@amazon.co.jp','YpuyBjILG4e','Russia',NULL),('07139702','ROLE_STU','Frusher','970603-1045562','M','수학과','7.109.51.238','913-512-2970','bfrusher3p@irs.gov','lzsFcd','Slovenia',NULL),('07144726','ROLE_STU','Bazoche','800924-2117572','F','통계학과','141.36.94.184','723-519-3545','rbazoche1j@cam.ac.uk','sX9H1DlP4','Mauritius',NULL),('07165230','ROLE_STU','Hedditch','980903-2495047','F','건축학과','216.173.223.158','889-218-7213','hhedditch8n@independent.co.uk','9zJuATm2','Indonesia',NULL),('07169336','ROLE_STU','O\'Reilly','851211-2886042','F','체육학과','32.238.161.74','959-131-6101','moreilly7u@tamu.edu','sD96jzdI','Sweden',NULL),('07178184','ROLE_STU','Jay','871001-1712080','M','심리학과','29.175.203.29','920-664-4499','ejayam@samsung.com','OXElDi0E','Poland',NULL),('07183946','ROLE_STU','Hullyer','961220-2914287','F','언론정보학과','160.178.187.108','868-903-1635','rhullyer78@webs.com','v6ypgkg','China',NULL),('07185991','ROLE_STU','Haithwaite','930724-1562606','M','언론정보학과','232.179.187.135','725-520-5409','ehaithwaitel@time.com','PgZkFlPgc','Croatia',NULL),('07231165','ROLE_PROF','MacShirrie','800201-1955295','M','영어영문학과','197.32.24.190','810-941-2079','pmacshirrieb@dropbox.com','2wfswhqU','Indonesia',NULL),('07277873','ROLE_PROF','Slograve','880419-1805160','M','사회학과','129.6.79.61','653-760-0628','rslograve4p@google.fr','Kgq0pum','Colombia',NULL),('07291274','ROLE_PROF','Parminter','880905-2782275','F','언론정보학과','248.121.226.46','442-406-8184','nparminter9i@google.nl','7Zg2FWzs','Portugal',NULL),('07299522','ROLE_PROF','Claffey','910621-1184914','M','의류학과','83.17.93.113','844-649-4150','mclaffeye@yellowpages.com','JgIuUCsU','Russia',NULL),('08101138','ROLE_STU','Huot','951120-2979479','F','언어학과','213.39.55.122','434-561-1755','jhuot7n@yahoo.com','h2V1A2dIXRb','Sweden',NULL),('08107051','ROLE_STU','McMeekin','890926-2533521','F','국어국문학과','153.248.246.253','320-660-4531','fmcmeekinb0@blogs.com','sUzIQQ3l9Q','China',NULL),('08110595','ROLE_STU','Dohrmann','840324-1576520','M','기계공학과','195.39.122.231','524-254-3127','ldohrmann45@tamu.edu','Q4eIF2mCU','Armenia',NULL),('08112846','ROLE_STU','Yole','920222-2921836','F','사회학과','55.225.145.60','458-239-6387','tyole2w@newsvine.com','PoBkq2J85UG','China',NULL),('08113217','ROLE_STU','Marsters','901225-1842530','M','컴퓨터공학과','2.146.182.27','660-252-3151','smarstersbp@elpais.com','RYVM1GxI','Philippines',NULL),('08123476','ROLE_STU','Eyam','880122-1702743','M','사회복지학과','117.148.200.222','529-366-4412','meyam7z@sina.com.cn','2ENDTi','Somalia',NULL),('08126264','ROLE_STU','Weymont','921119-1372032','M','경영학과','111.79.17.179','913-916-9366','hweymontbr@etsy.com','fVK6RjcUzj','Finland',NULL),('08138949','ROLE_STU','O\'Reilly','980601-2989288','F','사회학과','232.163.215.128','915-952-2753','boreilly72@jalbum.net','USfZLpB0e','China',NULL),('08142585','ROLE_STU','Stoad','930318-2085933','F','의류학과','44.184.71.165','212-703-8173','sstoadc9@chronoengine.com','VQRgUNQO','Indonesia',NULL),('08150892','ROLE_STU','Rapsey','830806-2398441','F','철학과','184.95.171.216','852-784-2395','jrapseybx@typepad.com','j9XWFW','China',NULL),('08157899','ROLE_STU','Antonat','891201-2935481','F','언어학과','90.190.117.18','703-211-0911','aantonat3s@umich.edu','gP1yaIbAW3On','Czech Republic',NULL),('08161294','ROLE_STU','Poluzzi','840827-2600015','F','기계공학과','215.72.46.117','215-474-1240','cpoluzzib4@nps.gov','FzmJEW3S4','Philippines',NULL),('08172305','ROLE_STU','Nudds','900907-1117968','M','의류학과','129.241.56.42','486-925-5122','snudds6w@123-reg.co.uk','KEmoKWiB9Ei','Tajikistan',NULL),('08268070','ROLE_PROF','Chezier','880609-1640817','M','컴퓨터공학과','92.235.193.164','347-365-3068','hchezier1@examiner.com','$2a$10$8E.l0YPTJ.ozMt9XixQVqOo8y6IDt6IMCKDV50TqfMylMMVpROF1i','Philippines',NULL),('08287004','ROLE_PROF','MacKonochie','891216-1442099','M','영어영문학과','6.215.76.233','973-306-2151','ymackonochie3g@homestead.com','3sORtYe4','United States',NULL),('08291798','ROLE_PROF','Buntine','910313-2146809','F','국어국문학과','173.130.164.199','918-904-4943','nbuntine5o@sina.com.cn','WmqyIi0','Argentina',NULL),('08349236','ROLE_ADMIN','McPartlin','950624-2833137','F','인사','10.240.133.61','845-433-6475','umcpartlind7@woothemes.com','JxLCbs0JOaE','Venezuela',NULL),('08374220','ROLE_ADMIN','Dedham','910809-1963851','M','인사','17.101.96.47','670-374-1071','ddedhambg@blogtalkradio.com','5PU6eoIKk','Portugal',NULL),('09103045','ROLE_STU','Vasyutkin','901222-2799936','F','언론정보학과','48.150.128.190','301-355-7624','jvasyutkinal@fda.gov','9xih7NzR','Togo',NULL),('09110058','ROLE_STU','Whooley','890711-2179707','F','사회복지학과','48.250.38.201','485-398-3383','awhooleyd2@fda.gov','MccYZdVXTh2D','Finland',NULL),('09169569','ROLE_STU','Warrener','860426-2900511','F','언론정보학과','23.141.141.123','355-667-5978','pwarrener22@deliciousdays.com','j7ej3j','Honduras',NULL),('09181881','ROLE_STU','MacKartan','930909-2037595','F','철학과','31.138.82.183','784-418-3150','cmackartanbm@nhs.uk','gr1uMm','China',NULL),('09339494','ROLE_ADMIN','Johnsey','990704-2226609','F','기획','185.167.214.35','900-428-8710','mjohnsey73@disqus.com','zYd75c','Russia',NULL),('09376772','ROLE_ADMIN','McCluin','910510-2509397','F','기획','86.24.81.188','947-405-0962','tmccluinj@nifty.com','dqRFhvqbQ','Switzerland',NULL),('09379449','ROLE_ADMIN','Rosenbloom','830812-1273585','M','재무','15.80.68.218','771-634-5615','brosenbloom81@liveinternet.ru','sKt2sRWqdDXD','Poland',NULL),('10101105','ROLE_STU','Cassels','990313-2577110','F','의류학과','113.139.69.117','146-144-1132','tcassels7p@behance.net','xKR5hXMkY','Russia',NULL),('10135925','ROLE_STU','Sabates','991002-2372148','F','컴퓨터공학과','35.19.178.50','139-490-9480','asabatesao@tinyurl.com','1EnDAtuihM5','Colombia',NULL),('10147216','ROLE_STU','Champken','941014-1312164','M','통계학과','122.175.210.71','292-357-7815','bchampken3z@biblegateway.com','WKIO0ma1h3WN','Indonesia',NULL),('10156422','ROLE_STU','Hosburn','990614-2403170','F','수학과','18.251.110.202','268-903-1393','rhosburn9f@scientificamerican.com','E26EBy','Mongolia',NULL),('10173865','ROLE_STU','Bilby','920801-1915195','M','사회학과','172.50.8.95','178-171-9105','bbilbyds@slate.com','k7qOvn','Colombia',NULL),('10175411','ROLE_STU','Mattholie','990919-2068744','F','통계학과','196.100.129.64','144-105-5431','smattholiea4@squidoo.com','M9t9XKKRLjxx','Ukraine',NULL),('10188712','ROLE_STU','Ferriere','800205-1015985','M','사회학과','74.224.126.116','473-843-8771','bferriere8i@usa.gov','GTqfog1VNDbQ','Brazil',NULL),('10245479','ROLE_PROF','Carnaman','820607-2348347','F','언론정보학과','104.249.23.219','679-220-6215','vcarnamand3@gnu.org','4F3wjm8hJe1','Indonesia',NULL),('10271715','ROLE_PROF','Thompson','830620-2098327','F','기계공학과','205.202.63.24','906-609-2538','nthompson34@discuz.net','N7L0Xg3TQCO8','Philippines',NULL),('10278966','ROLE_PROF','Catt','820523-2710954','F','영어영문학과','61.65.213.116','146-650-3771','gcatt96@google.pl','pD5YTplEx7B','Ivory Coast',NULL),('10298843','ROLE_PROF','Chamberlen','850804-2294629','F','사회복지학과','123.163.197.186','648-346-8585','mchamberlen1p@washingtonpost.com','iUME7wSpSi','Poland',NULL),('11118142','ROLE_STU','Ecob','910212-1424423','M','통계학과','252.131.48.209','771-132-4416','mecob2x@amazon.co.jp','bnQxGwy0UxE','Poland',NULL),('11123456','ROLE_STU','박찬호','950401-2123456','F','영어영문학과','서울시 여의도','010-1111-2222','pch@ajefaw.com','$2a$10$GDSn9FFeO2Sc97LlLNq7Fek3mBw4Y5AqUzLY4gXEiFDMBlMIV1xY.','한국','01174314.jpg'),('11126385','ROLE_STU','Dale','800703-2036889','F','수학과','185.180.188.221','469-846-0987','adale2c@guardian.co.uk','Vz0mR1oF4','France',NULL),('11135820','ROLE_STU','Japp','870126-2425184','F','국어국문학과','207.143.59.209','773-161-3634','ljapp8k@marriott.com','40XqLp','United States',NULL),('11155787','ROLE_STU','Perocci','860904-1500124','M','통계학과','143.220.47.184','529-230-0755','lperocciak@nydailynews.com','DtJ8yPQ27','Ukraine',NULL),('11155891','ROLE_STU','Stannering','980222-2426979','F','사회복지학과','144.30.101.82','134-466-7687','dstanneringcw@youtube.com','mXi2WVXDkYlU','China',NULL),('11175038','ROLE_STU','Bothen','890525-1551572','M','통계학과','232.54.214.122','126-433-0399','pbothencj@cyberchimps.com','uRV8WknzObx','China',NULL),('11184366','ROLE_STU','Farlam','840826-1799771','M','경영학과','137.36.211.68','664-426-6082','sfarlamc1@aefwef','yC1QeXpR','Indonesia',NULL),('11185346','ROLE_STU','Phifer','901207-1818648','M','의류학과','164.223.191.65','353-993-8857','jphifer2m@naver.com','Xedig4NF','Indonesia',NULL),('11186205','ROLE_STU','Hodgins','991008-1249144','M','의류학과','217.83.85.236','261-888-3432','fhodginsag@mayoclinic.com','z2y5J0sh','China',NULL),('11210096','ROLE_PROF','Rolfs','950928-2025032','F','의류학과','24.58.51.69','212-404-5862','lrolfs6q@dyndns.org','WvdZeVy8yzw','United States',NULL),('11236532','ROLE_PROF','Tabourin','920806-2415613','F','의류학과','142.163.20.153','353-858-0518','ytabourin16@technorati.com','YqG7WXl','Japan',NULL),('11245302','ROLE_PROF','Petrusch','820521-2373475','F','수학과','56.83.68.233','847-509-3428','epetrusch8f@com.com','XRaqTFBGX','Indonesia',NULL),('11252732','ROLE_PROF','De Mattia','840714-2909239','F','통계학과','144.18.158.108','891-235-4197','ademattiav@about.com','Wtoh7s','Palestinian Territory',NULL),('11371696','ROLE_ADMIN','Oguz','940325-2030614','F','인사','183.216.97.73','692-147-5816','woguz3n@phpbb.com','oN7qmIMsD','Indonesia',NULL),('12108821','ROLE_STU','Insworth','800924-2584984','F','철학과','90.73.114.155','623-610-6709','dinsworth7h@prlog.org','COgdeG','Russia',NULL),('12110058','ROLE_STU','Brine','820418-1248941','M','국어국문학과','1.245.36.15','127-728-8964','cbrine2i@samsung.com','7dx7EKE','China',NULL),('12130744','ROLE_STU','Karadzas','940727-2019365','F','컴퓨터공학과','19.205.105.56','131-261-4869','fkaradzas5z@imageshack.us','xgt5A3NG7F','Palestinian Territory',NULL),('12131053','ROLE_STU','Meechan','830812-1719220','M','언론정보학과','44.240.34.29','462-413-0396','rmeechani@cornell.edu','eSaRWjlNM2','South Africa',NULL),('12144760','ROLE_STU','Swettenham','811009-1759115','M','영어영문학과','97.61.206.210','606-820-7239','jswettenhamy@photobucket.com','vqdHLqg0dVL','Indonesia',NULL),('12172877','ROLE_STU','Whyard','800928-2060351','F','물리학과','68.174.51.94','887-113-5957','gwhyard2f@meetup.com','iysIiO3p','Belarus',NULL),('12188975','ROLE_STU','Dysart','891021-1709490','M','언어학과','169.213.220.143','945-120-4707','edysart3f@washingtonpost.com','LiPARUeHUgDF','Russia',NULL),('12229475','ROLE_PROF','Patrick','850308-1214676','M','철학과','49.241.1.224','806-265-2067','apatrick79@jiathis.com','p3N5Af6','China',NULL),('12271194','ROLE_PROF','Scipsey','820223-1529053','M','의류학과','213.228.128.68','417-498-4494','sscipsey7y@amazonaws.com','y3TMpdwmTe','Indonesia',NULL),('12294120','ROLE_PROF','Pretti','880209-2966957','F','수학과','21.1.118.133','154-579-0410','npretticp@netvibes.com','x18O9Kl','Brazil',NULL),('12392705','ROLE_ADMIN','Sennett','860830-1193929','M','재무','143.175.141.210','455-380-8766','fsennettcd@ox.ac.uk','PPjsTMLUG','Brazil',NULL),('13108574','ROLE_STU','Stovold','950406-1318337','M','물리학과','142.188.78.206','797-692-9211','gstovoldce@chron.com','DSNwUb','Thailand',NULL),('13113512','ROLE_STU','Martinson','891111-2880116','F','의류학과','217.246.123.118','683-594-0560','amartinsonw@google.co.jp','AQubzW','Greece',NULL),('13137023','ROLE_STU','Labrom','840313-2514781','F','언어학과','61.71.228.53','883-738-0912','zlabrom2p@icq.com','odE5iPd0RQG','Portugal',NULL),('13139981','ROLE_STU','Lightwood','860713-1517871','M','언어학과','74.250.125.38','757-238-1987','olightwood46@columbia.edu','eJHbv6kqLQ','Egypt',NULL),('13186274','ROLE_STU','Leisman','840728-2924674','F','물리학과','19.74.19.65','984-764-9240','sleisman59@w3.org','jFovzg58','China',NULL),('13194220','ROLE_STU','Littlejohn','800911-2130734','F','언론정보학과','40.217.175.9','532-323-1591','llittlejohn2z@reverbnation.com','AoKm0HGl02','Ukraine',NULL),('13258522','ROLE_PROF','Dolman','800922-2276827','F','컴퓨터공학과','11.6.13.162','690-875-2709','gdolmandv@tamu.edu','870vjEUlqh','Uruguay',NULL),('13311712','ROLE_ADMIN','Walford','870408-2218417','F','기획','182.115.100.217','931-679-9668','mwalford9m@gov.uk','5bk2wXv','Indonesia',NULL),('13314969','ROLE_ADMIN','Petteford','830112-1678216','M','기획','55.126.114.92','311-287-3372','fpetteford7c@phpbb.com','ecXUX0kAavZ','Indonesia',NULL),('13385880','ROLE_ADMIN','Rudgley','840407-1868771','M','재무','48.102.27.99','596-654-6226','hrudgley9x@storify.com','D3XSx1','Philippines',NULL),('14103134','ROLE_STU','Angear','891023-1294135','M','심리학과','229.212.31.161','939-758-7336','rangears@ed.gov','Jsp6yr2qJzGL','Russia',NULL),('14106615','ROLE_STU','Haygreen','881203-2933100','F','사회학과','91.102.101.215','324-611-3789','khaygreen70@bravesites.com','ivtRDlP4','Peru',NULL),('14117683','ROLE_STU','Bamlet','990506-1066113','M','언어학과','161.14.185.81','673-937-5831','bbamletcy@360.cn','rnI9yFrN','Poland',NULL),('14121313','ROLE_STU','Sivil','930803-1703993','M','기계공학과','50.92.111.176','427-104-2059','esivilbn@ehow.com','743WmADW7Umb','Iran',NULL),('14121627','ROLE_STU','Muir','910421-2574102','F','컴퓨터공학과','205.163.224.187','523-375-2146','lmuir8c@mozilla.org','4GGFbl','Sweden',NULL),('14126305','ROLE_STU','Brister','920209-1670835','M','심리학과','201.13.88.185','992-729-5229','mbrister7a@nydailynews.com','5F8fFXU','Nigeria',NULL),('14137896','ROLE_STU','Farenden','871012-1614480','M','기계공학과','104.94.45.35','592-948-5617','gfarenden3o@ca.gov','BSJMOdcjv36I','Brazil',NULL),('14160233','ROLE_STU','Lorence','911224-2589195','F','국어국문학과','43.108.212.87','532-597-3230','olorence87@ebay.com','dhlPbq54','Myanmar',NULL),('14184145','ROLE_STU','Jeary','880125-1759332','M','의류학과','147.109.30.235','764-508-5798','mjeary9q@i2i.jp','FWegDeVKwYtq','Ukraine',NULL),('14210481','ROLE_PROF','Gocke','960916-1436131','M','물리학과','64.214.51.228','134-988-2569','hgocke4l@wordpress.org','SGKiPW4JxX','Philippines',NULL),('14234456','ROLE_PROF','Sallinger','870105-1423076','M','사회복지학과','215.216.133.191','679-208-2066','dsallinger1n@reuters.com','IxImaMOZ8Fm','Peru',NULL),('14250168','ROLE_PROF','Hartfield','820630-1723119','M','컴퓨터공학과','199.6.32.45','628-224-9189','chartfield0@ibm.com','hQzeOl','China',NULL),('14268611','ROLE_PROF','Shelmerdine','850625-2318283','F','국어국문학과','28.106.75.28','350-780-2665','sshelmerdine2u@ovh.net','LsYtwAFZ','China',NULL),('14271791','ROLE_PROF','Gorch','860701-1913951','M','통계학과','39.119.68.215','473-348-5984','ggorch1l@joomla.org','Rlh7JOKTJl7z','Indonesia',NULL),('14272236','ROLE_PROF','Biddy','910109-1114394','M','사회학과','249.132.235.94','250-826-7229','fbiddy8u@dyndns.org','meBLAmSB7n9','Philippines',NULL),('15106737','ROLE_STU','Cubbon','910929-1455715','M','수학과','167.242.94.131','500-196-9773','acubbonad@cafepress.com','rgXNcKd','Nigeria',NULL),('15107174','ROLE_STU','Blenkin','860827-2654620','F','사회복지학과','102.231.120.213','612-209-0464','nblenkin8r@economist.com','EEc0um','Argentina',NULL),('15108668','ROLE_STU','Rack','890224-2093389','F','컴퓨터공학과','200.7.183.103','374-257-2683','erackbz@europa.eu','CeAvoW','Philippines',NULL),('15114325','ROLE_STU','Bencher','921221-1954479','M','사회학과','188.164.166.169','644-276-4833','gbencher8@businesswire.com','b6bjGZ','China',NULL),('15118598','ROLE_STU','Benaine','810925-1295429','M','국어국문학과','181.115.77.9','758-520-9089','wbenainebs@de.vu','SukNCA','China',NULL),('15122208','ROLE_STU','Barthrop','910705-2452835','F','건축학과','154.185.64.219','426-539-5658','nbarthrop61@nationalgeographic.com','cDNinYT4','Colombia',NULL),('15127860','ROLE_STU','Strevens','860722-2251184','F','경영학과','154.90.210.129','978-683-2779','jstrevens9a@nationalgeographic.com','cgGm3j','China',NULL),('15147602','ROLE_STU','Peddowe','950324-1776633','M','국어국문학과','6.218.209.116','870-451-6187','gpeddowear@a8.net','7eOHuH8VYL','Norway',NULL),('15223287','ROLE_PROF','Tuminini','880725-1399928','M','철학과','4.14.42.157','202-512-6558','dtuminini29@ask.com','JlkFrR00','China',NULL),('15231565','ROLE_PROF','Petrasek','850708-2630858','F','물리학과','233.32.178.159','420-116-7422','cpetrasek94@bloomberg.com','msbvKbf','Brazil',NULL),('15262813','ROLE_PROF','Brand','940713-1507126','M','영어영문학과','108.28.55.25','493-734-0651','dbrand1v@miibeian.gov.cn','k5Y1DMDSOKHK','Greece',NULL),('16101803','ROLE_STU','Mellor','940404-1839114','M','언어학과','140.44.214.230','781-718-2902','jmellor8o@wsj.com','rqSIeAYW','Nigeria',NULL),('16102611','ROLE_STU','Skala','920914-1149707','M','경영학과','125.47.249.79','780-875-0064','nskalad1@nih.gov','dkxPFQd','Thailand',NULL),('16110752','ROLE_STU','Luberto','880710-1906733','M','건축학과','237.182.64.30','453-632-0523','kluberto2e@mit.edu','dep3ocs6sW','Greece',NULL),('16116861','ROLE_STU','Slowcock','970529-1768390','M','심리학과','189.139.36.209','975-897-7562','pslowcock9v@whitehouse.gov','r55irXSq','China',NULL),('16119134','ROLE_STU','Burnup','881205-1487445','M','영어영문학과','95.104.223.1','778-415-9826','tburnup6l@macromedia.com','Cb9s5NSBl','Indonesia',NULL),('16122646','ROLE_STU','Haye','800428-1744237','M','건축학과','249.9.80.179','584-339-7837','khaye6y@about.me','UnfY73xkjGBk','Yemen',NULL),('16126888','ROLE_STU','Colbran','940220-2440477','F','철학과','31.125.191.24','984-523-3130','fcolbran2a@goo.gl','vzawQB','Albania',NULL),('16137684','ROLE_STU','Winchester','920225-1891391','M','사회학과','148.116.48.48','692-987-0634','pwinchester4z@dailymail.co.uk','iLkEbd0','Argentina',NULL),('16154463','ROLE_STU','Farrans','880616-1721812','M','사회학과','82.244.193.70','392-655-8853','bfarrans6c@answers.com','tKPAXQMF','Albania',NULL),('16156846','ROLE_STU','Thorne','820217-2457227','F','컴퓨터공학과','130.161.60.208','190-337-2281','fthorne12@i2i.jp','nVlIRw','Philippines',NULL),('16164305','ROLE_STU','Janas','890603-2344702','F','국어국문학과','243.97.108.120','500-898-2952','pjanas1m@slideshare.net','EnALNCVrIL','Portugal',NULL),('16172972','ROLE_STU','Boog','970826-1868057','M','건축학과','230.212.202.131','528-625-1838','cboog1i@bigcartel.com','3V2G4ou','Cuba',NULL),('16175208','ROLE_STU','Loxdale','850109-2384517','F','통계학과','13.232.80.74','926-205-1490','jloxdaleco@bloglovin.com','mqopeMm0','China',NULL),('16180053','ROLE_STU','Ianittello','980806-1415913','M','컴퓨터공학과','187.252.19.217','988-183-2224','kianittellof@php.net','tFyfZnO','Indonesia',NULL),('16180882','ROLE_STU','Oliver-Paull','910205-1192075','M','언론정보학과','71.40.85.101','725-676-2137','coliverpaull3i@yelp.com','M4YfsJgaQaU','Indonesia',NULL),('16197429','ROLE_STU','Polfer','840422-2244311','F','체육학과','243.39.71.246','484-841-0490','apolferas@desdev.cn','PzBr9uBwU','Paraguay',NULL),('16208163','ROLE_PROF','Pooly','850916-2418523','F','건축학과','217.32.113.49','559-874-7321','bpooly6f@ucoz.com','QKtGjzNUC','Canada',NULL),('16234199','ROLE_PROF','Gehringer','940230-1568759','M','언어학과','218.239.249.241','453-376-4949','hgehringer4u@nymag.com','nINjykh','Brazil',NULL),('16237302','ROLE_PROF','Ivanenkov','900211-1802788','M','체육학과','144.23.150.131','968-805-7765','sivanenkov3d@stumbleupon.com','QrXhyDZgcg','China',NULL),('16253388','ROLE_PROF','Restall','910429-1585469','M','경영학과','194.172.227.70','949-614-9841','brestall1d@amazon.co.jp','v7nZeWHJE','San Marino',NULL),('16271524','ROLE_PROF','Leyban','841211-2547011','F','경영학과','69.243.87.30','770-823-7235','tleybanai@webs.com','7cbvPOWO6s','Ukraine',NULL),('17120777','ROLE_STU','Bowering','960622-2905155','F','국어국문학과','84.85.39.162','165-281-0373','jbowering71@newsvine.com','qTCxp4spFy','Portugal',NULL),('17121572','ROLE_STU','Lenaghen','860422-2931186','F','철학과','78.71.131.36','656-320-3006','glenaghen58@cargocollective.com','kADcjddW','China',NULL),('17125917','ROLE_STU','Akehurst','910411-2957224','F','기계공학과','19.188.86.33','252-504-2791','nakehurstu@vk.com','yrCeKKyW','France',NULL),('17128399','ROLE_STU','Caverhill','900527-1070122','M','건축학과','88.140.175.64','917-807-8842','scaverhill6d@gravatar.com','C22EqQfqUX8','Philippines',NULL),('17189569','ROLE_STU','Scrivin','880822-2234951','F','언어학과','115.169.80.167','641-339-3384','yscrivin5n@jugem.jp','dQ3gYce','Russia',NULL),('17197614','ROLE_STU','Brideaux','860430-2629668','F','심리학과','65.52.150.236','200-497-7898','rbrideaux3t@cdc.gov','ES2yHoWACD','Indonesia',NULL),('17198885','ROLE_STU','Hub','890517-1968704','M','철학과','39.241.45.27','387-906-7788','nhub5u@jiathis.com','Sbhucx7cYF','Spain',NULL),('17216720','ROLE_PROF','Timmermann','940630-1299655','M','언론정보학과','140.246.48.179','625-284-6645','btimmermann53@mlb.com','jQPxRdjgx8a','Russia',NULL),('18100892','ROLE_STU','Saintpierre','800318-1731578','M','수학과','3.61.146.20','261-683-0685','osaintpierrek@howstuffworks.com','4NGB8QbTw','Poland',NULL),('18103786','ROLE_STU','Francom','830702-2640880','F','물리학과','3.210.194.233','662-101-3830','dfrancomdm@bloomberg.com','oRXEtt5ltt','Indonesia',NULL),('18116253','ROLE_STU','Verduin','830929-1802605','M','물리학과','228.168.74.184','993-714-2298','iverduin7e@google.co.uk','ZB6U85','Sweden',NULL),('18116606','ROLE_STU','Linfoot','900430-1669675','M','사회복지학과','64.103.109.176','802-948-5136','tlinfootcz@tumblr.com','VC08aJ','Poland',NULL),('18119511','ROLE_STU','Marde','810204-2726954','F','건축학과','53.139.56.80','542-344-0231','smardedp@tuttocitta.it','iCFUAFl','Vietnam',NULL),('18139962','ROLE_STU','Wadie','910204-2655329','F','언어학과','46.77.105.62','891-976-9811','awadie89@odnoklassniki.ru','kGPWZkB','Sweden',NULL),('18140568','ROLE_STU','Mulligan','960721-2046635','F','영어영문학과','56.180.74.180','178-676-6258','mmulliganb3@digg.com','BviouEzQzn','Indonesia',NULL),('18146593','ROLE_STU','Delacoste','870907-1465233','M','심리학과','115.55.148.4','543-360-2023','ddelacostecb@unblog.fr','IaY60nD','Russia',NULL),('18180198','ROLE_STU','Ashness','910510-1206321','M','철학과','230.98.238.11','294-720-6520','cashness2r@elpais.com','mL8jCm07Ey','China',NULL),('18183524','ROLE_STU','Bellhouse','990413-1634167','M','체육학과','181.254.204.150','468-802-9840','tbellhousea9@webmd.com','KOw9HC','Philippines',NULL),('18199618','ROLE_STU','Marioneau','881220-2278895','F','영어영문학과','199.156.122.167','693-260-9979','nmarioneaud8@ihg.com','p3i7hOB','Portugal',NULL),('18228944','ROLE_PROF','Aspall','820315-1612641','M','기계공학과','39.54.3.223','279-182-1197','caspall6@t.co','348IbM0','Poland',NULL),('19104187','ROLE_STU','Romera','870806-1487804','M','국어국문학과','221.199.79.46','479-270-9398','jromerac7@opera.com','s7CiDsZSld','Indonesia',NULL),('19109453','ROLE_STU','Gebuhr','940702-2827700','F','의류학과','136.226.252.148','865-522-4261','ogebuhr8q@kickstarter.com','W6k7Qd','Russia',NULL),('19109454','ROLE_STU','Hopewell','930813-2264427','F','심리학과','239.19.16.47','179-674-9011','bhopewellax@usatoday.com','uW6fGZrWk','Canada',NULL),('19111503','ROLE_STU','Doumenc','890414-2175058','F','언론정보학과','232.250.71.178','950-641-6208','bdoumenc5w@cbc.ca','PzLmQW','France',NULL),('19118402','ROLE_STU','McCay','970402-2832871','F','기계공학과','188.5.228.117','941-449-9001','cmccay6o@elpais.com','ZAPqrv','Indonesia',NULL),('19136098','ROLE_STU','Wallis','851118-1729181','M','영어영문학과','91.192.190.108','359-298-2082','mwallis2o@geocities.com','4HT8vhP1','Portugal',NULL),('19143945','ROLE_STU','Jiroutka','941006-2211869','F','경영학과','146.199.14.54','200-586-4308','ejiroutkadq@nasa.gov','k6aKmbfsXD','Mexico',NULL),('19179440','ROLE_STU','Ducham','820524-1817817','M','국어국문학과','60.72.59.115','103-954-7733','jducham7i@icio.us','3FXPQaaJ1KbT','Peru',NULL),('19189372','ROLE_STU','Middler','840826-1404413','M','영어영문학과','98.221.7.0','920-801-3004','amiddler1g@liveinternet.ru','kPJeqe3d2Hgb','China',NULL),('19192126','ROLE_STU','Aldam','800726-1330534','M','심리학과','78.217.100.56','244-993-3274','raldamc5@vkontakte.ru','zhWVHWObzaP','South Africa',NULL),('19193538','ROLE_STU','Nourse','840604-1165016','M','의류학과','11.132.133.66','822-118-5604','dnourse4r@fastcompany.com','jpIzjBGI','Brazil',NULL),('19285757','ROLE_PROF','Stennard','810501-1481609','M','체육학과','50.50.83.0','722-609-8847','wstennard4m@answers.com','GJNJ1YAUo','Slovenia',NULL),('20121193','ROLE_STU','Wichard','980907-2921488','F','영어영문학과','162.166.149.56','432-536-1349','awichard6k@is.gd','AvGdSxt','France',NULL),('20123808','ROLE_STU','Fouracres','821218-1327103','M','기계공학과','238.222.129.3','222-209-2669','nfouracresab@youku.com','iLLCr5JPPtEz','Russia',NULL),('20141374','ROLE_STU','Coskerry','950622-2745963','F','통계학과','225.97.84.114','298-147-0069','pcoskerry8d@fastcompany.com','SV00ruHMA3','Bolivia',NULL),('20142248','ROLE_STU','Alleyn','820712-2426541','F','물리학과','212.111.26.65','214-927-7118','galleyn7k@deviantart.com','mQdSZpp4k1','China',NULL),('20144609','ROLE_STU','Tzar','810825-2878765','F','통계학과','85.108.24.56','684-500-5212','ptzar85@tiny.cc','i2JXE0e1uKv3','China',NULL),('20155510','ROLE_STU','Bage','840217-2420427','F','기계공학과','103.106.155.53','999-394-2108','sbage63@jiathis.com','MFGWr2DysB','Russia',NULL),('20165495','ROLE_STU','Trillow','900722-2915942','F','물리학과','26.126.11.143','501-538-6107','atrillow23@meetup.com','H6lmlTQS','Czech Republic',NULL),('20165528','ROLE_STU','Bradtke','981002-1094393','M','언론정보학과','182.143.37.127','680-821-8883','dbradtkex@blogs.com','g1GcQHLUic01','Lithuania',NULL),('20165868','ROLE_STU','Sinkings','930105-2611964','F','건축학과','196.249.233.59','697-986-0410','dsinkings3h@theguardian.com','wcObJOmwphhv','Indonesia',NULL),('20166057','ROLE_STU','Shevelin','821204-1133842','M','사회복지학과','236.164.137.205','922-936-6365','eshevelin28@arizona.edu','VkNoVf5K','Sweden',NULL),('20173769','ROLE_STU','Deval','960321-2539273','F','물리학과','146.252.71.132','441-369-6646','tdevalci@abc.net.au','4htf3RZi7z2','Indonesia',NULL),('20178628','ROLE_STU','Faughny','960715-1467485','M','경영학과','95.83.108.110','166-288-7386','afaughnyn@google.com.hk','l3u8ey','Indonesia',NULL),('20179587','ROLE_STU','Scaife','970428-2339288','F','체육학과','247.205.208.222','619-948-2793','fscaife51@sohu.com','BFaSnq2','Greece',NULL),('20187183','ROLE_STU','Refford','820912-1155322','M','건축학과','202.92.69.243','150-708-3152','mrefford4y@usatoday.com','3l2vpypjsl7P','Argentina',NULL),('20240291','ROLE_PROF','Ellsom','870905-1578039','M','국어국문학과','117.105.158.9','177-729-7657','hellsom2q@usnews.com','N4LaigNtl','France',NULL),('20255121','ROLE_PROF','Blinco','840705-1244125','M','언어학과','239.177.43.5','176-895-3123','gblinco1f@surveymonkey.com','Uuaky7','Peru',NULL),('20256648','ROLE_PROF','Jimeno','900230-2425732','F','체육학과','251.59.116.36','370-636-9512','hjimeno5i@issuu.com','eXc1r0Yrd','Thailand',NULL),('21105406','ROLE_STU','Bernardotti','971112-2905350','F','체육학과','10.240.81.191','116-370-3992','sbernardotti44@bravesites.com','dmdHAB0u','Afghanistan',NULL),('21118400','ROLE_STU','Frankish','881113-1881107','M','언어학과','198.71.2.74','865-791-3167','mfrankish4f@yahoo.com','4clnkib02e','Indonesia',NULL),('21118677','ROLE_STU','Chevis','830225-1927662','M','기계공학과','78.145.8.155','757-846-3424','schevis7o@latimes.com','8hy0bY0','United States',NULL),('21124593','ROLE_STU','Ditchfield','851228-2615200','F','영어영문학과','248.177.141.217','998-833-0983','rditchfieldbe@nba.com','Q0Szzdhlaw1','Poland',NULL),('21149494','ROLE_STU','Rosencrantz','921213-2123857','F','사회학과','75.18.115.176','429-540-8214','crosencrantz48@hugedomains.com','vbLn1lBEIr','Nigeria',NULL),('21150011','ROLE_STU','Rau','981229-1928082','M','체육학과','149.73.101.6','149-146-0397','crau6v@huffingtonpost.com','o7bEkG','Indonesia',NULL),('21164493','ROLE_STU','Cresser','820824-1396994','M','영어영문학과','0.243.237.232','585-341-0644','dcresser77@time.com','JQBjMFA','China',NULL),('21216968','ROLE_PROF','Ghidini','940727-1034907','M','건축학과','160.72.137.40','289-585-2115','eghidini82@alibaba.com','x6xIlQ','Chile',NULL),('21221191','ROLE_PROF','Dugget','841120-1004909','M','수학과','36.195.247.150','298-191-3841','gduggeth@irs.gov','liBay4VJ5zWK','China',NULL),('21265836','ROLE_PROF','Rannie','890919-2354289','F','건축학과','7.45.171.47','614-822-0016','frannie1z@wsj.com','Nhss0hZwEwh5','Serbia',NULL),('22102082','ROLE_STU','Giraudo','811124-2209936','F','물리학과','209.28.209.241','179-623-3744','ggiraudob1@zimbio.com','slaVlKmgTK','Indonesia',NULL),('22122035','ROLE_STU','Phelips','981023-2686410','F','수학과','162.245.169.33','773-545-8096','mphelips52@businessinsider.com','pOv0jVoS2KVb','Cuba',NULL),('22145097','ROLE_STU','Howerd','990401-2508304','F','통계학과','95.1.48.208','472-839-4639','khowerd2@freewebs.com','2CqXQF0VmW6','China',NULL),('22145874','ROLE_STU','Tollett','810211-2294555','F','수학과','219.48.125.8','492-360-6782','atollettd@hud.gov','CJduFD0ke5G','Indonesia',NULL),('22151829','ROLE_STU','Rawsen','911213-1055783','M','영어영문학과','88.45.77.48','811-813-7803','mrawsen14@webs.com','FEo3Sos','China',NULL),('22156790','ROLE_STU','Edginton','940602-1436594','M','수학과','31.191.59.169','621-278-4798','jedginton37@mediafire.com','Qo2bWCgPMm','Czech Republic',NULL),('22173886','ROLE_STU','Stiddard','961030-2620520','F','의류학과','96.171.196.165','706-678-2548','estiddard3v@drupal.org','L4hv8VYj28','Indonesia',NULL),('22175972','ROLE_STU','Tissell','910608-2015667','F','사회학과','80.237.119.82','649-705-9121','wtissell8s@weibo.com','bgwyW6Qh','Czech Republic',NULL),('22186694','ROLE_STU','Malins','811030-2167617','F','철학과','215.57.100.60','416-681-6086','mmalins4w@mayoclinic.com','xq5H0XM7Y3','Albania',NULL),('22266199','ROLE_PROF','Grabert','840103-1154551','M','철학과','102.25.224.177','215-266-6964','jgrabert26@java.com','vzNIkayQe','China',NULL),('95101804','ROLE_STU','Weekland','810319-1862181','M','영어영문학과','218.149.184.37','968-720-6495','gweeklandd9@bandcamp.com','qKvqnxTrT','Russia',NULL),('95103515','ROLE_STU','Bravery','990510-1007219','M','심리학과','246.84.38.140','820-509-0277','obraverybd@cyberchimps.com','SpgqkE4Tpb','Spain',NULL),('95108044','ROLE_STU','Sheirlaw','800409-1317800','M','철학과','119.204.200.177','769-734-2891','hsheirlaw5r@istockphoto.com','brukPdXCaqC','Iran',NULL),('95108789','ROLE_STU','Shorland','940422-2714755','F','심리학과','232.168.124.125','117-425-5202','ashorland17@utexas.edu','bu4Pszalbb6','Greece',NULL),('95109682','ROLE_STU','Cuttler','860306-1526715','M','통계학과','252.67.164.138','420-593-7648','kcuttler9b@house.gov','MM9dSHjs','Slovenia',NULL),('95109757','ROLE_STU','Varley','821021-1057603','M','체육학과','70.104.224.58','205-757-9726','cvarley97@netvibes.com','CZrqvDTu4','Malaysia',NULL),('95110536','ROLE_STU','Kenny','920818-1770863','M','통계학과','114.79.104.114','472-977-0029','ckenny5b@goodreads.com','uItxFxWI','France',NULL),('95112934','ROLE_STU','Drews','861027-2076475','F','경영학과','38.166.241.148','297-960-6914','kdrews5d@booking.com','Un3kP7M','Indonesia',NULL),('95113162','ROLE_STU','Symcoxe','830401-2487197','F','심리학과','249.9.125.184','106-408-7338','msymcoxe32@indiegogo.com','BEtvFrj','Russia',NULL),('95113717','ROLE_STU','Benoist','991018-2444970','F','기계공학과','45.92.218.69','666-597-6178','bbenoist5c@alibaba.com','fzNMqDG3v','Poland',NULL),('95115760','ROLE_STU','Silversmid','961120-2479706','F','기계공학과','25.60.93.124','713-978-2358','asilversmid1h@macromedia.com','8QkDewRL','Ireland',NULL),('95120617','ROLE_STU','Snipe','900908-1448976','M','컴퓨터공학과','124.253.108.206','368-708-8057','msnipeb9@arizona.edu','O34lmlWOME','Philippines',NULL),('95122232','ROLE_STU','Gonet','941226-2182161','F','통계학과','136.70.153.196','783-974-8067','kgonet49@1und1.de','9bfamvXeyVu','Japan',NULL),('95123056','ROLE_STU','Donet','830221-1493270','M','체육학과','153.248.30.136','583-224-7691','kdonetbh@guardian.co.uk','xAZfyiic','China',NULL),('95123959','ROLE_STU','Warfield','840728-2821842','F','언어학과','123.48.173.66','456-306-9293','twarfield8t@cbsnews.com','45AcTPoI','Russia',NULL),('95125678','ROLE_STU','Eager','860222-2306225','F','영어영문학과','189.226.195.98','492-697-3996','yeager4d@dell.com','06bBwT1GG','Brazil',NULL),('95127891','ROLE_STU','Broadway','901201-1124329','M','기계공학과','117.78.237.112','128-194-4443','cbroadway8m@list-manage.com','3Hru1zMYQ','Japan',NULL),('95137834','ROLE_STU','Faunch','970506-1542870','M','사회복지학과','21.8.97.21','491-994-4433','ifaunch8p@rakuten.co.jp','xK7XRIBC','Dominican Republic',NULL),('95138318','ROLE_STU','Holdin','840101-2698478','F','의류학과','61.58.188.161','225-899-2211','iholdin6z@live.com','RCCIg6F1L9','Brazil',NULL),('95139429','ROLE_STU','Eagan','960706-1532399','M','경영학과','249.255.105.162','535-913-6117','teaganb5@phpbb.com','vNR7UAtEz4bC','Brazil',NULL),('95139516','ROLE_STU','Wallege','860410-1747318','M','사회학과','32.204.125.77','302-354-8789','cwallege5p@tinyurl.com','1MiZQjJA','Germany',NULL),('95141366','ROLE_STU','Garric','830314-2732283','F','통계학과','122.207.187.66','291-407-8906','mgarricdt@ftc.gov','EmZpAqQj4','Indonesia',NULL),('95142246','ROLE_STU','Dulton','900330-1799453','M','건축학과','56.98.199.79','548-525-8859','fdulton10@digg.com','1HbkXdMLEEy','Colombia',NULL),('95144098','ROLE_STU','Melbury','840224-2971204','F','수학과','47.159.181.214','270-496-1212','mmelburyck@nyu.edu','H3mcY3YX','Venezuela',NULL),('95144718','ROLE_STU','Turbitt','870604-2261563','F','기계공학과','227.163.86.206','814-947-1855','rturbitt35@newyorker.com','r1RHaA','Haiti',NULL),('95151093','ROLE_STU','Armitage','920514-2274670','F','사회복지학과','11.94.96.29','355-649-5961','rarmitage64@china.com.cn','zXdJnNpdTlG','Ukraine',NULL),('95155237','ROLE_STU','Philippsohn','930901-1650119','M','물리학과','91.155.63.37','860-500-4783','aphilippsohn1a@multiply.com','Cu98po','China',NULL),('95157160','ROLE_STU','McMeekan','880118-2698184','F','경영학과','162.117.192.215','172-220-7078','gmcmeekan5m@prnewswire.com','qrj2epy','Brazil',NULL),('95157895','ROLE_STU','Cheltnam','800601-1597310','M','국어국문학과','110.27.84.111','950-809-7637','rcheltnamdr@com.com','rCU9K8VXBi','Ukraine',NULL),('95161609','ROLE_STU','MacFadden','950809-1193900','M','언어학과','113.203.74.212','259-442-6750','bmacfadden7f@tmall.com','BvY1IjJug','Philippines',NULL),('95161791','ROLE_STU','De Blasi','990921-2918517','F','컴퓨터공학과','94.154.13.221','977-290-6221','mdeblasidj@live.com','DrXpoOfEWINu','Russia',NULL),('95166464','ROLE_STU','Weyman','801221-2153934','F','언론정보학과','133.57.247.77','316-145-7475','rweyman9c@seesaa.net','da3Mgj8hFw63','Philippines',NULL),('95167558','ROLE_STU','Mercer','860415-1778146','M','심리학과','198.254.240.178','971-431-3994','kmercer4a@ft.com','twerekCQ','Brazil',NULL),('95167636','ROLE_STU','Hassen','820712-1213491','M','사회학과','166.222.174.242','282-719-2204','fhassen86@xing.com','qyo1bgR1Gq4t','Czech Republic',NULL),('95169217','ROLE_STU','Bertot','860324-2411288','F','수학과','222.99.5.38','443-175-5556','kbertot5e@constantcontact.com','mFgZSuSF0p','Colombia',NULL),('95172962','ROLE_STU','Lewcock','880919-1781467','M','영어영문학과','205.126.186.71','850-553-0005','dlewcock4k@ed.gov','B2RSbQ','China',NULL),('95174087','ROLE_STU','Fellibrand','870121-2338588','F','언어학과','230.65.204.9','584-371-5796','afellibrand2v@topsy.com','yjsomng','Greece',NULL),('95175773','ROLE_STU','Gallally','960718-1232261','M','의류학과','198.23.36.83','428-188-7797','egallally27@myspace.com','3LRAcRDn','China',NULL),('95177465','ROLE_STU','Brech','900111-2521876','F','통계학과','20.111.144.209','319-615-1561','nbrech8z@nsw.gov.au','5Wq6rbOw','China',NULL),('95180310','ROLE_STU','Segrott','900505-2706260','F','물리학과','105.145.83.155','783-686-5951','rsegrott1k@cyberchimps.com','09zzsqAk','Mexico',NULL),('95181146','ROLE_STU','Adaway','801021-1866126','M','언어학과','19.159.147.42','836-813-7978','vadaway7r@ifeng.com','nHLRH5WNZT','France',NULL),('95186008','ROLE_STU','Esley','820701-1047479','M','언어학과','237.24.187.240','788-551-1207','hesley3k@1und1.de','GtGNiPIWq','China',NULL),('95186689','ROLE_STU','Banville','970206-1638091','M','기계공학과','144.163.85.251','907-705-6264','abanville3c@harvard.edu','r11ghq','Nigeria',NULL),('95195955','ROLE_STU','Poundford','930328-2236345','F','철학과','86.142.47.167','153-725-2655','kpoundford5v@lycos.com','bXEfwZ','Russia',NULL),('95197851','ROLE_STU','Blazi','820622-2841407','F','심리학과','81.25.18.138','586-421-5157','mblazi13@army.mil','dR3Efj0LcYhE','Brazil',NULL),('95217606','ROLE_PROF','Furst','911022-1238801','M','체육학과','140.145.0.126','897-908-1860','afurst2t@quantcast.com','xZ5HFFuM','Tanzania',NULL),('95228603','ROLE_PROF','Eefting','810326-2733694','F','언론정보학과','31.153.206.153','726-842-0267','seefting5q@unblog.fr','4e1SeC','Poland',NULL),('95246667','ROLE_PROF','Ambler','920114-1861265','M','경영학과','191.151.149.101','583-417-8600','bambler2j@cdbaby.com','suygRW7','Indonesia',NULL),('95249409','ROLE_PROF','Roskams','930930-2427193','F','통계학과','146.86.9.194','913-501-6394','droskamsc2@slate.com','A1oStPiSmfM8','Philippines',NULL),('95263449','ROLE_PROF','Lemmon','800709-1917209','M','기계공학과','140.248.13.74','771-782-7149','blemmona3@discovery.com','mQVH4L','Mauritius',NULL),('95271428','ROLE_PROF','Brealey','991017-2794735','F','국어국문학과','140.60.102.12','660-575-1772','dbrealey39@paginegialle.it','UycyfU','Ukraine',NULL),('95276513','ROLE_PROF','Heelis','900222-1502362','M','물리학과','16.219.124.224','429-154-7840','kheelis9k@bravesites.com','NsVsUc','Japan',NULL),('95296459','ROLE_PROF','Cicchinelli','851209-2209453','F','의류학과','27.241.121.248','851-239-0760','rcicchinelli56@icq.com','s4kQNBfU','Poland',NULL),('95299906','ROLE_PROF','Cowden','960209-2835638','F','체육학과','162.30.44.152','485-459-4492','kcowden5j@barnesandnoble.com','JYaDe7','Indonesia',NULL),('96101273','ROLE_STU','Byrkmyr','940612-1723166','M','국어국문학과','2.170.120.135','788-583-3379','mbyrkmyrb6@omniture.com','ZuLvN9','Egypt',NULL),('96101431','ROLE_STU','MacCracken','960621-2060244','F','사회복지학과','252.26.63.192','326-155-9363','lmaccracken9z@clickbank.net','S6NCz6W','Vietnam',NULL),('96102369','ROLE_STU','Darycott','960703-2750627','F','물리학과','189.22.91.243','220-523-6853','odarycott50@taobao.com','mwj3c2VAN2W7','Indonesia',NULL),('96102476','ROLE_STU','Kellick','921019-2287740','F','경영학과','39.104.253.164','790-200-5533','pkellickde@php.net','7QrDK7','China',NULL),('96109664','ROLE_STU','Wickenden','810412-2242052','F','사회학과','172.160.193.209','574-861-5469','cwickendenm@cocolog-nifty.com','bVaOOBXrSh','Russia',NULL),('96112210','ROLE_STU','Kohlert','870305-2678959','F','사회학과','89.116.106.153','205-724-4011','nkohlert25@independent.co.uk','3iZK4Ce2','Philippines',NULL),('96115369','ROLE_STU','Josey','921117-1017358','M','건축학과','219.201.110.78','499-925-5546','hjoseyau@amazon.de','QhPUY9Suw','Chile',NULL),('96122544','ROLE_STU','Cooke','820626-1585102','M','물리학과','48.72.102.127','340-979-7191','dcookeq@mac.com','BXMjQ69mRP3','Philippines',NULL),('96124567','ROLE_STU','Downer','991210-1107804','M','국어국문학과','9.123.147.91','942-600-7924','rdowner4b@histats.com','m1ALXpbN','Brazil',NULL),('96131880','ROLE_STU','Shallcrass','850628-1480998','M','수학과','113.124.99.211','833-531-7367','vshallcrass2l@google.es','XBSKjS3a','Brazil',NULL),('96133704','ROLE_STU','Caldicot','800718-2565768','F','건축학과','84.118.20.242','657-510-3025','acaldicot3b@google.de','OCbtKw0','Colombia',NULL),('96140559','ROLE_STU','Le Pruvost','980128-1160208','M','건축학과','233.211.144.30','241-636-9103','mlepruvostbk@ftc.gov','T2dI0JECcid','Greece',NULL),('96140562','ROLE_STU','Woonton','881006-2739034','F','수학과','67.57.17.104','778-714-2146','cwoonton20@epa.gov','vQdEys','China',NULL),('96141370','ROLE_STU','Mohring','950313-1607556','M','컴퓨터공학과','144.250.208.190','778-687-8461','lmohring40@elegantthemes.com','qyGQlPnvvxU','Indonesia',NULL),('96141738','ROLE_STU','Winstone','871018-1936076','M','체육학과','67.128.206.153','406-934-0713','swinstone93@cbslocal.com','1AI3hdfh1z','Peru',NULL),('96143888','ROLE_STU','MacCoveney','980824-1141716','M','물리학과','147.97.61.119','909-651-0888','nmaccoveney4q@discovery.com','FmaW6HOD','Czech Republic',NULL),('96145460','ROLE_STU','Tribell','840816-2955402','F','컴퓨터공학과','248.144.243.85','187-372-0216','gtribella8@angelfire.com','ApjmpG62Cj','Philippines',NULL),('96148872','ROLE_STU','Schulze','850213-2519573','F','컴퓨터공학과','75.118.58.105','327-772-8198','aschulze7d@live.com','T47Y6MOP8e','Kazakhstan',NULL),('96158904','ROLE_STU','Kenworthey','840308-1212758','M','기계공학과','58.43.133.158','425-236-4027','mkenwortheyac@shareasale.com','FxjVJam','Argentina',NULL),('96162208','ROLE_STU','Lintall','920708-2524159','F','의류학과','142.152.194.49','121-894-0212','llintallaf@vistaprint.com','sOXrZhgfkvR','Indonesia',NULL),('96163840','ROLE_STU','Treherne','860313-2130052','F','국어국문학과','34.132.163.56','738-288-5175','utreherne8v@newyorker.com','R5kmEKk','Japan',NULL),('96163982','ROLE_STU','Hatfull','970502-2920942','F','심리학과','73.220.106.170','391-628-3404','ahatfull4s@naver.com','CvsnuPA','Mexico',NULL),('96172390','ROLE_STU','Rotte','820117-2841499','F','국어국문학과','243.200.63.85','887-566-0978','grotte3m@xing.com','sT0vmVnMc','Philippines',NULL),('96174387','ROLE_STU','Olyunin','870827-2184799','F','통계학과','76.166.59.143','525-861-6540','lolyunina5@msn.com','1NpuJwKe','Bosnia and Herzegovina',NULL),('96181248','ROLE_STU','Nolton','940614-2665319','F','철학과','42.104.222.200','346-435-0851','vnolton6g@devhub.com','laD8GJI1Y','Russia',NULL),('96182990','ROLE_STU','De Atta','960406-2243867','F','체육학과','207.236.44.215','663-781-6957','ldeatta9n@home.pl','Zku3HKIfQFWd','Indonesia',NULL),('96183431','ROLE_STU','Andreazzi','800707-1791544','M','심리학과','246.148.181.197','689-238-5576','aandreazzi2b@ox.ac.uk','rjnhSe','Indonesia',NULL),('96185360','ROLE_STU','Dulson','920307-1890624','M','언론정보학과','238.120.220.180','214-191-9816','mdulsonct@jiathis.com','SKCCarZq67','Russia',NULL),('96185555','ROLE_STU','Ohanessian','951211-1254115','M','수학과','215.87.234.71','759-893-7804','dohanessian2n@umn.edu','at83NNReT','Ukraine',NULL),('96188434','ROLE_STU','Jeannaud','840306-1361264','M','국어국문학과','83.160.220.21','254-893-1171','ajeannaud7t@un.org','UqJ0S2b','China',NULL),('96190596','ROLE_STU','Loan','920711-2732076','F','컴퓨터공학과','116.157.213.12','982-624-6249','wloan83@wikimedia.org','acXmEf','Russia',NULL),('96193666','ROLE_STU','Fellini','830120-1619670','M','언론정보학과','84.30.122.125','892-677-2608','dfellini3q@mtv.com','x1Pey2EwfUV','Mongolia',NULL),('96194151','ROLE_STU','Dukes','971030-1819882','M','언어학과','162.229.202.198','375-636-2690','sdukes68@theguardian.com','J3T4hUU','Indonesia',NULL),('96196690','ROLE_STU','Corder','891026-2335860','F','사회복지학과','41.202.68.125','614-310-9360','scorder4c@webeden.co.uk','jq1GYoiexuGh','Serbia',NULL),('96197424','ROLE_STU','Matchett','920715-2087610','F','심리학과','51.96.170.231','780-477-8481','lmatchett4x@pinterest.com','pPbMR8BoN9','Nigeria',NULL),('96200943','ROLE_PROF','Birchall','980908-2983595','F','영어영문학과','253.180.249.238','407-724-5110','nbirchall1s@themeforest.net','snVmdXKPj','Ukraine',NULL),('96237399','ROLE_PROF','Frankel','841124-2923686','F','사회복지학과','74.69.0.30','969-484-2909','ifrankel31@samsung.com','fp8dzxC','Russia',NULL),('96238195','ROLE_PROF','Galpen','920324-1903339','M','국어국문학과','192.178.168.77','866-400-8745','agalpen3@creativecommons.org','qpNuYLKG','Yemen',NULL),('96251345','ROLE_PROF','Voss','930525-2125601','F','기계공학과','61.123.160.217','894-430-1403','fvossbf@multiply.com','g8fXACCtyt20','China',NULL),('96261823','ROLE_PROF','Tzarkov','811104-2690317','F','영어영문학과','47.133.129.114','995-954-5049','rtzarkov1e@sphinn.com','SAd0ATalNWz3','France',NULL),('96266948','ROLE_PROF','Youhill','831029-2578353','F','물리학과','74.15.47.36','503-290-5695','ryouhillcr@godaddy.com','r96xJKGd6Jbg','Turkmenistan',NULL),('96282034','ROLE_PROF','Scrannage','960101-2965731','F','수학과','161.70.148.189','382-379-7826','rscrannager@mlb.com','VyXIOAeK','Slovenia',NULL),('96285904','ROLE_PROF','Bartot','910420-2456717','F','수학과','116.23.240.69','881-426-4158','ibartot1x@cornell.edu','Gt9tw29WkBF','Greece',NULL),('96299428','ROLE_PROF','Boulde','970614-1901807','M','기계공학과','242.12.81.26','712-688-5174','lboulde4g@google.com.br','Zlgbqyti','Nigeria',NULL),('97100631','ROLE_STU','Krikorian','871120-1310479','M','건축학과','49.139.201.134','408-838-2509','fkrikorianb2@goodreads.com','lgIG5RXP','Tunisia',NULL),('97104783','ROLE_STU','Gillivrie','840903-1766794','M','철학과','249.68.71.101','802-445-6149','lgillivrie6p@tiny.cc','NHh2fclF','Indonesia',NULL),('97107569','ROLE_STU','Bottoms','881104-1427438','M','통계학과','240.168.57.103','331-307-5873','ebottoms76@sciencedirect.com','tyLfFCm','Uganda',NULL),('97110881','ROLE_STU','Currm','831222-2172773','F','영어영문학과','223.62.195.234','612-746-8656','mcurrm8w@chronoengine.com','d6caD2JuXG','Guatemala',NULL),('97111017','ROLE_STU','Rhule','851116-1035716','M','사회학과','194.211.249.155','976-912-5064','jrhule11@msu.edu','uoqfmJmpqY','Indonesia',NULL),('97111434','ROLE_STU','Cay','900306-1172324','M','건축학과','14.109.198.58','678-912-8517','bcaybc@dropbox.com','hYDUV1K','Portugal',NULL),('97113607','ROLE_STU','Sharpless','980704-1024779','M','의류학과','35.35.150.193','644-474-0910','asharplessdu@prweb.com','xAhD87','Bahrain',NULL),('97113662','ROLE_STU','Reisen','861228-2634187','F','사회복지학과','79.160.50.206','499-798-7025','areisenbt@sakura.ne.jp','0hWFmfM65','Philippines',NULL),('97118253','ROLE_STU','Keuneke','930806-2770184','F','사회학과','183.147.21.131','930-835-1161','lkeuneke60@ask.com','XmR3iRtNWQ','Poland',NULL),('97119382','ROLE_STU','Burtwell','950904-1973212','M','경영학과','73.155.116.236','691-468-1719','hburtwellca@amazon.co.jp','uwXA3pAf9tk','Bulgaria',NULL),('97119866','ROLE_STU','Drohane','851122-2408921','F','국어국문학과','18.43.74.124','508-886-2686','ddrohane30@amazon.de','VmgwYjcto','Iran',NULL),('97122894','ROLE_STU','Yggo','940810-2669969','F','심리학과','244.230.182.181','320-483-0620','gyggo7g@xing.com','VcbhzzXL6','Cyprus',NULL),('97133338','ROLE_STU','Shortall','810217-1099477','M','심리학과','15.219.102.95','578-269-4954','dshortalldh@umich.edu','GgsoHyL','France',NULL),('97138436','ROLE_STU','Ginni','970723-1659881','M','언어학과','241.132.210.104','693-562-7963','dginni6h@delicious.com','XGMCaw9EMWt','Indonesia',NULL),('97140968','ROLE_STU','Jellings','810930-2271242','F','건축학과','196.214.198.163','109-284-9485','ejellings84@icio.us','aLSInRDYWh4','China',NULL),('97145357','ROLE_STU','Dowthwaite','880219-1891506','M','철학과','64.124.251.118','400-635-2112','adowthwaited0@wikimedia.org','gGECIzzPNr6S','Yemen',NULL),('97146947','ROLE_STU','Brimmell','950915-1665068','M','통계학과','153.9.77.136','826-933-3379','hbrimmell8x@ustream.tv','ZJyyETcQ','Malaysia',NULL),('97150910','ROLE_STU','Dowbakin','830223-1027285','M','기계공학과','0.189.88.158','369-548-9235','kdowbakincx@gov.uk','FZuN48aa4','Netherlands',NULL),('97151615','ROLE_STU','Inott','911206-1972476','M','체육학과','158.50.20.134','760-594-6406','sinott41@nih.gov','Xjnf8g','China',NULL),('97161604','ROLE_STU','Camilleri','910616-1165675','M','건축학과','99.129.73.55','424-176-9507','ccamilleri4@dagondesign.com','Y1op49Y6VnmS','Russia',NULL),('97163211','ROLE_STU','Collop','960301-2773915','F','수학과','202.33.11.2','617-515-3434','fcollop4e@booking.com','HvpAGFIWLVN','Poland',NULL),('97164788','ROLE_STU','Tookey','970207-1535409','M','사회복지학과','58.212.190.111','609-701-1035','stookeyc8@skype.com','P2l2nBaz','Japan',NULL),('97164854','ROLE_STU','Morratt','950713-2949123','F','경영학과','115.161.28.146','268-867-3501','amorratt19@springer.com','OAFoMqeGUrx','Indonesia',NULL),('97165937','ROLE_STU','Songust','940321-2740613','F','물리학과','165.197.6.189','154-600-7906','esongust8y@globo.com','6puE6Nf','Ukraine',NULL),('97177716','ROLE_STU','Peegrem','960306-1427680','M','의류학과','175.61.20.251','373-720-1666','cpeegrem9e@umich.edu','p3ta6g','Argentina',NULL),('97179741','ROLE_STU','Studdert','940412-1892197','M','국어국문학과','98.214.108.201','535-554-7848','lstuddert33@yandex.ru','vms0qwf','Philippines',NULL),('97184914','ROLE_STU','Noraway','860924-2159921','F','사회복지학과','250.253.132.187','325-934-4796','anoraway9@nyu.edu','9rhTwrpEfq','Russia',NULL),('97190513','ROLE_STU','Salatino','980712-1458135','M','사회학과','74.1.249.59','651-447-5624','hsalatinoby@free.fr','WavmVbY','China',NULL),('97194954','ROLE_STU','Gawke','901015-1675081','M','언론정보학과','20.51.66.32','380-677-7494','jgawked5@homestead.com','EM9y4t8H3iq','Pakistan',NULL),('97206870','ROLE_PROF','Koenen','850621-2754373','F','언론정보학과','60.192.53.174','825-844-5117','nkoenen9t@livejournal.com','Gj9C72oL6E','Luxembourg',NULL),('97209783','ROLE_PROF','O\'Hallihane','830622-2838285','F','경영학과','46.153.1.80','768-926-7433','sohallihane5s@prnewswire.com','aArvYGtZkIPj','Sweden',NULL),('97214089','ROLE_PROF','Bertholin','911201-2624999','F','컴퓨터공학과','88.167.172.131','316-880-5078','mbertholin6m@ocn.ne.jp','RLlNKvuR','Indonesia',NULL),('97214948','ROLE_PROF','Andreou','850420-1124322','M','물리학과','188.41.189.91','439-454-8511','pandreou65@ca.gov','eCOcql','France',NULL),('97223502','ROLE_PROF','Ballard','980106-1326388','M','수학과','46.82.36.10','200-479-3249','rballardo@oakley.com','29Qc0mq','Indonesia',NULL),('97224411','ROLE_PROF','Jahns','900325-1451661','M','언론정보학과','235.171.158.181','592-541-6814','wjahns6n@foxnews.com','NOhqFLG9oEG','Poland',NULL),('97236728','ROLE_PROF','Fantonetti','920929-1841803','M','심리학과','226.173.117.116','623-733-2060','mfantonetti2y@ucla.edu','y6yvUSQlELt8','China',NULL),('97269644','ROLE_PROF','O\'Carney','990501-2572652','F','철학과','230.208.90.128','173-849-1191','iocarney3a@blogs.com','KOzBBrHep','Poland',NULL),('97270285','ROLE_PROF','Skudder','840104-1870431','M','사회학과','91.43.100.229','308-599-8099','dskudder18@google.co.uk','PDIICZhkH','Indonesia',NULL),('97273893','ROLE_PROF','Pollicott','980917-2749148','F','사회복지학과','56.48.23.111','764-133-2280','rpollicottcv@nationalgeographic.com','vQL0chlO','Philippines',NULL),('97276721','ROLE_PROF','Iban','940102-1740459','M','언어학과','188.18.163.223','490-397-8335','siban6t@nbcnews.com','So0NviKR','Poland',NULL),('97285470','ROLE_PROF','Sturror','870806-2802168','F','컴퓨터공학과','253.232.53.254','712-988-7049','psturroran@intel.com','EHqJGV8fkqWo','Malaysia',NULL),('97299813','ROLE_PROF','Domnin','820107-2281333','F','건축학과','152.205.166.94','845-437-8412','jdomnin9p@cnbc.com','vNdzadg3PiL6','Mongolia',NULL),('97393234','ROLE_ADMIN','Boarder','870515-2289309','F','인사','113.179.11.49','636-669-8705','hboarder1t@surveymonkey.com','du9GSc','South Africa',NULL),('98103194','ROLE_STU','Bowhey','931121-1623581','M','건축학과','134.246.250.146','526-922-3498','cbowheyc4@yellowpages.com','FAv53VCBHseh','Poland',NULL),('98104620','ROLE_STU','Boraston','870702-2361124','F','영어영문학과','46.3.178.204','653-701-8646','oborastondd@illinois.edu','2CpPgXpDBb','China',NULL),('98104890','ROLE_STU','Canero','821230-1994550','M','사회학과','204.80.251.151','536-615-6947','kcanero57@ocn.ne.jp','5YU2SLAeB','Russia',NULL),('98106637','ROLE_STU','Abbs','820909-2740834','F','언론정보학과','67.192.182.214','797-795-9648','babbs2d@miibeian.gov.cn','kPzyVR5','Russia',NULL),('98107476','ROLE_STU','Jeyness','990115-2982227','F','철학과','73.103.180.29','191-162-2985','bjeynessc0@nifty.com','5tIKwjJ1cXu','Russia',NULL),('98108958','ROLE_STU','Frodsham','980712-1048269','M','통계학과','106.168.42.172','141-649-6103','nfrodshamay@epa.gov','oWOhogbVYGd','Philippines',NULL),('98112458','ROLE_STU','Winsom','870416-1025031','M','체육학과','149.223.232.0','526-697-7422','fwinsomav@engadget.com','nYmhDEGvh','Russia',NULL),('98120147','ROLE_STU','Roblett','870317-1081209','M','체육학과','238.134.190.157','466-408-6846','nroblett66@goo.ne.jp','cSOOZY','France',NULL),('98123758','ROLE_STU','Mantrup','830620-1941947','M','사회학과','8.9.52.233','954-137-6598','smantrup4h@bing.com','4ZNXaaba1X','China',NULL),('98127721','ROLE_STU','Sumpter','900927-1439431','M','물리학과','16.174.116.141','102-192-0498','isumpter1y@techcrunch.com','ewQeJh4','Cape Verde',NULL),('98128085','ROLE_STU','Altoft','850423-2269820','F','철학과','3.137.117.174','383-647-2921','ealtoft98@e-recht24.de','An9zYnQ4Zlz','Ukraine',NULL),('98128104','ROLE_STU','Thomann','970210-1989382','M','언론정보학과','58.64.39.3','510-312-3512','nthomann4v@mashable.com','sslKBdl','China',NULL),('98130927','ROLE_STU','Ahmad','970912-2716924','F','기계공학과','140.237.207.145','474-649-0331','oahmad47@istockphoto.com','e1ro89SGrco7','Indonesia',NULL),('98138550','ROLE_STU','Withringten','920724-2174379','F','컴퓨터공학과','193.154.198.151','101-432-0743','awithringten9l@livejournal.com','wk32RZ44QYkK','Philippines',NULL),('98142303','ROLE_STU','Liversley','950911-2349197','F','의류학과','46.191.85.95','461-269-5975','iliversleybq@etsy.com','GFUDIW','Mongolia',NULL),('98142548','ROLE_STU','Keelin','931215-2028067','F','체육학과','209.102.167.227','805-914-0244','gkeelin4o@cisco.com','pVNON4','United States',NULL),('98144004','ROLE_STU','Moncur','980210-2788606','F','사회복지학과','91.85.115.14','459-342-7540','smoncurap@nasa.gov','ySZHoZyUSv','Serbia',NULL),('98144698','ROLE_STU','Jorn','810811-1392874','M','의류학과','195.237.132.174','436-577-8733','rjorn99@cornell.edu','JmhWbbJDXJCb','China',NULL),('98145272','ROLE_STU','Philipsohn','830112-1240312','M','언론정보학과','79.0.30.29','459-547-9075','ophilipsohn9h@storify.com','NeSI7JSg','France',NULL),('98146439','ROLE_STU','Hourihane','830122-2489572','F','물리학과','61.204.204.188','763-508-1437','chourihane3j@hubpages.com','IJpC7fMpT','Russia',NULL),('98147857','ROLE_STU','Rosenfelder','910621-1426523','M','건축학과','232.160.108.82','988-528-3299','mrosenfelderg@clickbank.net','lKX0j8','Russia',NULL),('98151670','ROLE_STU','Baguley','920926-2883851','F','건축학과','42.196.35.251','950-288-5420','bbaguley67@purevolume.com','UuVECY4uA','Argentina',NULL),('98154539','ROLE_STU','Manzell','850425-2073093','F','수학과','101.205.188.140','306-206-4752','ymanzell5a@theglobeandmail.com','GgTTUWex','Peru',NULL),('98156951','ROLE_STU','McCrory','961119-2245521','F','국어국문학과','148.188.214.207','867-738-1563','tmccrory75@ucoz.ru','aPF4kEADjffA','Greece',NULL),('98157244','ROLE_STU','Huygens','830929-2979118','F','수학과','23.224.89.150','424-921-6712','ehuygens8l@timesonline.co.uk','y3DkROULNbJ','Chad',NULL),('98159767','ROLE_STU','Meth','991108-2935720','F','철학과','81.135.85.39','916-223-8644','fmeth6s@etsy.com','ZceY7v','United States',NULL),('98161362','ROLE_STU','Inchbald','800719-2449705','F','컴퓨터공학과','51.40.250.45','550-777-6877','minchbaldcq@ucsd.edu','RPjzCF','Indonesia',NULL),('98171416','ROLE_STU','Pretorius','810528-1601766','M','수학과','52.169.24.95','711-265-9304','npretorius9j@hp.com','J3V22gSofP','Nigeria',NULL),('98178800','ROLE_STU','Keling','820104-1321275','M','영어영문학과','96.114.217.31','922-233-5907','lkelingbl@biblegateway.com','uZD5XzZQ3eyB','Brazil',NULL),('98181064','ROLE_STU','Vest','871111-1125052','M','기계공학과','22.13.84.238','403-935-2818','jvest43@examiner.com','m34lnxJAJVjU','Philippines',NULL),('98182374','ROLE_STU','Cushworth','931116-2124341','F','언어학과','25.154.110.12','461-513-3130','scushworth3l@mozilla.com','lVA83j','Guatemala',NULL),('98187855','ROLE_STU','Bollini','970926-2544194','F','경영학과','105.109.193.140','732-407-0058','bbollinidi@apple.com','WRYwCx5D0b','Pakistan',NULL),('98188599','ROLE_STU','Tradewell','950620-1073519','M','영어영문학과','136.142.76.186','266-618-6528','jtradewellda@sohu.com','SvoiQe4vWFsq','Ukraine',NULL),('98193195','ROLE_STU','Bettridge','810219-2466509','F','국어국문학과','240.243.144.140','105-669-6295','jbettridge5x@state.gov','69banwIMZ','Lithuania',NULL),('98194905','ROLE_STU','Pudsall','841226-1509327','M','통계학과','243.191.74.4','753-132-4603','apudsallah@irs.gov','lgHx6rMg','Malaysia',NULL),('98198172','ROLE_STU','Jaumet','840402-2063340','F','언론정보학과','41.30.61.61','116-254-7365','sjaumet7q@com.com','TdQ6TE','Colombia',NULL),('98204804','ROLE_PROF','Rillstone','880413-1682659','M','통계학과','134.154.193.250','308-387-9782','trillstonebj@illinois.edu','UFJEBh','Indonesia',NULL),('98237637','ROLE_PROF','Petrov','980605-1013279','M','건축학과','182.219.26.118','487-222-4139','bpetrovdg@theguardian.com','BxkLECbDe','Norway',NULL),('98240713','ROLE_PROF','Chalke','800403-2942176','F','컴퓨터공학과','40.45.34.15','856-913-8260','echalke6r@fema.gov','3VRYTXUbL','Iran',NULL),('98248569','ROLE_PROF','Domoni','980327-1818280','M','심리학과','250.41.213.19','492-101-3655','kdomoni8g@seesaa.net','k4WqsekE','Indonesia',NULL),('98297800','ROLE_PROF','Tanser','850310-1871361','M','의류학과','253.146.4.26','734-174-2238','ctanser8a@domainmarket.com','rroFL6LnFKLi','Mauritius',NULL),('98350349','ROLE_ADMIN','Winley','930628-1110536','M','재무','57.84.61.226','610-129-0046','dwinleycl@who.int','vd01Sve97Bqv','Brazil',NULL),('98372061','ROLE_ADMIN','Dreghorn','811106-2611046','F','기획','14.69.13.126','553-480-9729','adreghorn1r@edublogs.org','MD63j3t','Indonesia',NULL),('99101175','ROLE_STU','Duxbury','901130-2283511','F','물리학과','1.65.79.79','328-792-6020','rduxbury42@examiner.com','iGkCYxH','Russia',NULL),('99107577','ROLE_STU','Cardenas','901205-1487957','M','체육학과','112.137.91.185','528-243-3682','dcardenasaj@spotify.com','1iXssfmWlAG','Uruguay',NULL),('99111714','ROLE_STU','Podbury','840515-1695970','M','철학과','57.141.71.103','350-957-0474','bpodburyba@symantec.com','1TmcCvmEiIw','Philippines',NULL),('99117106','ROLE_STU','Bubbear','821027-1697612','M','컴퓨터공학과','47.133.181.18','178-424-3513','gbubbear6e@posterous.com','79kRIs','Sweden',NULL),('99124899','ROLE_STU','Bard','920801-1138036','M','언론정보학과','226.241.211.249','346-522-8340','pbard7@tmall.com','J4IyxL9bkGT','Paraguay',NULL),('99128242','ROLE_STU','Franceschelli','970409-1667908','M','수학과','216.197.33.196','279-394-3127','rfranceschelli7w@theatlantic.com','DciQWUM2eg7m','Canada',NULL),('99132069','ROLE_STU','Columbine','850923-1473755','M','물리학과','163.193.134.213','783-229-6207','ecolumbine9d@nsw.gov.au','Pdk9CG','Canada',NULL),('99134963','ROLE_STU','Meas','840419-2336610','F','의류학과','42.43.202.55','867-962-8838','kmeas9r@economist.com','cwc75AqOnw','China',NULL),('99135036','ROLE_STU','Whitter','841220-2561227','F','사회복지학과','214.79.204.80','601-267-7229','swhitter2k@google.ru','c91bixYNMEMd','Ireland',NULL),('99135606','ROLE_STU','Hlavecek','940208-2954697','F','경영학과','186.113.120.75','274-884-2422','khlavecek1b@opensource.org','TVrRj29bexF','Philippines',NULL),('99136955','ROLE_STU','Chesters','850712-2885875','F','언어학과','254.50.159.181','574-399-8295','tchesters7j@homestead.com','WIclfEvBM','Bulgaria',NULL),('99140982','ROLE_STU','Grindley','811121-2087949','F','영어영문학과','110.253.148.249','334-184-1946','tgrindley6b@webnode.com','Vx7xcxA','Indonesia',NULL),('99146775','ROLE_STU','Thiolier','860304-1920839','M','사회복지학과','41.14.215.99','397-978-9855','tthiolier9g@elegantthemes.com','zBAdj9','China',NULL),('99154775','ROLE_STU','Pollins','820214-1704533','M','기계공학과','250.92.225.46','787-197-5418','cpollins5y@slashdot.org','di4Nr0Toxpzm','Philippines',NULL),('99157379','ROLE_STU','Gansbuhler','821214-2138459','F','컴퓨터공학과','159.154.75.106','533-277-5794','ngansbuhler6u@illinois.edu','Vqe3f3IlrJv','Poland',NULL),('99158834','ROLE_STU','Fowlestone','930215-1833657','M','철학과','111.165.60.189','328-894-9958','ffowlestone6a@hexun.com','pUDiNKKlP9n','Serbia',NULL),('99159042','ROLE_STU','Prinett','970103-1225630','M','체육학과','64.170.61.30','600-825-2404','rprinettt@desdev.cn','Z1xsNWcUb','Russia',NULL),('99161386','ROLE_STU','Byrcher','980918-2931742','F','수학과','40.38.152.98','477-789-2065','lbyrcher69@uiuc.edu','V8KHz8','Philippines',NULL),('99162332','ROLE_STU','McNair','880328-1342379','M','심리학과','157.162.141.75','786-974-7465','cmcnairaz@themeforest.net','MKFS89RjlH','United States',NULL),('99164679','ROLE_STU','Kristufek','831105-1610232','M','의류학과','239.41.220.104','877-407-9417','bkristufekae@weibo.com','YSVp6y97','Poland',NULL),('99167651','ROLE_STU','Wolver','961110-1745347','M','경영학과','215.81.209.69','898-711-2639','ywolver8h@odnoklassniki.ru','YvfyplLbBlKY','Philippines',NULL),('99170018','ROLE_STU','Boyton','951229-1410089','M','경영학과','148.123.220.228','185-162-9157','lboyton38@reference.com','BoQ5GeT','Philippines',NULL),('99171742','ROLE_STU','Kitchaside','971104-2457036','F','컴퓨터공학과','9.228.17.13','711-919-4968','gkitchaside9o@cpanel.net','mx5rHU5','Indonesia',NULL),('99172098','ROLE_STU','Mathew','900305-1915575','M','언어학과','88.49.23.36','753-983-2530','cmathewcf@ask.com','8gTd5o','China',NULL),('99172969','ROLE_STU','Schwandermann','911019-2125188','F','언론정보학과','96.39.208.30','612-279-2240','dschwandermanndn@hc360.com','OzXhaRtFd','Netherlands',NULL),('99173220','ROLE_STU','Deeley','840322-2543171','F','경영학과','92.237.141.22','210-336-9750','adeeley5l@goodreads.com','2LPPx3fp','Nicaragua',NULL),('99178514','ROLE_STU','Matokhnin','910629-2579591','F','국어국문학과','72.222.106.16','569-726-2135','ematokhninbo@samsung.com','YL3Q9z','China',NULL),('99179911','ROLE_STU','Veracruysse','951112-2355821','F','체육학과','250.240.187.253','635-241-8600','cveracruysseb8@elpais.com','RMhaGi2n2D','Australia',NULL),('99181013','ROLE_STU','Brawley','840407-1301557','M','사회학과','199.171.232.28','765-985-8927','abrawley2h@networksolutions.com','Z4sxymJ6qtkl','Thailand',NULL),('99185489','ROLE_STU','Elegood','871228-2509098','F','기계공학과','0.0.124.221','908-939-8411','eelegoodcg@earthlink.net','PgF9wepL','Argentina',NULL),('99187512','ROLE_STU','Maass','811023-2280808','F','물리학과','30.134.129.253','761-807-5872','kmaassa7@yahoo.com','q1Qn6UV','Nicaragua',NULL),('99188532','ROLE_STU','Turton','941207-2857887','F','사회학과','86.164.48.203','744-123-7096','mturton36@china.com.cn','9vZBfJPihax','Indonesia',NULL),('99188717','ROLE_STU','Philippson','990622-1086071','M','사회복지학과','98.180.60.34','948-484-2935','jphilippson9y@prnewswire.com','N1OqCm','France',NULL),('99193449','ROLE_STU','Abreheart','860303-1624278','M','영어영문학과','177.8.90.153','110-178-2180','mabreheart88@go.com','hqU0SPuH','Croatia',NULL),('99194300','ROLE_STU','Tolson','810526-2159190','F','의류학과','161.91.190.244','297-499-8455','mtolsondo@multiply.com','zdVpsNWzDfz4','Kazakhstan',NULL),('99195608','ROLE_STU','Cockerill','910603-2587765','F','영어영문학과','244.125.62.102','437-801-6131','lcockerill4j@mozilla.com','tA3z6WLjCg0','China',NULL),('99203458','ROLE_PROF','Rivett','920706-2201243','F','사회학과','162.236.151.121','552-651-9494','trivett80@hibu.com','2NS0Sved','Mongolia',NULL),('99212905','ROLE_PROF','Wissby','800614-2204594','F','국어국문학과','246.148.4.229','791-537-1007','awissby1c@techcrunch.com','27Dr4VPXJAJc','Colombia',NULL),('99242637','ROLE_PROF','Charlin','910322-1228114','M','경영학과','105.181.180.132','731-715-4069','echarlina2@pcworld.com','GlV5hk0eDByb','China',NULL),('99249681','ROLE_PROF','Llewhellin','980723-2990341','F','철학과','91.178.221.1','888-340-7487','lllewhellinat@nps.gov','XoM5MheO','Indonesia',NULL),('99250159','ROLE_PROF','Feldhuhn','991117-2857577','F','건축학과','152.110.240.100','974-989-4050','gfeldhuhnd6@w3.org','yN7rThYz','Indonesia',NULL),('99253149','ROLE_PROF','Northcliffe','950409-2605496','F','사회학과','179.188.247.223','814-160-1036','cnorthcliffec@blogtalkradio.com','7onKd1US','United States',NULL),('99255215','ROLE_PROF','Chipchase','810206-1120779','M','언어학과','217.24.179.74','599-909-7077','gchipchase2g@paypal.com','H3bZ7ELCVRV','Norway',NULL),('99261832','ROLE_PROF','Detoc','820515-2011330','F','체육학과','172.207.52.116','780-597-1680','cdetocb7@t-online.de','TZWr2dwXg8e','Vanuatu',NULL),('99289861','ROLE_PROF','Garthland','801221-2054490','F','심리학과','9.200.7.147','942-784-3451','cgarthlanddb@angelfire.com','RbrAtIq5','Papua New Guinea',NULL),('99295054','ROLE_PROF','Snalham','980804-2393511','F','사회복지학과','179.206.164.203','325-702-2873','esnalham1q@jigsy.com','oeTVvm','Russia',NULL),('99333770','ROLE_ADMIN','Pfleger','850412-1709461','M','재무','230.100.239.164','672-522-0692','wpfleger74@dagondesign.com','WqQ5B90sSLwt','Brazil',NULL),('99376683','ROLE_ADMIN','Raffin','801112-2013227','F','기획','165.125.186.23','125-454-3538','iraffindf@wufoo.com','rz2aH4A','China',NULL),('a12h0000','ROLE_STU','testname','001122-3333333','F','','','','','$2a$10$dzznctHUqEoOFqed5BtWFOa2Y/JPTcRBU40.xbwe.KCugNvgd4yYC','',NULL),('test123','ROLE_STU','testname','001122-2446325','F','경영학과','testaddr','testphone','testemail','$2a$10$zKFX6Yi6Uk1.9jv.zDhDjeLDli1MbWd1sMuB76jNDWzwHQ83xPJiK','testnation',NULL),('testprof','ROLE_PROF','testname2','810604-1846235','M','컴퓨터공학과','testaddr2','testphone2','testemail2','$2a$10$vwjohV1/0GL0ISm8hyZBe.teG5.E7aeYNagwOnQlRdl5115LU9.rq','testnation2',NULL);
/*!40000 ALTER TABLE `k_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matchigId_seq`
--

DROP TABLE IF EXISTS `matchigId_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matchigId_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matchigId_seq`
--

LOCK TABLES `matchigId_seq` WRITE;
/*!40000 ALTER TABLE `matchigId_seq` DISABLE KEYS */;
INSERT INTO `matchigId_seq` VALUES (3001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `matchigId_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_id_seq`
--

DROP TABLE IF EXISTS `notice_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_id_seq`
--

LOCK TABLES `notice_id_seq` WRITE;
/*!40000 ALTER TABLE `notice_id_seq` DISABLE KEYS */;
INSERT INTO `notice_id_seq` VALUES (3000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `notice_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_no_seq`
--

DROP TABLE IF EXISTS `notice_no_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice_no_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_no_seq`
--

LOCK TABLES `notice_no_seq` WRITE;
/*!40000 ALTER TABLE `notice_no_seq` DISABLE KEYS */;
INSERT INTO `notice_no_seq` VALUES (1001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `notice_no_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_d_id_seq`
--

DROP TABLE IF EXISTS `quiz_d_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_d_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_d_id_seq`
--

LOCK TABLES `quiz_d_id_seq` WRITE;
/*!40000 ALTER TABLE `quiz_d_id_seq` DISABLE KEYS */;
INSERT INTO `quiz_d_id_seq` VALUES (2001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_d_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_h_id_seq`
--

DROP TABLE IF EXISTS `quiz_h_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_h_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_h_id_seq`
--

LOCK TABLES `quiz_h_id_seq` WRITE;
/*!40000 ALTER TABLE `quiz_h_id_seq` DISABLE KEYS */;
INSERT INTO `quiz_h_id_seq` VALUES (2001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_h_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_r_id_seq`
--

DROP TABLE IF EXISTS `quiz_r_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_r_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_r_id_seq`
--

LOCK TABLES `quiz_r_id_seq` WRITE;
/*!40000 ALTER TABLE `quiz_r_id_seq` DISABLE KEYS */;
INSERT INTO `quiz_r_id_seq` VALUES (2001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_r_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_seq`
--

DROP TABLE IF EXISTS `quiz_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_seq`
--

LOCK TABLES `quiz_seq` WRITE;
/*!40000 ALTER TABLE `quiz_seq` DISABLE KEYS */;
INSERT INTO `quiz_seq` VALUES (3005,1,9223372036854775806,5,1,1000,0,0);
/*!40000 ALTER TABLE `quiz_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduleSeq`
--

DROP TABLE IF EXISTS `scheduleSeq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduleSeq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduleSeq`
--

LOCK TABLES `scheduleSeq` WRITE;
/*!40000 ALTER TABLE `scheduleSeq` DISABLE KEYS */;
INSERT INTO `scheduleSeq` VALUES (4001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `scheduleSeq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seq_mysql`
--

DROP TABLE IF EXISTS `seq_mysql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seq_mysql` (
  `id` int(11) NOT NULL,
  `seq_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seq_mysql`
--

LOCK TABLES `seq_mysql` WRITE;
/*!40000 ALTER TABLE `seq_mysql` DISABLE KEYS */;
INSERT INTO `seq_mysql` VALUES (0,'scheduleSeq'),(0,'careerqid');
/*!40000 ALTER TABLE `seq_mysql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_career_h_id`
--

DROP TABLE IF EXISTS `sq_career_h_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_career_h_id` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_career_h_id`
--

LOCK TABLES `sq_career_h_id` WRITE;
/*!40000 ALTER TABLE `sq_career_h_id` DISABLE KEYS */;
INSERT INTO `sq_career_h_id` VALUES (2001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_career_h_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_career_list`
--

DROP TABLE IF EXISTS `sq_career_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_career_list` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_career_list`
--

LOCK TABLES `sq_career_list` WRITE;
/*!40000 ALTER TABLE `sq_career_list` DISABLE KEYS */;
INSERT INTO `sq_career_list` VALUES (3001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_career_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_career_q_id`
--

DROP TABLE IF EXISTS `sq_career_q_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_career_q_id` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_career_q_id`
--

LOCK TABLES `sq_career_q_id` WRITE;
/*!40000 ALTER TABLE `sq_career_q_id` DISABLE KEYS */;
INSERT INTO `sq_career_q_id` VALUES (4001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_career_q_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq_mtr_id`
--

DROP TABLE IF EXISTS `sq_mtr_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq_mtr_id` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq_mtr_id`
--

LOCK TABLES `sq_mtr_id` WRITE;
/*!40000 ALTER TABLE `sq_mtr_id` DISABLE KEYS */;
INSERT INTO `sq_mtr_id` VALUES (2001,1,9223372036854775806,1,1,1000,0,0);
/*!40000 ALTER TABLE `sq_mtr_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_code_seq`
--

DROP TABLE IF EXISTS `timetable_code_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_code_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_code_seq`
--

LOCK TABLES `timetable_code_seq` WRITE;
/*!40000 ALTER TABLE `timetable_code_seq` DISABLE KEYS */;
INSERT INTO `timetable_code_seq` VALUES (2000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `timetable_code_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable_id_seq`
--

DROP TABLE IF EXISTS `timetable_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable_id_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) unsigned NOT NULL,
  `cycle_option` tinyint(1) unsigned NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB SEQUENCE=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable_id_seq`
--

LOCK TABLES `timetable_id_seq` WRITE;
/*!40000 ALTER TABLE `timetable_id_seq` DISABLE KEYS */;
INSERT INTO `timetable_id_seq` VALUES (2000,1,9223372036854775806,1000,1,1000,0,0);
/*!40000 ALTER TABLE `timetable_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'kcy'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_terms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`kcy`@`%` FUNCTION `fn_terms`(p_sch_id varchar(100)
  ) RETURNS varchar(100) CHARSET utf8mb4
begin
  	declare v_sch_title varchar(100);
  
  SELECT sch_title
  into v_sch_title
  from k_schedule
  where sch_id = p_sch_id;
 
 return v_sch_title;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-31 19:30:17
