package com.kcy.lecture.service;

import lombok.Data;

@Data
public class RoomVO {

	
	private String roomId;
	private String roomBuilding;
	private int roomNo;
}
