package com.kcy.lecture.service;

import lombok.Data;

@Data
public class MajorVO {

	private String majorName;
	
}

