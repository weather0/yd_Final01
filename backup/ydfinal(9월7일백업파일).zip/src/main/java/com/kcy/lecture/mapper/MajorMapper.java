package com.kcy.lecture.mapper;

import java.util.List;

import com.kcy.lecture.service.MajorVO;

public interface MajorMapper {

	public List<MajorVO> majorlist();
}
