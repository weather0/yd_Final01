package com.kcy.lecture.mapper;

import java.util.List;

import com.kcy.lecture.service.RoomVO;

public interface RoomMapper {

	public List<RoomVO>getRoomId(RoomVO vo);
}
