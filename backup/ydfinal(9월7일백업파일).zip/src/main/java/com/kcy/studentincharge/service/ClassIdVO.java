package com.kcy.studentincharge.service;

import lombok.Data;

@Data
public class ClassIdVO {

	private String classId;
	private String userId;
	private String courseTitle;
}
