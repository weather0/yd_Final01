package com.kcy.studentincharge.service;

import lombok.Data;

@Data
public class StudentInChargeVO {

	private String userId;
	private String classId;
	
}
