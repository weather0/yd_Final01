package com.kcy.matching.service;

import lombok.Data;

@Data
public class MatchingProfVO {	
	private String profId;
	private String userName;
	private String userDept;
	private String profLab;
	private int mentee;
}
