package com.kcy.lecture.mapper;

import java.util.List;

import com.kcy.lecture.service.CourseVO;


public interface CourseMapper {

	 public List<CourseVO> getCourse(CourseVO vo);
	 
	
	
}
