package com.kcy.lecture.service;

import lombok.Data;

@Data
public class EnrolmentVO {
	
	
	private String classId;
	private String stuId;
	private String userId;
	private String classMemberId;
	private int classCk;

}
