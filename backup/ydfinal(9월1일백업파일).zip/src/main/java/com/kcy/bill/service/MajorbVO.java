package com.kcy.bill.service;

import lombok.Data;

@Data
public class MajorbVO {
	public String majorId;
	public String majorName;
}
