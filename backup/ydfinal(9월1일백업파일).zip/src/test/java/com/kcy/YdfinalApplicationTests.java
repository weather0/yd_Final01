package com.kcy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YdfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
